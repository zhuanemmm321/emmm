(function () {
  var target = String.fromCharCode(30331, 24405);
  var all = document.querySelectorAll('a,button,div,span,li');
  for (var i = 0; i < all.length; i++) {
    var el = all[i];
    if (el.children.length === 0 && (el.innerText || '').trim() === target) {
      el.click();
      return 'CLICKED ' + el.tagName + ' class=' + el.className;
    }
  }
  return 'NOT_FOUND:' + document.title;
})()

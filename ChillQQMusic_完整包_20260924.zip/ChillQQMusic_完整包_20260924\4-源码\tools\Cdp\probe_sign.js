(function () {
  var out = [];
  var keys = Object.keys(window);
  var hits = keys.filter(function (n) { return /sign|Sign|security|Security|musicu|encrypt|Encrypt|hash|Hash|qqmusic/i.test(n); });
  out.push("globals=" + hits.join(","));
  var fnHits = [];
  for (var i = 0; i < hits.length && fnHits.length < 20; i++) {
    try { if (typeof window[hits[i]] === "function") fnHits.push(hits[i] + "(" + window[hits[i]].length + ")"); } catch (e) { }
  }
  out.push("functions=" + fnHits.join(","));
  var scripts = document.querySelectorAll("script[src]");
  var srcs = [];
  for (var j = 0; j < scripts.length && srcs.length < 12; j++) {
    if ((scripts[j].src || "").indexOf("y.qq.com") >= 0) srcs.push(scripts[j].src);
  }
  out.push("scripts=" + srcs.length);
  out.push(srcs.slice(0, 6).join(" | "));
  return out.join(" ;; ");
})()

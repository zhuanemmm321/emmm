<#
  Fallback build script for ChillQQMusic.
  It calls Roslyn csc directly, so it does not depend on MSBuild resolving the Windows SDK paths
  (which can fail with "access denied" in restricted environments).

  Usage:
    powershell -ExecutionPolicy Bypass -File .\build.ps1
    powershell -ExecutionPolicy Bypass -File .\build.ps1 -CheckOnly   # syntax check only, no BepInEx needed

  NOTE: keep this file ASCII-only. Windows PowerShell 5.1 reads BOM-less .ps1 as ANSI.
#>
param(
    [string]$GameDir = 'D:\SteamLibrary\steamapps\common\Chill with You Lo-Fi Story',
    [string]$Csc = 'C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\Roslyn\csc.exe',
    [string]$FrameworkDir = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319',
    [switch]$CheckOnly
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$managed = Join-Path $GameDir 'Chill With You_Data\Managed'
$bepinex = Join-Path $GameDir 'BepInEx'
$plugins = Join-Path $bepinex 'plugins\ChillQQMusic'

if (-not (Test-Path $Csc)) { throw "Cannot find csc: $Csc" }
if (-not (Test-Path $managed)) { throw "Cannot find game Managed folder: $managed" }

$unityAssemblies = @(
    'UnityEngine.dll',
    'UnityEngine.CoreModule.dll',
    'UnityEngine.UI.dll',
    'UnityEngine.UIModule.dll',
    'UnityEngine.AudioModule.dll',
    'UnityEngine.ImageConversionModule.dll',
    'UnityEngine.IMGUIModule.dll',
    'UnityEngine.InputLegacyModule.dll',
    'UnityEngine.TextRenderingModule.dll',
    'UnityEngine.UnityWebRequestModule.dll',
    'UnityEngine.UnityWebRequestAudioModule.dll',
    'UnityEngine.UnityWebRequestTextureModule.dll',
    'Newtonsoft.Json.dll'
)

$frameworkAssemblies = @('mscorlib.dll','System.dll','System.Core.dll','System.Net.Http.dll','System.Security.dll','System.Xml.dll','System.Xml.Linq.dll')

$cscArgs = @('-nologo', '-target:library', '-langversion:9.0', '-optimize+', '-nowarn:1591')
foreach ($a in $frameworkAssemblies) { $cscArgs += "/r:$(Join-Path $FrameworkDir $a)" }
foreach ($a in @('netstandard.dll','System.Runtime.dll')) { $cscArgs += "/r:$(Join-Path $managed $a)" }
foreach ($a in $unityAssemblies) { $cscArgs += "/r:$(Join-Path $managed $a)" }

$sources = Get-ChildItem (Join-Path $root 'ChillQQMusic\*.cs') | ForEach-Object { $_.FullName }

if ($CheckOnly) {
    $cscArgs += "/out:$(Join-Path $root 'tools\StubCheck\chillqqmusic.check.dll')"
    $cscArgs += (Join-Path $root 'tools\StubCheck\BepInExStubs.cs')
    $cscArgs += $sources
    Write-Host 'Syntax check...' -ForegroundColor Cyan
    & $Csc @cscArgs
    if ($LASTEXITCODE -ne 0) { throw "Compile failed (exit=$LASTEXITCODE)" }
    Write-Host 'Syntax check passed.' -ForegroundColor Green
    return
}

$bepInExDll = Join-Path $bepinex 'core\BepInEx.dll'
if (-not (Test-Path $bepInExDll)) { throw "BepInEx.dll not found. Install BepInEx 5 and run the game once: $bepInExDll" }
$cscArgs += "/r:$bepInExDll"
$cscArgs += "/r:$(Join-Path $bepinex 'core\0Harmony.dll')"

$outDir = Join-Path $root 'ChillQQMusic\bin\Release'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$cscArgs += "/out:$(Join-Path $outDir 'ChillQQMusic.dll')"
$cscArgs += "/doc:$(Join-Path $outDir 'ChillQQMusic.xml')"
$cscArgs += $sources

Write-Host 'Building plugin...' -ForegroundColor Cyan
& $Csc @cscArgs
if ($LASTEXITCODE -ne 0) { throw "Compile failed (exit=$LASTEXITCODE)" }

New-Item -ItemType Directory -Force -Path $plugins | Out-Null
Copy-Item (Join-Path $outDir 'ChillQQMusic.dll') $plugins -Force

# Native m4a decoder (calls Windows Media Foundation) must sit next to the plugin DLL
$mfDecode = Join-Path $root 'tools\MfDecode\MfDecode.dll'
if (Test-Path $mfDecode) {
    Copy-Item $mfDecode $plugins -Force
    Write-Host "Copied MfDecode.dll (native m4a decoder)" -ForegroundColor Green
} else {
    Write-Host "WARN: MfDecode.dll not found - m4a playback will not work" -ForegroundColor Yellow
}
Write-Host "Done. Deployed to: $plugins" -ForegroundColor Green

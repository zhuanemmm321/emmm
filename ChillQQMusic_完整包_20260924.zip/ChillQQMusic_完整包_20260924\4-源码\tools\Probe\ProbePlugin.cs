// 诊断用探针插件（独立 BepInEx 插件，GUID 与主插件不同）。
// 目的：在当前游戏里隔离验证三件事——
//   1) BepInEx 插件的 Awake / Update / OnGUI 到底会不会被调用；
//   2) 一个最朴素的 UGUI Canvas（屏幕中央大红框）能不能渲染出来；
//   3) 插件 GameObject 是否被游戏销毁（OnDestroy 会记录）。
// 日志写两份：BepInEx 控制台 + 立即 flush 的 probe.log（防止崩溃丢日志）。
// 定位完成后可以直接删除本 DLL。
using System;
using System.IO;
using BepInEx;
using BepInEx.Logging;
using UnityEngine;
using UnityEngine.UI;

namespace ChillQQMusicProbe
{
    [BepInPlugin(ProbeGuid, "ChillQQMusic Probe", "0.1.0")]
    public class ProbePlugin : BaseUnityPlugin
    {
        public const string ProbeGuid = "com.codex.chillqqmusic.probe";

        private static ManualLogSource _log;
        private static StreamWriter _file;

        private Canvas _canvas;
        private GameObject _panel;
        private int _frame;
        private float _nextHeartbeat;
        private bool _guiSeen;

        private int _beforeRenderCount;
        private float _nextBeforeRenderLog;
        private int _willRenderCount;
        private float _nextWillRenderLog;
        private static int _lastBeforeRenderFrame = -1;
        private static int _lastWillRenderFrame = -1;
        private Canvas _lateCanvas;
        private GameObject _latePanel;

        private void Awake()
        {
            _log = Logger;
            try
            {
                var dir = Path.Combine(Paths.ConfigPath, "ChillQQMusic");
                Directory.CreateDirectory(dir);
                var path = Path.Combine(dir, "probe.log");
                _file = new StreamWriter(new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                {
                    AutoFlush = true      // 崩溃也不丢日志
                };

                Write("================ probe v1 启动 ================");
                Write("unity=" + Application.unityVersion
                      + " screen=" + Screen.width + "x" + Screen.height
                      + " fullscreen=" + Screen.fullScreen
                      + " platform=" + Application.platform);
                Write("paths: config=" + Paths.ConfigPath + " plugins=" + Paths.PluginPath);

                // 测量三个"不依赖 MonoBehaviour"的引擎回调会不会触发
                Application.onBeforeRender += OnBeforeRenderProbe;
                Canvas.willRenderCanvases += OnWillRenderProbe;
                UnityEngine.SceneManagement.SceneManager.sceneLoaded += OnSceneLoadedProbe;
                Write("已注册 3 个引擎回调探针：onBeforeRender / willRenderCanvases / sceneLoaded");

                BuildSimpleUi();

                Write("Awake 结束，接下来看有没有 update# 心跳");
                StartCoroutine(HeartbeatRoutine());
            }
            catch (Exception e)
            {
                Write("!!! Awake 异常: " + e);
            }
        }

        private void OnSceneLoadedProbe(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode)
        {
            Write("sceneLoaded 触发：" + scene.name + "（" + mode + "）frame=" + Time.frameCount);

            // 关键验证：在"场景加载之后"再建一个 Canvas，看它能不能活下来并渲染。
            if (_lateCanvas == null)
            {
                try
                {
                    var go = new GameObject("ProbeLateCanvas");
                    go.hideFlags = HideFlags.DontSave;
                    UnityEngine.Object.DontDestroyOnLoad(go);
                    _lateCanvas = go.AddComponent<Canvas>();
                    _lateCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                    _lateCanvas.sortingOrder = 26000;
                    go.AddComponent<GraphicRaycaster>();

                    _latePanel = new GameObject("LatePanel", typeof(RectTransform), typeof(Image));
                    _latePanel.transform.SetParent(go.transform, false);
                    var rect = _latePanel.GetComponent<RectTransform>();
                    rect.anchorMin = new Vector2(0.5f, 1f);
                    rect.anchorMax = new Vector2(0.5f, 1f);
                    rect.pivot = new Vector2(0.5f, 1f);
                    rect.sizeDelta = new Vector2(700f, 160f);
                    rect.anchoredPosition = new Vector2(0f, -40f);
                    _latePanel.GetComponent<Image>().color = new Color(0.15f, 0.7f, 0.25f, 0.85f);
                    Write("【迟建 Canvas】已在场景加载后创建绿色测试条（屏幕顶部中间），继续观察它是否存活");
                }
                catch (Exception e)
                {
                    Write("迟建 Canvas 失败: " + e.Message);
                }
            }
        }

        private void OnBeforeRenderProbe()
        {
            _beforeRenderCount++;
            if (Time.frameCount == _lastBeforeRenderFrame) return;
            _lastBeforeRenderFrame = Time.frameCount;
            if (Time.unscaledTime >= _nextBeforeRenderLog)
            {
                _nextBeforeRenderLog = Time.unscaledTime + 5f;
                Write("onBeforeRender 心跳：frame=" + Time.frameCount + " t=" + Time.unscaledTime.ToString("F1")
                      + " 调用次数=" + _beforeRenderCount
                      + " | 早期Canvas存活=" + (_canvas != null)
                      + " 迟建Canvas存活=" + (_lateCanvas != null)
                      + " 插件对象存活=" + (this != null));
            }
        }

        private void OnWillRenderProbe()
        {
            _willRenderCount++;
            if (Time.frameCount == _lastWillRenderFrame) return;
            _lastWillRenderFrame = Time.frameCount;
            if (Time.unscaledTime >= _nextWillRenderLog)
            {
                _nextWillRenderLog = Time.unscaledTime + 5f;
                Write("willRenderCanvases 心跳：frame=" + Time.frameCount + " t=" + Time.unscaledTime.ToString("F1")
                      + " 调用次数=" + _willRenderCount);
            }
        }

        /// <summary>协程心跳：能跑说明 MonoBehaviour 生命周期是通的。</summary>
        private System.Collections.IEnumerator HeartbeatRoutine()
        {
            var n = 0;
            while (true)
            {
                yield return new WaitForSeconds(5f);
                n++;
                Write("协程心跳 #" + n + " t=" + Time.unscaledTime.ToString("F1") + "（MonoBehaviour 生命周期正常）");
            }
        }

        private void BuildSimpleUi()
        {
            try
            {
                var go = new GameObject("ProbeCanvas");
                UnityEngine.Object.DontDestroyOnLoad(go);

                _canvas = go.AddComponent<Canvas>();
                _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                _canvas.sortingOrder = 25000;

                var scaler = go.AddComponent<CanvasScaler>();
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ConstantPixelSize;
                go.AddComponent<GraphicRaycaster>();

                Write("Canvas 已创建: renderMode=" + _canvas.renderMode
                      + " sortingOrder=" + _canvas.sortingOrder
                      + " isRootCanvas=" + _canvas.isRootCanvas
                      + " enabled=" + _canvas.enabled);

                _panel = new GameObject("ProbePanel", typeof(RectTransform), typeof(Image));
                _panel.transform.SetParent(go.transform, false);
                var rect = _panel.GetComponent<RectTransform>();
                rect.anchorMin = new Vector2(0.5f, 0.5f);
                rect.anchorMax = new Vector2(0.5f, 0.5f);
                rect.pivot = new Vector2(0.5f, 0.5f);
                rect.sizeDelta = new Vector2(700f, 280f);
                rect.anchoredPosition = Vector2.zero;

                var image = _panel.GetComponent<Image>();
                image.color = new Color(0.92f, 0.18f, 0.12f, 0.85f);
                image.raycastTarget = false;
                Write("红色测试面板已创建（屏幕正中央，700x280）。看不到它 = UGUI 渲染层有问题");

                var textGo = new GameObject("ProbeText", typeof(RectTransform), typeof(Text));
                textGo.transform.SetParent(_panel.transform, false);
                var textRect = textGo.GetComponent<RectTransform>();
                textRect.anchorMin = Vector2.zero;
                textRect.anchorMax = Vector2.one;
                textRect.offsetMin = new Vector2(12f, 12f);
                textRect.offsetMax = new Vector2(-12f, -12f);

                var text = textGo.GetComponent<Text>();
                text.font = Font.CreateDynamicFontFromOSFont(
                    new[] { "Microsoft YaHei UI", "Microsoft YaHei", "SimHei", "Arial" }, 30);
                text.text = "PROBE OK\n看到红框 = UGUI 正常\n按 F8 后日志里应有「检测到 F8」";
                text.fontSize = 28;
                text.color = Color.white;
                text.alignment = TextAnchor.MiddleCenter;
                text.raycastTarget = false;

                Write("文字控件已创建, font=" + (text.font != null ? text.font.name : "null"));
            }
            catch (Exception e)
            {
                Write("!!! BuildSimpleUi 异常: " + e);
            }
        }

        private void Update()
        {
            try
            {
                _frame++;
                if (Time.unscaledTime >= _nextHeartbeat)
                {
                    _nextHeartbeat = Time.unscaledTime + 5f;
                    Write(string.Format(
                        "update 心跳 frame={0} t={1:F1} scene={2} focused={3} canvasNull={4} panelActive={5}",
                        _frame, Time.unscaledTime,
                        UnityEngine.SceneManagement.SceneManager.GetActiveScene().name,
                        Application.isFocused, _canvas == null,
                        _panel != null && _panel.activeInHierarchy));
                }

                if (Input.GetKeyDown(KeyCode.F8)) Write("检测到 F8 按键（Input 层正常）");
                if (Input.GetKeyDown(KeyCode.F6)) Write("检测到 F6 按键");
                if (Input.GetKeyDown(KeyCode.F9)) Write("检测到 F9 按键");
                if (Input.GetKeyDown(KeyCode.F10)) Write("检测到 F10 按键");
            }
            catch (Exception e)
            {
                Write("!!! Update 异常: " + e.Message);
            }
        }

        private void OnGUI()
        {
            if (!_guiSeen)
            {
                _guiSeen = true;
                Write("OnGUI 被调用（IMGUI 层正常）");
            }

            GUI.Label(new Rect(24f, 24f, 1200f, 40f),
                "IMGUI 探针：能看到这行字说明 Unity 的界面渲染是通的（即使 UGUI 红框没出现）");
        }

        private void OnDestroy()
        {
            Write("!!! 探针插件 GameObject 被销毁（OnDestroy 触发）!!!");
        }

        private static void Write(string message)
        {
            var line = DateTime.Now.ToString("HH:mm:ss.fff") + "  " + message;
            try { _file?.WriteLine(line); } catch { /* 忽略 */ }
            try { _log?.LogInfo("[probe] " + message); } catch { /* 忽略 */ }
        }
    }
}

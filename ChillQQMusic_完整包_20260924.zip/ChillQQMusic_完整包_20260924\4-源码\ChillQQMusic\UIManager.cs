﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Networking;
using UnityEngine.UI;

namespace ChillQQMusic
{
    /// <summary>
    /// 游戏内悬浮 UI（UGUI，全部代码动态创建）。
    /// 视觉走 Lo-Fi：米白纸张 + 暖黄点缀 + 圆角 + 半透明 + 轻微噪点 + 黑胶封面。
    /// 所有 Unity API 都只在主线程调用。
    /// </summary>
    public sealed class UIManager : MonoBehaviour
    {
        private const float PanelWidth = 430f;
        private const float PanelHeight = 620f;
        private const float Pad = 20f;

        private ConfigManager _settings;
        private PlaylistManager _playlist;
        private AudioPlayer _audio;
        private LoginManager _login;
        private AudioCache _cache;

        private Canvas _canvas;
        private CanvasGroup _group;
        private RectTransform _panel;
        private RectTransform _vinyl;
        private Image _coverArt;
        private GameObject _coverMask;

        private Text _titleText;
        private Text _artistText;
        private Text _qualityText;
        private Text _positionText;
        private Text _durationText;
        private Text _lyricCurrent;
        private Text _lyricNext;
        private Text _playlistName;
        private Text _statusText;
        private Text _toastText;

        private LofiSlider _progress;
        private LofiSlider _volume;
        private Button _playButton;
        private Button _modeButton;
        private Button _lyricsButton;

        private GameObject _lyricRoot;
        private GameObject _loginPanel;
        private GameObject _playlistPanel;
        private RawImage _qrImage;
        private Texture2D _qrTexture;
        private Text _loginStatus;
        private InputField _cookieInput;
        private RectTransform _playlistListRoot;
        private Text _playlistPanelStatus;
        private InputField _playlistIdInput;
        private InputField _userUidInput;

        private Lyrics _lyrics;
        private bool _visible = true;
        private bool _built;
        private bool _eventSystemCreated;
        private float _showUntil;
        private float _coverAngle;
        private float _toastUntil;
        private int _lastLyricIndex = -2;
        private Coroutine _coverRoutine;
        private UnityWebRequest _coverRequest;
        private Sprite _coverSprite;
        private CancellationTokenSource _playlistListCts;

        // ------------------------------------------------------------------ 构建

        internal void Build(ConfigManager settings, PlaylistManager playlist, AudioPlayer audio,
            LoginManager login, AudioCache cache)
        {
            if (_built) return;
            _built = true;

            _settings = settings;
            _playlist = playlist;
            _audio = audio;
            _login = login;
            _cache = cache;

            var canvasGo = new GameObject("ChillQQMusicCanvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasGo.hideFlags = HideFlags.DontSave;      // 场景切换不销毁
            DontDestroyOnLoad(canvasGo);
            _canvas = canvasGo.GetComponent<Canvas>();
            _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            _canvas.sortingOrder = 32000;

            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;

            BuildPanel(canvasGo.transform);
            BuildSideButton(canvasGo.transform);
            Subscribe();
            ApplyConfig();
            RefreshHeaderTexts();

            // 启动后完整显示一段时间，避免"窗口其实在左下角，只是淡到看不见"。
            // 默认改为"启动时隐藏"，需要时按 F8 或点游戏内音符按钮呼出。
            _visible = _settings.ShowUiOnStart.Value;
            if (_visible && _settings.ShowOnStartSeconds.Value > 0f)
                _showUntil = Time.unscaledTime + _settings.ShowOnStartSeconds.Value;
            else
                _showUntil = 0f;

            StartCoroutine(FirstFrameDiagnostics());
        }

        /// <summary>
        /// 屏幕最左侧的呼出按钮：与游戏原生圆形按钮同风格（深色玻璃 + 青→品红渐变描边）、同尺寸（56px）。
        /// 它挂在 Canvas 下而不是悬浮窗内，因此不会随面板一起淡出，始终可点。
        /// </summary>
        private void BuildSideButton(Transform canvasRoot)
        {
            if (_settings == null || !_settings.ShowSideButton.Value) return;

            try
            {
                var background = LoFiTheme.GradientRing(128,
                    new Color32(0x10, 0x10, 0x20, 0xC4), LoFiTheme.Accent, LoFiTheme.AccentDeep, 4);

                var button = UiKit.IconButton(canvasRoot, "SideMusicButton", new Vector2(56f, 56f),
                    background, LofiIcon.Music, LoFiTheme.IconLav, ToggleVisible, "音乐播放器 (F8)");

                var rect = button.GetComponent<RectTransform>();
                rect.anchorMin = new Vector2(0f, 0.5f);
                rect.anchorMax = new Vector2(0f, 0.5f);
                rect.pivot = new Vector2(0f, 0.5f);
                rect.anchoredPosition = new Vector2(22f, _settings.SideButtonOffsetY.Value);
                _sideButton = button.gameObject;
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("创建左侧呼出按钮失败: " + e.Message);
            }
        }

        private GameObject _sideButton;
        private bool _sideButtonAttached;

        /// <summary>
        /// 把左侧按钮挂到**游戏自己的 UI 层级**里。
        /// 这样它会跟随游戏 UI 一起：进游戏时淡入、退出时淡出、按游戏"隐藏 UI"时一起隐藏。
        /// 找不到容器时保持挂在插件自己的 Canvas 上（仍然可用，只是不随游戏 UI 变化）。
        /// </summary>
        internal void TryAttachSideButtonToGameUi()
        {
            if (_sideButton == null || _sideButtonAttached) return;

            try
            {
                var container = FindTransformByName("LeftIcons")
                                ?? FindTransformByName("LeftIcon")
                                ?? FindTransformByName("RightIcons");
                if (container == null) return;   // 这个场景还没有游戏 UI，等下次场景加载再试

                _sideButton.transform.SetParent(container, false);
                _sideButton.transform.SetSiblingIndex(0);   // 用户要求：排到这一排的最左边

                var rect = _sideButton.GetComponent<RectTransform>();
                rect.anchorMin = new Vector2(0f, 0.5f);
                rect.anchorMax = new Vector2(0f, 0.5f);
                rect.pivot = new Vector2(0f, 0.5f);
                rect.anchoredPosition = new Vector2(22f, _settings.SideButtonOffsetY.Value);

                // 尺寸：直接量一个原生兄弟按钮，保证"和游戏里其他按钮一样大"。
                // （之前写死 56，实测只画到 66 屏幕像素，而原生按钮是 107 像素。）
                var nativeSize = MeasureNativeButtonSize(container);
                var size = nativeSize.x > 1f && nativeSize.y > 1f ? nativeSize : new Vector2(56f, 56f);
                rect.sizeDelta = size;

                // 若容器带 LayoutGroup，用 LayoutElement 声明尺寸以免被压扁
                var layout = _sideButton.GetComponent<LayoutElement>();
                if (layout == null) layout = _sideButton.AddComponent<LayoutElement>();
                layout.preferredWidth = size.x;
                layout.preferredHeight = size.y;
                layout.minWidth = size.x;
                layout.minHeight = size.y;
                layout.flexibleWidth = 0f;
                layout.flexibleHeight = 0f;

                // 图标跟着按钮一起放大（否则大圆里一个小音符）
                var icon = _sideButton.transform.Find("Icon");
                if (icon != null) icon.GetComponent<RectTransform>().sizeDelta = size * 0.5f;

                _sideButtonAttached = true;
                Plugin.Log?.LogInfo("左侧呼出按钮已挂进游戏 UI：" + GetTransformPath(container)
                    + " 尺寸=" + size + "（量自原生按钮）"
                    + "（将随游戏 UI 一起淡入淡出）");
                StartCoroutine(LogSideButtonAfterLayout());
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("把左侧按钮挂进游戏 UI 失败: " + e.Message);
            }
        }

        /// <summary>等布局算完一帧后，把呼出按钮的真实尺寸/屏幕位置写进日志，方便远程核对。</summary>
        private IEnumerator LogSideButtonAfterLayout()
        {
            yield return null;
            yield return new WaitForEndOfFrame();
            if (_sideButton == null) yield break;

            try
            {
                var rect = _sideButton.GetComponent<RectTransform>();
                var corners = new Vector3[4];
                rect.GetWorldCorners(corners);
                var parentRect = rect.parent as RectTransform;

                Plugin.Log?.LogInfo(string.Format(
                    "[UI自检/呼出按钮] 布局尺寸={0} 屏幕矩形=({1:F0},{2:F0})-({3:F0},{4:F0}) 屏幕宽={5:F0}px 父容器={6}",
                    rect.rect.size, corners[0].x, corners[0].y, corners[2].x, corners[2].y,
                    Mathf.Abs(corners[2].x - corners[0].x),
                    parentRect != null ? parentRect.name : "无"));
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("呼出按钮自检失败: " + e.Message);
            }
        }

        private static Transform FindTransformByName(string namePart)
        {
            try
            {
                var all = Resources.FindObjectsOfTypeAll<Transform>();
                Transform firstMatch = null;
                foreach (var transform in all)
                {
                    if (transform == null || transform.gameObject == null) continue;
                    if (!transform.gameObject.scene.IsValid()) continue;      // 排除预制体资源
                    if (transform.name.Equals(namePart, StringComparison.OrdinalIgnoreCase)) return transform;
                    if (firstMatch == null && transform.name.IndexOf(namePart, StringComparison.OrdinalIgnoreCase) >= 0)
                        firstMatch = transform;
                }
                return firstMatch;
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("查找 UI 容器失败: " + e.Message);
                return null;
            }
        }

        /// <summary>
        /// 量一个原生兄弟按钮的尺寸，让我们的按钮和游戏按钮一样大。
        /// 优先用 LayoutElement.preferred（LayoutGroup 真正认的值），退回 RectTransform.rect。
        /// </summary>
        private static Vector2 MeasureNativeButtonSize(Transform container)
        {
            try
            {
                foreach (Transform sibling in container)
                {
                    if (sibling == null || sibling.name == "SideMusicButton") continue;

                    var element = sibling.GetComponent<LayoutElement>();
                    if (element != null && element.preferredWidth > 1f && element.preferredHeight > 1f)
                        return new Vector2(element.preferredWidth, element.preferredHeight);

                    var siblingRect = sibling as RectTransform;
                    if (siblingRect != null && siblingRect.rect.width > 1f && siblingRect.rect.height > 1f)
                        return siblingRect.rect.size;
                }
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("测量原生按钮尺寸失败: " + e.Message);
            }
            return Vector2.zero;
        }

        private static string GetTransformPath(Transform transform)
        {
            var path = transform.name;
            var parent = transform.parent;
            var depth = 0;
            while (parent != null && depth < 6)
            {
                path = parent.name + "/" + path;
                parent = parent.parent;
                depth++;
            }
            return path;
        }

        /// <summary>首帧自检：把 UI 的真实屏幕坐标 / 透明度写进日志，方便远程定位问题。</summary>
        private IEnumerator FirstFrameDiagnostics()
        {
            yield return null;
            yield return new WaitForEndOfFrame();
            ClampIntoView();
            LogUiState("首帧自检");
        }

        private void ClampIntoView()
        {
            if (_panel == null || _canvas == null) return;
            var canvasRect = _canvas.transform as RectTransform;
            if (canvasRect == null) return;

            var canvasSize = canvasRect.rect.size;
            if (canvasSize.x < 1f || canvasSize.y < 1f)
            {
                // 布局还没算出来时退回屏幕尺寸推算
                var scale = _canvas.scaleFactor > 0.001f ? _canvas.scaleFactor : 1f;
                canvasSize = new Vector2(Screen.width, Screen.height) / scale;
            }

            var scaleVec = _panel.localScale;
            var panelSize = new Vector2(PanelWidth * Mathf.Abs(scaleVec.x), PanelHeight * Mathf.Abs(scaleVec.y));
            var position = _panel.anchoredPosition;
            var clamped = new Vector2(
                Mathf.Clamp(position.x, 0f, Mathf.Max(0f, canvasSize.x - panelSize.x)),
                Mathf.Clamp(position.y, 0f, Mathf.Max(0f, canvasSize.y - panelSize.y)));

            if ((clamped - position).sqrMagnitude > 0.01f)
            {
                _panel.anchoredPosition = clamped;
                _settings.UiPosX.Value = clamped.x;
                _settings.UiPosY.Value = clamped.y;
                _settings.Save();
                Plugin.Log?.LogInfo("悬浮窗原坐标 " + position + " 超出屏幕，已修正为 " + clamped);
            }
        }

        private void LogUiState(string tag)
        {
            try
            {
                var corners = new Vector3[4];
                _panel.GetWorldCorners(corners);
                var canvasRect = _canvas.transform as RectTransform;
                var canvasSize = canvasRect != null ? canvasRect.rect.size : Vector2.zero;

                Plugin.Log?.LogInfo(string.Format(
                    "[UI自检/{0}] 屏幕={1}x{2} canvas={3}x{4} 面板位置={5} 尺寸={6} alpha={7:F2} 可见={8} 屏幕矩形=({9},{10})-({11},{12}) EventSystem={13}",
                    tag, Screen.width, Screen.height, canvasSize.x, canvasSize.y,
                    _panel.anchoredPosition, _panel.sizeDelta, _group.alpha, _visible,
                    corners[0].x, corners[0].y, corners[2].x, corners[2].y,
                    EventSystem.current != null ? EventSystem.current.name : "无"));
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("UI 自检失败: " + e.Message);
            }
        }

        private void BuildPanel(Transform parent)
        {
            var root = UiKit.Node(parent, "Panel");
            _panel = UiKit.Rect(root);
            _panel.anchorMin = Vector2.zero;
            _panel.anchorMax = Vector2.zero;
            _panel.pivot = Vector2.zero;
            _panel.sizeDelta = new Vector2(PanelWidth, PanelHeight);

            _group = root.AddComponent<CanvasGroup>();
            _group.alpha = 1f;

            // 柔和投影 + 纸面 + 噪点
            var shadow = UiKit.Panel(_panel, "Shadow",
                LoFiTheme.RoundedRect(360, 360, 34, new Color(0, 0, 0, 0), new Color(0, 0, 0, 0), 0, 0f, 26f),
                Color.white);
            var shadowRect = shadow.rectTransform;
            shadowRect.anchorMin = Vector2.zero;
            shadowRect.anchorMax = Vector2.one;
            shadowRect.offsetMin = new Vector2(-12f, -16f);
            shadowRect.offsetMax = new Vector2(12f, 8f);

            var background = UiKit.Panel(_panel, "Paper",
                LoFiTheme.GradientRoundedRect(360, 360, 22, LoFiTheme.Paper,
                    LoFiTheme.Accent, LoFiTheme.AccentDeep, 2),
                Color.white, true);
            UiKit.Stretch(background.rectTransform);

            var noise = UiKit.Panel(_panel, "Noise", LoFiTheme.Noise(96, 0.04f), new Color(1f, 1f, 1f, 0.12f));
            noise.type = UnityEngine.UI.Image.Type.Tiled;
            UiKit.Stretch(noise.rectTransform);
            noise.raycastTarget = false;

            // 顶部拖拽区
            var dragZone = UiKit.Panel(_panel, "DragZone",
                LoFiTheme.RoundedRect(64, 64, 26, new Color(1f, 1f, 1f, 0.01f), new Color(1f, 1f, 1f, 0.01f)),
                Color.white, true);
            TopLeft(dragZone, 0f, 0f, PanelWidth, 56f);
            var drag = dragZone.gameObject.AddComponent<PanelDragHandler>();
            drag.Target = _panel;
            drag.Canvas = _canvas;
            drag.DragEnded += OnPanelDragged;

            // 标题
            var title = UiKit.Label(_panel, "Header", "QQ 音乐 · Lo-Fi", 17, LoFiTheme.Ink, TextAnchor.MiddleLeft, FontStyle.Bold);
            TopLeft(title, Pad, 14f, 200f, 26f);

            // 顶部按钮
            var buttonSize = new Vector2(30f, 30f);
            var closeBg = LoFiTheme.Circle(64, LoFiTheme.PaperSoft, LoFiTheme.RingSoft, 2);
            var close = UiKit.IconButton(_panel, "Close", buttonSize, closeBg, LofiIcon.Close, LoFiTheme.IconLav,
                ToggleVisible, "隐藏 (F8)");
            TopLeft(close, PanelWidth - Pad - 30f, 12f, 30f, 30f);

            var login = UiKit.IconButton(_panel, "Login", buttonSize, closeBg, LofiIcon.Login, LoFiTheme.IconLav,
                () => ToggleOverlay(_loginPanel), "账号 / 登录");
            TopLeft(login, PanelWidth - Pad - 30f * 2f - 8f, 12f, 30f, 30f);

            var refresh = UiKit.IconButton(_panel, "Refresh", buttonSize, closeBg, LofiIcon.Refresh, LoFiTheme.IconLav,
                () => _ = _playlist.RefreshAsync(), "刷新歌单");
            TopLeft(refresh, PanelWidth - Pad - 30f * 3f - 16f, 12f, 30f, 30f);

            var list = UiKit.IconButton(_panel, "Playlists", buttonSize, closeBg, LofiIcon.List, LoFiTheme.IconLav,
                () => _ = OpenPlaylistPanelAsync(), "我的歌单");
            TopLeft(list, PanelWidth - Pad - 30f * 4f - 24f, 12f, 30f, 30f);

            _lyricsButton = UiKit.IconButton(_panel, "LyricsToggle", buttonSize, closeBg, LofiIcon.Lyrics, LoFiTheme.IconLav,
                ToggleLyrics, "显示 / 隐藏歌词");
            TopLeft(_lyricsButton, PanelWidth - Pad - 30f * 5f - 32f, 12f, 30f, 30f);

            var divider = UiKit.Panel(_panel, "Divider",
                LoFiTheme.RoundedRect(32, 32, 2, new Color(1f, 1f, 1f, 0.16f), new Color(1f, 1f, 1f, 0.16f)),
                Color.white);
            TopLeft(divider, Pad, 52f, PanelWidth - Pad * 2f, 2f);

            // 黑胶封面：外层容器负责定位，内层图片用中心 pivot ——
            // 否则旋转会绕左上角"公转"，看起来就是转得不对。
            var coverRoot = UiKit.Node(_panel, "CoverRoot", typeof(RectTransform));
            TopLeft(coverRoot, Pad, 68f, 148f, 148f);

            // 黑胶外圈的青→品红渐变环（贴合游戏 UI 的强调色语言）
            var vinylGlow = UiKit.Panel(coverRoot.transform, "VinylGlow",
                LoFiTheme.GradientRing(256, new Color(0f, 0f, 0f, 0f), LoFiTheme.Accent, LoFiTheme.AccentDeep, 3),
                Color.white);
            var glowRect = vinylGlow.rectTransform;
            glowRect.anchorMin = Vector2.zero;
            glowRect.anchorMax = Vector2.one;
            glowRect.offsetMin = new Vector2(-5f, -5f);
            glowRect.offsetMax = new Vector2(5f, 5f);

            var vinyl = UiKit.Panel(coverRoot.transform, "Vinyl", LoFiTheme.Vinyl(256), Color.white);
            var vinylRect = vinyl.rectTransform;
            vinylRect.anchorMin = Vector2.zero;
            vinylRect.anchorMax = Vector2.one;
            vinylRect.offsetMin = Vector2.zero;
            vinylRect.offsetMax = Vector2.zero;
            vinylRect.pivot = new Vector2(0.5f, 0.5f);
            _vinyl = vinylRect;

            // 封面不再用 UGUI 的 Mask：Mask 是按"网格"裁剪的，而圆形贴图在运行时的
            // Tight 网格只有十几个顶点 —— 于是封面被裁成了一个十来条边的多边形。
            // 改成下载后直接在贴图里做圆形 alpha 裁切（见 CreateRoundCoverSprite），
            // 这条子节点只当容器用。
            var coverHolder = UiKit.Node(_vinyl, "CoverMask", typeof(RectTransform));
            var holderRect = UiKit.Rect(coverHolder);
            holderRect.anchorMin = new Vector2(0.5f, 0.5f);
            holderRect.anchorMax = new Vector2(0.5f, 0.5f);
            holderRect.sizeDelta = new Vector2(92f, 92f);
            holderRect.anchoredPosition = Vector2.zero;
            _coverMask = coverHolder;

            var art = UiKit.Panel(coverHolder.transform, "CoverArt", null, Color.white);
            UiKit.Stretch(art.rectTransform);
            art.preserveAspect = true;
            art.raycastTarget = false;
            _coverArt = art;

            // 唱片中心轴孔（画在封面之上，黑胶的"孔"）
            var spindle = UiKit.Panel(coverHolder.transform, "Spindle",
                LoFiTheme.Circle(48, new Color32(0x08, 0x08, 0x10, 0xFF), new Color32(0x40, 0x40, 0x58, 0xE0), 2),
                Color.white);
            var spindleRect = spindle.rectTransform;
            spindleRect.anchorMin = new Vector2(0.5f, 0.5f);
            spindleRect.anchorMax = new Vector2(0.5f, 0.5f);
            spindleRect.sizeDelta = new Vector2(11f, 11f);
            spindleRect.anchoredPosition = Vector2.zero;
            spindle.raycastTarget = false;

            _coverMask.SetActive(false);

            // 歌曲信息
            _titleText = UiKit.Label(_panel, "SongTitle", "等待播放", 19, LoFiTheme.Ink, TextAnchor.UpperLeft, FontStyle.Bold);
            TopLeft(_titleText, Pad + 164f, 72f, PanelWidth - Pad * 2f - 164f, 46f);

            _artistText = UiKit.Label(_panel, "Artist", "—", 14, LoFiTheme.InkSoft, TextAnchor.UpperLeft);
            TopLeft(_artistText, Pad + 164f, 122f, PanelWidth - Pad * 2f - 164f, 22f);

            _qualityText = UiKit.Label(_panel, "Quality", string.Empty, 12, LoFiTheme.AccentDeep, TextAnchor.UpperLeft);
            TopLeft(_qualityText, Pad + 164f, 146f, PanelWidth - Pad * 2f - 164f, 20f);

            // 进度条
            // 第 4 个参数 = 凹槽高度（对齐游戏自带媒体条的"空心圆角凹槽"，约 8~10px）。
            // 填充条单独压到 4px（见下面的 Fill 覆写），这样它才"嵌"在凹槽里，
            // 而不是像之前那样鼓出来一坨 —— 根因是 LofiSlider 里 Fill 的锚点写错了。
            _progress = UiKit.Slider(_panel, "Progress", new Vector2(PanelWidth - Pad * 2f, 18f), 10f, 11f,
                LoFiTheme.Track, LoFiTheme.Accent, LoFiTheme.Ink,
                LoFiTheme.GradientBar(64, 4, 0, LoFiTheme.Accent, LoFiTheme.AccentDeep),
                LoFiTheme.Circle(64, LoFiTheme.Ink, new Color(0.06f, 0.06f, 0.12f, 0.55f), 2),
                LoFiTheme.RoundedRect(64, 10, 4, new Color(1f, 1f, 1f, 0.035f), LoFiTheme.TrackEdge, 2, 0f, 0f, 4));
            _progress.Fill.rectTransform.sizeDelta = new Vector2(0f, 4f);
            TopLeft(_progress.gameObject, Pad, 214f, PanelWidth - Pad * 2f, 18f);
            _progress.Changed += OnProgressDragging;
            _progress.Committed += OnProgressCommitted;

            _positionText = UiKit.Label(_panel, "Position", "00:00", 12, LoFiTheme.InkSoft, TextAnchor.MiddleLeft);
            TopLeft(_positionText, Pad, 234f, 100f, 20f);

            _durationText = UiKit.Label(_panel, "Duration", "00:00", 12, LoFiTheme.InkSoft, TextAnchor.MiddleRight);
            TopLeft(_durationText, PanelWidth - Pad - 100f, 234f, 100f, 20f);

            // 控制区
            // 描边改成游戏原生按钮实测的淡紫（#9292B5），图标也跟着用淡紫白，
            // 否则一排纯白图标会比游戏自己的按钮亮一档，看着就不像同一套 UI。
            var circleBg = LoFiTheme.Circle(64, LoFiTheme.PaperSoft, LoFiTheme.RingLav, 2);
            // 播放键：**透明底 + 青→品红渐变描边 + 白色图形**，和游戏底部那颗播放键一模一样。
            // （之前是纯白实心圆盘 + 深色图形，和游戏风格差得最远。）
            var accentBg = LoFiTheme.GradientRing(96, new Color32(0x10, 0x10, 0x20, 0xB4),
                LoFiTheme.Accent, LoFiTheme.AccentDeep, 5);

            _modeButton = UiKit.IconButton(_panel, "Mode", new Vector2(40f, 40f), circleBg, LofiIcon.RepeatAll,
                LoFiTheme.IconLav, CycleMode, "播放模式");
            TopLeft(_modeButton, Pad, 276f, 40f, 40f);

            var prev = UiKit.IconButton(_panel, "Prev", new Vector2(46f, 46f), circleBg, LofiIcon.Prev,
                LoFiTheme.IconLav, () => _ = _playlist.PrevAsync(), "上一首");
            TopLeft(prev, Pad + 54f, 273f, 46f, 46f);

            _playButton = UiKit.IconButton(_panel, "Play", new Vector2(58f, 58f), accentBg, LofiIcon.Play,
                LoFiTheme.Ink, () => _playlist.TogglePlayPause(), "播放 / 暂停", 0.56f);
            TopLeft(_playButton, Pad + 110f, 267f, 58f, 58f);

            var next = UiKit.IconButton(_panel, "Next", new Vector2(46f, 46f), circleBg, LofiIcon.Next,
                LoFiTheme.IconLav, () => _ = _playlist.NextAsync(), "下一首");
            TopLeft(next, Pad + 178f, 273f, 46f, 46f);

            var volumeIcon = UiKit.Panel(_panel, "VolumeIcon", LoFiTheme.Icon(LofiIcon.Volume), LoFiTheme.IconLav);
            TopLeft(volumeIcon, Pad + 248f, 286f, 24f, 24f);

            _volume = UiKit.Slider(_panel, "Volume", new Vector2(110f, 18f), 10f, 10f,
                LoFiTheme.Track, LoFiTheme.AccentDeep, LoFiTheme.Ink,
                LoFiTheme.GradientBar(64, 4, 0, LoFiTheme.Accent, LoFiTheme.AccentDeep),
                LoFiTheme.Circle(64, LoFiTheme.Ink, new Color(0.06f, 0.06f, 0.12f, 0.55f), 2),
                LoFiTheme.RoundedRect(64, 10, 4, new Color(1f, 1f, 1f, 0.035f), LoFiTheme.TrackEdge, 2, 0f, 0f, 4));
            _volume.Fill.rectTransform.sizeDelta = new Vector2(0f, 4f);
            TopLeft(_volume.gameObject, PanelWidth - Pad - 110f, 289f, 110f, 18f);
            _volume.Value = _settings.Volume.Value;
            _volume.Changed += v => _audio.Volume = v;
            _volume.Committed += v => _playlist.SetVolume(v);

            // 歌词
            _lyricRoot = UiKit.Node(_panel, "Lyrics", typeof(RectTransform));
            var lyricRootRect = UiKit.Rect(_lyricRoot);
            lyricRootRect.anchorMin = Vector2.zero;
            lyricRootRect.anchorMax = Vector2.one;
            lyricRootRect.offsetMin = Vector2.zero;
            lyricRootRect.offsetMax = Vector2.zero;

            var lyricPanel = UiKit.Panel(_lyricRoot.transform, "LyricPanel",
                LoFiTheme.RoundedRect(64, 64, 18, new Color(1f, 1f, 1f, 0.05f), new Color(1f, 1f, 1f, 0.14f), 1),
                Color.white);
            TopLeft(lyricPanel, Pad, 344f, PanelWidth - Pad * 2f, 150f);

            _lyricCurrent = UiKit.Label(lyricPanel.transform, "Current", string.Empty, 16, LoFiTheme.Ink, TextAnchor.MiddleCenter);
            TopLeft(_lyricCurrent, 10f, 30f, PanelWidth - Pad * 2f - 20f, 44f);

            _lyricNext = UiKit.Label(lyricPanel.transform, "Next", string.Empty, 13, LoFiTheme.InkSoft, TextAnchor.UpperCenter);
            TopLeft(_lyricNext, 10f, 78f, PanelWidth - Pad * 2f - 20f, 60f);

            // 歌单信息 / 状态 / 提示
            _playlistName = UiKit.Label(_panel, "PlaylistName", "歌单：未加载", 12, LoFiTheme.InkSoft, TextAnchor.MiddleLeft);
            TopLeft(_playlistName, Pad, 502f, PanelWidth - Pad * 2f, 20f);

            _statusText = UiKit.Label(_panel, "Status", "准备就绪", 13, LoFiTheme.InkSoft, TextAnchor.UpperLeft);
            TopLeft(_statusText, Pad, 522f, PanelWidth - Pad * 2f, 44f);

            _toastText = UiKit.Label(_panel, "Toast", string.Empty, 13, LoFiTheme.AccentDeep, TextAnchor.MiddleLeft);
            TopLeft(_toastText, Pad, 572f, PanelWidth - Pad * 2f, 26f);

            BuildLoginPanel();
            BuildPlaylistPanel();
        }

        private void BuildLoginPanel()
        {
            var panel = UiKit.Panel(_panel, "LoginPanel",
                LoFiTheme.GradientRoundedRect(360, 360, 22, new Color(0.06f, 0.06f, 0.12f, 0.97f),
                    LoFiTheme.Accent, LoFiTheme.AccentDeep, 2),
                Color.white, true);
            var rect = panel.rectTransform;
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(16f, 16f);
            rect.offsetMax = new Vector2(-16f, -16f);
            _loginPanel = panel.gameObject;

            var title = UiKit.Label(panel.transform, "Title", "QQ 音乐登录", 18, LoFiTheme.Ink, TextAnchor.MiddleCenter, FontStyle.Bold);
            TopLeft(title, 0f, 18f, PanelWidth - 32f, 26f);

            // 注意顺序：背景先建，RawImage 后建，否则二维码会被白底盖住（UGUI 子节点后绘制）。
            var qrContainer = UiKit.Node(panel.transform, "QrContainer", typeof(RectTransform));
            TopLeft(qrContainer, 106f, 56f, 186f, 186f);

            var qrBg = UiKit.Panel(qrContainer.transform, "QrBg",
                LoFiTheme.RoundedRect(64, 64, 16, Color.white, LoFiTheme.Track, 2), Color.white);
            UiKit.Stretch(qrBg.rectTransform);

            var qr = UiKit.Node(qrContainer.transform, "Qr", typeof(RectTransform), typeof(RawImage));
            UiKit.Stretch(UiKit.Rect(qr));
            _qrImage = qr.GetComponent<RawImage>();
            _qrImage.color = Color.white;

            _loginStatus = UiKit.Label(panel.transform, "Status", "未登录", 13, LoFiTheme.InkSoft, TextAnchor.MiddleCenter);
            TopLeft(_loginStatus, 16f, 246f, PanelWidth - 64f, 46f);

            var qrButton = UiKit.TextButton(panel.transform, "StartQr", "获取二维码", 14, new Vector2(140f, 34f),
                LoFiTheme.Accent, LoFiTheme.Paper, () => _ = _login.StartQrLoginAsync());
            TopLeft(qrButton, 40f, 296f, 130f, 32f);

            var logoutButton = UiKit.TextButton(panel.transform, "Logout", "退出登录", 14, new Vector2(110f, 32f),
                LoFiTheme.PaperDeep, LoFiTheme.Ink, () => _ = _login.LogoutAsync());
            TopLeft(logoutButton, 178f, 296f, 110f, 32f);

            // 扫码接口现在被腾讯 403 风控拦掉，浏览器 Cookie 才是可靠路径，把它做成显眼按钮。
            var openBrowser = UiKit.TextButton(panel.transform, "OpenBrowser", "打开浏览器登录", 13, new Vector2(150f, 30f),
                LoFiTheme.PaperSoft, LoFiTheme.Ink, () =>
                {
                    Application.OpenURL("https://y.qq.com/");
                    ShowToast("已打开浏览器：登录后按 F12 复制 Cookie 再回来导入", false, 6f);
                });
            TopLeft(openBrowser, 40f, 334f, 150f, 30f);

            var pasteButton = UiKit.TextButton(panel.transform, "PasteCookie", "从剪贴板导入", 13, new Vector2(140f, 30f),
                LoFiTheme.Accent, LoFiTheme.Paper, () =>
                {
                    var clip = GUIUtility.systemCopyBuffer;
                    if (string.IsNullOrWhiteSpace(clip))
                    {
                        ShowToast("剪贴板是空的：请先在浏览器里复制 Cookie", true, 5f);
                        return;
                    }
                    _ = _login.ImportCookieHeaderAsync(clip);
                });
            TopLeft(pasteButton, 198f, 334f, 140f, 30f);

            var hint = UiKit.Label(panel.transform, "Hint",
                "推荐：① 点「打开浏览器登录」在 y.qq.com 登录　② F12 → Network → 刷新页面 → 点任意请求 → "
                + "Request Headers 里复制整行 Cookie（必须含 qm_keyst）　③ 回来点「从剪贴板导入」",
                12, LoFiTheme.InkSoft, TextAnchor.UpperLeft);
            TopLeft(hint, 40f, 368f, PanelWidth - 96f, 52f);

            _cookieInput = UiKit.Input(panel.transform, "CookieInput", "uin=o0123456; qm_keyst=...; qqmusic_key=...",
                12, new Vector2(PanelWidth - 112f, 32f));
            TopLeft(_cookieInput.gameObject, 40f, 424f, PanelWidth - 112f, 30f);

            var importButton = UiKit.TextButton(panel.transform, "Import", "导入输入框内容", 13, new Vector2(140f, 30f),
                LoFiTheme.AccentDeep, LoFiTheme.Paper, () =>
                {
                    var value = _cookieInput != null ? _cookieInput.text : string.Empty;
                    _ = _login.ImportCookieHeaderAsync(value);
                    if (_cookieInput != null) _cookieInput.text = string.Empty;
                });
            TopLeft(importButton, 40f, 460f, 140f, 30f);

            var closeButton = UiKit.TextButton(panel.transform, "Close", "关闭", 13, new Vector2(90f, 30f),
                LoFiTheme.PaperDeep, LoFiTheme.Ink, () => ToggleOverlay(_loginPanel, false));
            TopLeft(closeButton, 190f, 460f, 90f, 30f);

            _loginPanel.SetActive(false);
        }

        private void BuildPlaylistPanel()
        {
            var panel = UiKit.Panel(_panel, "PlaylistPanel",
                LoFiTheme.GradientRoundedRect(360, 360, 22, new Color(0.06f, 0.06f, 0.12f, 0.97f),
                    LoFiTheme.Accent, LoFiTheme.AccentDeep, 2),
                Color.white, true);
            var rect = panel.rectTransform;
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(16f, 16f);
            rect.offsetMax = new Vector2(-16f, -16f);
            _playlistPanel = panel.gameObject;

            var title = UiKit.Label(panel.transform, "Title", "我的歌单", 18, LoFiTheme.Ink, TextAnchor.MiddleCenter, FontStyle.Bold);
            TopLeft(title, 0f, 18f, PanelWidth - 32f, 26f);

            _playlistPanelStatus = UiKit.Label(panel.transform, "Status", "需要先扫码登录", 13, LoFiTheme.InkSoft, TextAnchor.MiddleCenter);
            TopLeft(_playlistPanelStatus, 16f, 50f, PanelWidth - 64f, 24f);

            // ---- 在游戏内绑定歌单（不依赖 cfg）----
            // 两行输入：歌单（ID / 短码 / 分享链接）+ 用户UID（未登录时用来列歌单）。
            _playlistIdInput = UiKit.Input(panel.transform, "PlaylistIdInput",
                "歌单 ID / 分享链接 / 短码", 13, new Vector2(252f, 32f));
            TopLeft(_playlistIdInput, 36f, 72f, 252f, 32f);
            _playlistIdInput.text = _settings.ResolvePlaylistId();

            var bindButton = UiKit.TextButton(panel.transform, "BindPlaylist", "绑定", 13,
                new Vector2(68f, 32f), LoFiTheme.Accent, LoFiTheme.Paper, BindPlaylistFromInput);
            TopLeft(bindButton, 294f, 72f, 68f, 32f);

            _userUidInput = UiKit.Input(panel.transform, "UserUidInput",
                "用户 UID（未登录时需要）", 13, new Vector2(252f, 32f));
            TopLeft(_userUidInput, 36f, 110f, 252f, 32f);
            _userUidInput.text = _settings.UserUid.Value;

            var uidButton = UiKit.TextButton(panel.transform, "UseUserUid", "列歌单", 13,
                new Vector2(68f, 32f), LoFiTheme.PaperSoft, LoFiTheme.Ink, ApplyUserUidFromInput);
            TopLeft(uidButton, 294f, 110f, 68f, 32f);

            var listRoot = UiKit.Node(panel.transform, "List", typeof(RectTransform));
            _playlistListRoot = UiKit.Rect(listRoot);
            TopLeft(listRoot, 40f, 150f, PanelWidth - 112f, 310f);

            var clearButton = UiKit.TextButton(panel.transform, "ClearCache", "清空音频缓存", 13, new Vector2(150f, 32f),
                LoFiTheme.PaperSoft, LoFiTheme.Ink, () =>
                {
                    _cache.ClearAll();
                    ShowToast("本地音频缓存已清空", false);
                });
            TopLeft(clearButton, 40f, 472f, 150f, 32f);

            var closeButton = UiKit.TextButton(panel.transform, "Close", "关闭", 14, new Vector2(90f, 32f),
                LoFiTheme.PaperDeep, LoFiTheme.Ink, () => ToggleOverlay(_playlistPanel, false));
            TopLeft(closeButton, 40f, 508f, 90f, 32f);

            _playlistPanel.SetActive(false);
        }

        // ------------------------------------------------------------------ 事件订阅

        /// <summary>
        /// 退出前主动释放：停掉在途的封面下载（UnityWebRequest）并停止刷新。
        /// 不销毁 Canvas —— 交给 Unity 自己拆，我们只管把"可能挡住退出的东西"放掉。
        /// </summary>
        internal void PrepareForShutdown()
        {
            Plugin.Log?.LogInfo("  └ UI：停止刷新（封面请求=" + (_coverRequest != null ? "在途" : "无") + "）");
            Plugin.Trace("UI：停止刷新（封面请求=" + (_coverRequest != null ? "在途" : "无") + "）");

            _built = false;                 // Tick / TickExternal 立刻变成空操作

            if (_coverRoutine != null)
            {
                try { StopCoroutine(_coverRoutine); } catch { /* 忽略 */ }
                _coverRoutine = null;
            }

            if (_coverRequest != null)
            {
                try { _coverRequest.Abort(); } catch { /* 忽略 */ }
                try { _coverRequest.Dispose(); } catch { /* 忽略 */ }
                _coverRequest = null;
            }
            Plugin.Trace("UI：已释放封面请求。");
        }

        private void Subscribe()
        {
            _audio.StateChanged += OnPlayerStateChanged;
            _audio.BufferProgress += OnBufferProgress;
            _playlist.SongChanged += OnSongChanged;
            _playlist.PlaylistUpdated += OnPlaylistUpdated;
            _playlist.LyricsUpdated += OnLyricsUpdated;
            _playlist.Notice += OnNotice;
            _playlist.BusyChanged += OnBusyChanged;
            _login.StateChanged += OnLoginStateChanged;
            _login.QrCodeReady += OnQrCodeReady;
        }

        private void OnDestroy()
        {
            if (_audio != null)
            {
                _audio.StateChanged -= OnPlayerStateChanged;
                _audio.BufferProgress -= OnBufferProgress;
            }
            if (_playlist != null)
            {
                _playlist.SongChanged -= OnSongChanged;
                _playlist.PlaylistUpdated -= OnPlaylistUpdated;
                _playlist.LyricsUpdated -= OnLyricsUpdated;
                _playlist.Notice -= OnNotice;
                _playlist.BusyChanged -= OnBusyChanged;
            }
            if (_login != null)
            {
                _login.StateChanged -= OnLoginStateChanged;
                _login.QrCodeReady -= OnQrCodeReady;
            }

            if (_coverRequest != null) { _coverRequest.Dispose(); _coverRequest = null; }
            if (_qrTexture != null) Destroy(_qrTexture);
        }

        // ------------------------------------------------------------------ 主循环

        private void Update()
        {
            Tick("Update");
        }

        /// <summary>外部（看门狗兜底循环）调用的心跳；同一帧不会重复处理。</summary>
        internal void TickExternal() => Tick("兜底");

        internal bool IsHealthy => _built && _canvas != null && _panel != null;

        private int _lastTickFrame = -1;

        private void Tick(string source)
        {
            if (!_built) return;
            if (Time.frameCount == _lastTickFrame) return;
            _lastTickFrame = Time.frameCount;

            EnsureEventSystem();
            UpdateFade();
            UpdateCoverRotation();
            UpdateProgress();
            UpdateLyrics();
            UpdateToast();
        }

        private void EnsureEventSystem()
        {
            if (_eventSystemCreated) return;
            if (EventSystem.current != null)
            {
                _eventSystemCreated = true;   // 游戏自带，别抢
                return;
            }
            var go = new GameObject("ChillQQMusicEventSystem");
            go.hideFlags = HideFlags.DontSave;
            DontDestroyOnLoad(go);
            go.AddComponent<EventSystem>();
            go.AddComponent<StandaloneInputModule>();
            _eventSystemCreated = true;
            Plugin.Log?.LogInfo("已创建 EventSystem（游戏当前没有）。");
        }

        private void UpdateFade()
        {
            var pointer = (Vector2)Input.mousePosition;
            var near = IsPointerNearPanel(pointer);
            if (near) _showUntil = Time.unscaledTime + Mathf.Max(1f, _settings.FadeDelaySeconds.Value);

            var opacity = Mathf.Clamp01(_settings.UiOpacity.Value);
            var idle = Mathf.Clamp01(_settings.UiIdleOpacity.Value);
            var keepVisible = !_settings.IdleFade.Value || near || Time.unscaledTime < _showUntil;
            var target = !_visible ? 0f : (keepVisible ? opacity : idle);

            _group.alpha = Mathf.MoveTowards(_group.alpha, target, Time.unscaledDeltaTime * 2.2f);
            // 几乎透明时不要吃鼠标事件，避免挡住游戏本身的点击。
            _group.blocksRaycasts = _group.alpha > 0.55f;
            _group.interactable = _group.alpha > 0.55f;
        }

        private bool IsPointerNearPanel(Vector2 screenPoint)
        {
            if (_panel == null) return false;
            var corners = new Vector3[4];
            _panel.GetWorldCorners(corners);
            const float margin = 48f;
            return screenPoint.x >= corners[0].x - margin && screenPoint.x <= corners[2].x + margin
                && screenPoint.y >= corners[0].y - margin && screenPoint.y <= corners[2].y + margin;
        }

        private void UpdateCoverRotation()
        {
            if (_vinyl == null) return;
            if (_audio != null && _audio.IsPlaying) _coverAngle += Time.unscaledDeltaTime * 9f;
            if (_coverAngle > 360f) _coverAngle -= 360f;
            _vinyl.localRotation = Quaternion.Euler(0f, 0f, _coverAngle);
        }

        private void UpdateProgress()
        {
            if (_progress == null || _audio == null) return;

            var length = _audio.Length;
            var position = _audio.Position;

            if (length <= 0.1f)
            {
                _positionText.text = "00:00";
                _durationText.text = "00:00";
                return;
            }

            if (!_progressDragging) _progress.SetValueWithoutNotify(position / length);
            _positionText.text = FormatTime(position);
            _durationText.text = FormatTime(length);
        }

        private bool _progressDragging;

        private void OnProgressDragging(float value)
        {
            _progressDragging = true;
            if (_audio != null && _audio.Length > 0.1f)
                _positionText.text = FormatTime(value * _audio.Length);
        }

        private void OnProgressCommitted(float value)
        {
            _progressDragging = false;
            if (_playlist != null) _playlist.Seek01(value);
        }

        private void UpdateLyrics()
        {
            if (_lyricCurrent == null) return;

            var lines = _lyrics?.Lines;
            if (lines == null || lines.Count == 0)
            {
                if (_lastLyricIndex != -1)
                {
                    _lastLyricIndex = -1;
                    _lyricCurrent.text = _audio != null && _audio.CurrentSong != null ? "纯音乐，请欣赏" : string.Empty;
                    _lyricNext.text = string.Empty;
                }
                return;
            }

            var index = LyricsParser.FindIndex(lines, _audio != null ? _audio.Position : 0d);
            if (index == _lastLyricIndex) return;
            _lastLyricIndex = index;

            _lyricCurrent.text = index >= 0 ? lines[index].Display : string.Empty;
            _lyricNext.text = index >= 0 && index + 1 < lines.Count ? lines[index + 1].Display : string.Empty;
        }

        private void UpdateToast()
        {
            if (_toastText == null) return;
            if (_toastUntil > 0f && Time.unscaledTime > _toastUntil)
            {
                _toastUntil = 0f;
                _toastText.text = string.Empty;
            }
        }

        // ------------------------------------------------------------------ 交互

        internal void ToggleVisible()
        {
            // 关键体验细节：如果当前是隐藏状态，或者已经淡到几乎看不见，
            // 第一次按热键一定按"显示"处理，避免"按了没反应"的错觉。
            var nearlyInvisible = _group == null || _group.alpha < 0.3f;
            if (!_visible || nearlyInvisible)
            {
                _visible = true;
                _showUntil = Time.unscaledTime + 6f;
            }
            else
            {
                _visible = false;
                if (_loginPanel != null) _loginPanel.SetActive(false);
                if (_playlistPanel != null) _playlistPanel.SetActive(false);
            }

            ClampIntoView();
            Plugin.Log?.LogInfo("悬浮窗切换：" + (_visible ? "显示" : "隐藏")
                + "（热键 " + _settings.HotkeyToggleUi.Value + "）");
            LogUiState("热键");
        }

        private void ToggleLyrics()
        {
            _settings.ShowLyrics.Value = !_settings.ShowLyrics.Value;
            _settings.Save();
            if (_lyricRoot != null) _lyricRoot.SetActive(_settings.ShowLyrics.Value);
        }

        private void CycleMode()
        {
            var mode = _playlist.Mode;
            var next = mode == PlayMode.Sequential ? PlayMode.RepeatOne
                : mode == PlayMode.RepeatOne ? PlayMode.Shuffle : PlayMode.Sequential;
            _playlist.Mode = next;
            RefreshModeIcon();
        }

        private void ToggleOverlay(GameObject overlay, bool? force = null)
        {
            if (overlay == null) return;
            var target = force ?? !overlay.activeSelf;
            overlay.SetActive(target);
            if (target)
            {
                _visible = true;
                _showUntil = Time.unscaledTime + 30f;
            }
        }

        private void OnPanelDragged(Vector2 anchoredPosition)
        {
            _settings.UiPosX.Value = anchoredPosition.x;
            _settings.UiPosY.Value = anchoredPosition.y;
            _settings.Save();
        }

        internal void ApplyConfig()
        {
            if (_panel == null) return;
            _panel.anchoredPosition = new Vector2(_settings.UiPosX.Value, _settings.UiPosY.Value);
            _panel.localScale = Vector3.one * Mathf.Clamp(_settings.UiScale.Value, 0.5f, 2.5f);
            _group.alpha = Mathf.Clamp01(_settings.UiOpacity.Value);
            if (_lyricRoot != null) _lyricRoot.SetActive(_settings.ShowLyrics.Value);
            if (_volume != null) _volume.Value = _settings.Volume.Value;
            if (_settings.ShowOnStartSeconds.Value > 0f)
                _showUntil = Time.unscaledTime + _settings.ShowOnStartSeconds.Value;
            RefreshModeIcon();
        }

        private void RefreshModeIcon()
        {
            if (_modeButton == null || _playlist == null) return;
            switch (_playlist.Mode)
            {
                case PlayMode.RepeatOne: UiKit.SetIcon(_modeButton, LofiIcon.RepeatOne); break;
                case PlayMode.Shuffle: UiKit.SetIcon(_modeButton, LofiIcon.Shuffle); break;
                default: UiKit.SetIcon(_modeButton, LofiIcon.RepeatAll); break;
            }
        }

        private void RefreshHeaderTexts()
        {
            var bound = _settings.ResolvePlaylistId();
            var hasUid = !string.IsNullOrWhiteSpace(_settings.UserUid.Value);

            if (_statusText != null)
                _statusText.text = string.IsNullOrEmpty(bound) && !hasUid
                    ? "还没绑定歌单：点右上角「歌单」按钮，填歌单 ID 后点「绑定」"
                    : "按 " + _settings.HotkeyToggleUi.Value + " 显示/隐藏　·　拖动顶部标题栏移动窗口";

            if (_playlistName != null)
                _playlistName.text = string.IsNullOrEmpty(bound)
                    ? (hasUid ? "歌单：按用户UID加载" : "歌单：未绑定（点 ≡ 按钮绑定）")
                    : "歌单：" + bound;

            if (_qualityText != null) _qualityText.text = "音质：" + _settings.Quality.Value;
            RefreshModeIcon();
        }

        // ------------------------------------------------------------------ 事件响应

        private void OnPlayerStateChanged(PlayerState state, string message)
        {
            if (!_built) return;
            UiKit.SetIcon(_playButton, state == PlayerState.Playing ? LofiIcon.Pause : LofiIcon.Play);
            if (!string.IsNullOrEmpty(message)) SetStatus(message);
        }

        private void OnBufferProgress(float value)
        {
            if (!_built || _audio.State != PlayerState.Buffering) return;
            SetStatus("缓冲中 " + Mathf.RoundToInt(value * 100f) + "%");
        }

        private void OnSongChanged(SongInfo song)
        {
            if (!_built) return;
            _titleText.text = string.IsNullOrEmpty(song.Title) ? "未知歌曲" : song.Title;
            _artistText.text = string.IsNullOrEmpty(song.Artist) ? "未知歌手" : song.Artist;
            _qualityText.text = string.IsNullOrEmpty(song.Album)
                ? "音质：" + _settings.Quality.Value
                : song.Album + "　·　" + _settings.Quality.Value;
            _lyrics = null;
            _lastLyricIndex = -2;
            StartCoverLoad(song.CoverUrl);
        }

        private void OnPlaylistUpdated(PlaylistInfo playlist)
        {
            if (!_built || playlist == null) return;
            _playlistName.text = "歌单：" + playlist.Name + "（" + playlist.Songs.Count + " 首）";
            SetStatus("歌单已加载");
        }

        private void OnLyricsUpdated(Lyrics lyrics)
        {
            _lyrics = lyrics;
            _lastLyricIndex = -2;
        }

        private void OnNotice(string message, bool isError)
        {
            if (!_built) return;
            SetStatus(message);
            ShowToast(message, isError);

            // 播放地址失败多半是因为没登录 —— 直接把登录面板弹出来，省得用户找不到入口。
            if (isError && message.Contains("登录"))
            {
                ToggleOverlay(_loginPanel, true);
                if (_loginStatus != null && !_login.IsLoggedIn)
                    _loginStatus.text = "扫码登录后才能获取播放地址";
            }
        }

        private void OnBusyChanged(bool busy)
        {
            if (!_built) return;
            if (busy) SetStatus("正在获取播放地址…");
        }

        private void OnLoginStateChanged(LoginState state, string message)
        {
            if (!_built) return;
            if (_loginStatus != null) _loginStatus.text = message;
            if (state == LoginState.LoggedIn)
            {
                ShowToast("登录成功，可以访问私人歌单了", false);
                if (_playlistPanelStatus != null) _playlistPanelStatus.text = "登录成功，可以刷新歌单列表";
                // 登录后只刷新歌单，不自动播放（用户点了播放才出声）
                _ = _playlist.RefreshAsync(autoPlayIfIdle: false);
            }
            else if (state == LoginState.Failed)
            {
                ShowToast(message, true);
                ToggleOverlay(_loginPanel, true);
            }
        }

        private void OnQrCodeReady(Texture2D texture)
        {
            if (_qrTexture != null) Destroy(_qrTexture);
            _qrTexture = texture;
            if (_qrImage != null) _qrImage.texture = texture;
            ToggleOverlay(_loginPanel, true);
        }

        internal void SetStatus(string message)
        {
            if (_statusText != null) _statusText.text = message;
        }

        internal void ShowToast(string message, bool isError, float seconds = 4f)
        {
            if (_toastText == null) return;
            _toastText.color = isError ? new Color(1f, 0.46f, 0.52f, 1f) : LoFiTheme.Accent;
            _toastText.text = message;
            _toastUntil = Time.unscaledTime + Mathf.Max(1.5f, seconds);
            _showUntil = Time.unscaledTime + Mathf.Max(3f, seconds);
        }

        // ------------------------------------------------------------------ 封面

        private void StartCoverLoad(string url)
        {
            if (_coverRoutine != null)
            {
                StopCoroutine(_coverRoutine);
                _coverRoutine = null;
            }
            _coverRoutine = StartCoroutine(LoadCoverRoutine(url));
        }

        private IEnumerator LoadCoverRoutine(string url)
        {
            if (string.IsNullOrEmpty(url))
            {
                ApplyCoverSprite(null);
                yield break;
            }

            if (_coverRequest != null)
            {
                _coverRequest.Dispose();
                _coverRequest = null;
            }

            // 第二个参数 nonReadable 必须是 false，否则下面拿不到像素、没法做圆形裁切。
            var request = UnityWebRequestTexture.GetTexture(url, false);
            request.timeout = 15;
            _coverRequest = request;
            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                Plugin.Log?.LogDebug("封面下载失败: " + request.error);
                ApplyCoverSprite(null);
                yield break;
            }

            var texture = DownloadHandlerTexture.GetContent(request);
            if (texture == null)
            {
                ApplyCoverSprite(null);
                yield break;
            }

            var sprite = CreateRoundCoverSprite(texture);
            Destroy(texture);   // 原始方形贴图不再需要，避免显存泄漏
            if (sprite == null)
            {
                ApplyCoverSprite(null);
                yield break;
            }
            ApplyCoverSprite(sprite);
        }

        /// <summary>
        /// 把下载到的方形封面转成"切成圆形"的贴图。
        /// 直接用 UGUI Mask 会得到多边形边缘（Mask 按网格裁剪），所以在贴图阶段裁最靠谱。
        /// </summary>
        private static Sprite CreateRoundCoverSprite(Texture2D source)
        {
            if (source == null) return null;

            Color32[] pixels;
            try
            {
                pixels = source.GetPixels32();
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("封面贴图不可读，跳过圆形裁切: " + e.Message);
                return null;
            }

            if (pixels == null || pixels.Length < 4) return null;

            var side = Mathf.Min(source.width, source.height);
            var outSide = Mathf.Clamp(side, 32, 256);          // 最大 256，够用了
            var offsetX = (source.width - side) / 2;
            var offsetY = (source.height - side) / 2;
            var center = outSide * 0.5f;
            var radius = center - 0.5f;
            var scale = side / (float)outSide;

            var buffer = new Color32[outSide * outSide];
            for (var y = 0; y < outSide; y++)
            {
                var sy = Mathf.Clamp(offsetY + (int)((y + 0.5f) * scale), 0, source.height - 1);
                for (var x = 0; x < outSide; x++)
                {
                    var sx = Mathf.Clamp(offsetX + (int)((x + 0.5f) * scale), 0, source.width - 1);
                    var color = pixels[sy * source.width + sx];

                    var dx = x + 0.5f - center;
                    var dy = y + 0.5f - center;
                    var coverage = Mathf.Clamp01(radius + 0.5f - Mathf.Sqrt(dx * dx + dy * dy));
                    color.a = (byte)Mathf.Clamp(color.a * coverage, 0f, 255f);
                    buffer[y * outSide + x] = color;
                }
            }

            var texture = new Texture2D(outSide, outSide, TextureFormat.RGBA32, false);
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.filterMode = FilterMode.Bilinear;
            texture.SetPixels32(buffer);
            texture.Apply(false, false);

            return Sprite.Create(texture, new Rect(0, 0, outSide, outSide),
                new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect);
        }

        private void ApplyCoverSprite(Sprite sprite)
        {
            if (_coverArt == null) return;
            if (_coverSprite != null)
            {
                var oldTexture = _coverSprite.texture;
                Destroy(_coverSprite);
                if (oldTexture != null) Destroy(oldTexture);
            }

            _coverSprite = sprite;
            _coverArt.sprite = sprite;
            _coverArt.color = sprite == null ? new Color(1f, 1f, 1f, 0f) : Color.white;
            if (_coverMask != null) _coverMask.SetActive(sprite != null);
        }

        // ------------------------------------------------------------------ 歌单列表

        private async System.Threading.Tasks.Task OpenPlaylistPanelAsync()
        {
            ToggleOverlay(_playlistPanel, true);
            ClearChildren(_playlistListRoot);

            // 每次打开都把输入框同步成当前绑定，避免显示的是旧值
            if (_playlistIdInput != null) _playlistIdInput.text = _settings.ResolvePlaylistId();
            if (_userUidInput != null) _userUidInput.text = _settings.UserUid.Value;

            var hasIdentity = _login.IsLoggedIn || !string.IsNullOrWhiteSpace(_settings.UserUid.Value);
            if (!hasIdentity)
            {
                _playlistPanelStatus.text = "需要先「登录」，或在上面填「用户UID」";
                return;
            }

            _playlistPanelStatus.text = "正在获取歌单列表…";
            try
            {
                _playlistListCts?.Cancel();
                _playlistListCts = new CancellationTokenSource(TimeSpan.FromSeconds(15));
                var identity = _login.IsLoggedIn ? _login.User.Uin : _settings.UserUid.Value;
                var list = await Plugin.Music.GetUserPlaylistsAsync(identity, _playlistListCts.Token)
                    .ConfigureAwait(false);

                MainThreadDispatcher.Post(() => RenderPlaylistButtons(list));
            }
            catch (Exception e)
            {
                MainThreadDispatcher.Post(() => _playlistPanelStatus.text = "获取失败：" + e.Message);
            }
        }

        private void RenderPlaylistButtons(IReadOnlyList<PlaylistSummary> list)
        {
            if (_playlistListRoot == null) return;
            ClearChildren(_playlistListRoot);

            if (list == null || list.Count == 0)
            {
                _playlistPanelStatus.text = "没读到歌单：请在上面填「歌单 ID / 分享链接」后点「绑定」";
                return;
            }

            _playlistPanelStatus.text = "点击切换（共 " + list.Count + " 个）";
            var y = 0f;
            for (var i = 0; i < list.Count && i < 9; i++)
            {
                var item = list[i];
                var button = UiKit.TextButton(_playlistListRoot, "Item" + i,
                    item.Name + "（" + item.SongCount + "）", 13,
                    new Vector2(PanelWidth - 112f, 34f), LoFiTheme.PaperSoft, LoFiTheme.Ink, () =>
                    {
                        _settings.PlaylistId.Value = item.Id;
                        _settings.PlaylistUrl.Value = string.Empty;
                        _settings.Save();
                        ToggleOverlay(_playlistPanel, false);
                        RefreshHeaderTexts();
                        _ = _playlist.RefreshAsync();
                    });
                TopLeft(button.gameObject, 0f, y, PanelWidth - 112f, 34f);
                y += 40f;
            }
        }

        // ------------------------------------------------------------------ 游戏内绑定

        /// <summary>
        /// 把输入框里的歌单（纯数字 ID / 分享短码 / 完整分享链接）绑定到配置并立即加载。
        /// 解析规则复用 PlaylistManager.ExtractPlaylistId：能从链接里抠出数字 ID 就存 ID，
        /// 抠不出来（比如短码）就原样存下去，交给服务层继续解析。
        /// </summary>
        private void BindPlaylistFromInput()
        {
            var text = _playlistIdInput != null ? (_playlistIdInput.text ?? string.Empty).Trim() : string.Empty;
            if (string.IsNullOrEmpty(text))
            {
                ShowToast("请先填写歌单 ID 或分享链接", true);
                return;
            }

            var id = PlaylistManager.ExtractPlaylistId(text);
            if (string.IsNullOrEmpty(id)) id = text;

            _settings.PlaylistId.Value = id;
            _settings.PlaylistUrl.Value = string.Empty;   // 避免旧的链接盖住新绑定的 ID
            _settings.Save();

            Plugin.Log?.LogInfo("在游戏内绑定歌单：" + id);
            ShowToast("已绑定歌单，正在加载…", false);
            ToggleOverlay(_playlistPanel, false);
            RefreshHeaderTexts();
            _ = _playlist.RefreshAsync();
        }

        /// <summary>保存输入框里的用户UID，并用它去列歌单（未登录时的备用通道）。</summary>
        private void ApplyUserUidFromInput()
        {
            var uid = _userUidInput != null ? (_userUidInput.text ?? string.Empty).Trim() : string.Empty;
            _settings.UserUid.Value = uid;
            _settings.Save();

            Plugin.Log?.LogInfo("在游戏内设置用户UID：" + (string.IsNullOrEmpty(uid) ? "(已清空)" : uid));
            ShowToast(string.IsNullOrEmpty(uid) ? "已清空用户UID" : "已保存用户UID，正在读取歌单列表…", false);
            _ = OpenPlaylistPanelAsync();
        }

        private static void ClearChildren(RectTransform root)
        {
            if (root == null) return;
            for (var i = root.childCount - 1; i >= 0; i--)
                Destroy(root.GetChild(i).gameObject);
        }

        // ------------------------------------------------------------------ 工具

        private static RectTransform TopLeft(Component component, float x, float y, float width, float height)
            => TopLeft(component.gameObject, x, y, width, height);

        private static RectTransform TopLeft(GameObject go, float x, float y, float width, float height)
        {
            var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0f, 1f);
            rect.anchorMax = new Vector2(0f, 1f);
            rect.pivot = new Vector2(0f, 1f);
            rect.anchoredPosition = new Vector2(x, -y);
            rect.sizeDelta = new Vector2(width, height);
            return rect;
        }

        private static string FormatTime(float seconds)
        {
            if (seconds < 0f || float.IsNaN(seconds)) seconds = 0f;
            var total = Mathf.FloorToInt(seconds);
            return (total / 60).ToString("00") + ":" + (total % 60).ToString("00");
        }
    }
}

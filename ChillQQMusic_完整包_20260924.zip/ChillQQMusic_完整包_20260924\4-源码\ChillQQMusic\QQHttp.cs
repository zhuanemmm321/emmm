using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace ChillQQMusic
{
    /// <summary>
    /// QQ 相关 HTTP 的统一入口：共享 CookieContainer、UA、超时与重试策略。
    /// 注意：所有方法都在后台线程执行，调用方负责切回主线程。
    /// </summary>
    internal static class QQHttp
    {
        internal const string UserAgent =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

        internal static readonly CookieContainer Cookies = new CookieContainer();

        private static ConfigManager _settings;
        private static HttpClient _client;
        private static readonly object Sync = new object();

        static QQHttp()
        {
            // 关键：.NET 默认会为 POST 先发 "Expect: 100-continue" 试探，
            // 若服务端不按预期回应，请求就会一直挂着（GET 不受影响）。
            // 插件的取播放地址是 POST，之前"一直没有响应"就是这个原因。
            try
            {
                ServicePointManager.Expect100Continue = false;
                ServicePointManager.DefaultConnectionLimit = 16;
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
            }
            catch (Exception e)
            {
                Debug.LogWarning("[ChillQQMusic] 设置 ServicePointManager 失败: " + e.Message);
            }
        }

        internal static void Configure(ConfigManager settings)
        {
            lock (Sync)
            {
                _settings = settings;
                _client = null;
            }
        }

        internal static ConfigManager Settings => _settings;

        internal static HttpClient Client
        {
            get
            {
                lock (Sync)
                {
                    if (_client == null) _client = CreateClient();
                    return _client;
                }
            }
        }

        private static HttpClient CreateClient()
        {
            var handler = new HttpClientHandler
            {
                UseCookies = true,
                CookieContainer = Cookies,
                AllowAutoRedirect = true,
                AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate,
                MaxAutomaticRedirections = 10
            };

            var client = new HttpClient(handler, disposeHandler: false)
            {
                Timeout = TimeSpan.FromSeconds(Math.Max(5, _settings?.TimeoutSeconds?.Value ?? 15))
            };
            client.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", UserAgent);
            client.DefaultRequestHeaders.TryAddWithoutValidation("Referer", "https://y.qq.com/");
            client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "*/*");
            client.DefaultRequestHeaders.TryAddWithoutValidation("Accept-Language", "zh-CN,zh;q=0.9");
            return client;
        }

        /// <summary>把 "a=1; b=2" 形式的 Cookie 头塞进 CookieContainer。</summary>
        internal static void ApplyCookieHeader(string cookieHeader)
        {
            if (string.IsNullOrWhiteSpace(cookieHeader)) return;

            // 重要：CookieContainer.SetCookies(uri, text) 只接受 "Set-Cookie" 格式，
            // 传入普通的 "Cookie:" 头时它只会存下第一个 name=value，其余全部丢弃！
            // 之前登录态一直不生效就是这个原因，必须逐个 Add。
            var added = 0;
            foreach (var pair in cookieHeader.Split(';'))
            {
                var index = pair.IndexOf('=');
                if (index <= 0) continue;

                var name = pair.Substring(0, index).Trim();
                var value = pair.Substring(index + 1).Trim();
                if (name.Length == 0) continue;

                // ".qq.com" 会匹配所有 qq.com 子域（y.qq.com / u.y.qq.com / c.y.qq.com ...）
                try
                {
                    Cookies.Add(new Cookie(name, value, "/", ".qq.com"));
                    added++;
                }
                catch (Exception e)
                {
                    Plugin.Log?.LogDebug("写入 Cookie 失败 " + name + ": " + e.Message);
                }
            }

            Plugin.Log?.LogInfo("已装载 " + added + " 个 Cookie；"
                + "qm_keyst/qqmusic_key 是否存在: " + HasLoginCookie());
        }

        internal static string BuildCookieHeader()
        {
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var sb = new StringBuilder();
            foreach (var uri in new[] { "https://y.qq.com/", "https://u.y.qq.com/", "https://c.y.qq.com/", "https://i.y.qq.com/" })
            {
                CookieCollection collection;
                try { collection = Cookies.GetCookies(new Uri(uri)); }
                catch { continue; }
                foreach (Cookie cookie in collection)
                {
                    if (!seen.Add(cookie.Name)) continue;
                    if (sb.Length > 0) sb.Append("; ");
                    sb.Append(cookie.Name).Append('=').Append(cookie.Value);
                }
            }
            return sb.ToString();
        }

        internal static bool HasLoginCookie()
        {
            var header = BuildCookieHeader();
            if (string.IsNullOrEmpty(header)) return false;
            return header.IndexOf("qm_keyst", StringComparison.OrdinalIgnoreCase) >= 0
                || header.IndexOf("qqmusic_key", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        /// <summary>带指数退避重试的发送。</summary>
        internal static async Task<HttpResponseMessage> SendAsync(Func<HttpRequestMessage> factory, CancellationToken ct)
        {
            int retries = Math.Max(0, _settings?.RetryCount?.Value ?? 2);
            Exception last = null;

            for (int attempt = 0; attempt <= retries; attempt++)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    using (var request = factory())
                    {
                        // 硬超时兜底：Unity 的 Mono 上 HttpClient 偶发会静默挂住，
                        // 连 HttpClient.Timeout 都不触发。这里用 Task.WhenAny 强制限时，
                        // 保证上层一定能拿到异常而不是无限等待。
                        var timeoutMs = Math.Max(5, _settings?.TimeoutSeconds?.Value ?? 15) * 1000;
                        var sendTask = Client.SendAsync(request, HttpCompletionOption.ResponseContentRead, ct);
                        var finished = await Task.WhenAny(sendTask, Task.Delay(timeoutMs, ct)).ConfigureAwait(false);
                        if (!ReferenceEquals(finished, sendTask))
                            throw new QQMusicException("请求超时（" + timeoutMs / 1000 + " 秒内没有响应）");

                        var response = await sendTask.ConfigureAwait(false);

                        if ((int)response.StatusCode >= 500 && attempt < retries)
                        {
                            response.Dispose();
                            last = new HttpRequestException("服务端错误 HTTP " + (int)response.StatusCode);
                        }
                        else
                        {
                            return response;
                        }
                    }
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    throw;
                }
                catch (TaskCanceledException ex)
                {
                    last = new TimeoutException("请求超时（" + (_settings?.TimeoutSeconds?.Value ?? 15) + " 秒）", ex);
                }
                catch (Exception ex)
                {
                    last = ex;
                }

                if (attempt < retries)
                {
                    var delay = TimeSpan.FromMilliseconds(400 * Math.Pow(2, attempt));
                    try { await Task.Delay(delay, ct).ConfigureAwait(false); }
                    catch (OperationCanceledException) { throw; }
                }
            }

            throw new QQMusicException("网络请求失败：" + (last?.Message ?? "未知错误"), last);
        }

        internal static async Task<string> GetStringAsync(string url, CancellationToken ct, string referer = null)
        {
            using (var response = await SendAsync(() =>
            {
                var req = new HttpRequestMessage(HttpMethod.Get, url);
                if (!string.IsNullOrEmpty(referer)) req.Headers.TryAddWithoutValidation("Referer", referer);
                return req;
            }, ct).ConfigureAwait(false))
            {
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            }
        }

        internal static async Task<string> PostJsonAsync(string url, string json, CancellationToken ct, string referer = null)
        {
            using (var response = await SendAsync(() =>
            {
                var req = new HttpRequestMessage(HttpMethod.Post, url)
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
                req.Headers.ExpectContinue = false;      // 再兜一层，确保不发 100-continue
                if (!string.IsNullOrEmpty(referer)) req.Headers.TryAddWithoutValidation("Referer", referer);
                return req;
            }, ct).ConfigureAwait(false))
            {
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            }
        }
    }
}

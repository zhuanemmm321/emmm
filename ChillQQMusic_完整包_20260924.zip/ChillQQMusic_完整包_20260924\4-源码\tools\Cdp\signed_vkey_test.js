(function () {
  var uin = "1831290549";
  var mid = "000Ms8EM0k35Ms";
  var payload = {
    comm: { ct: 24, cv: 0, format: "json", uin: uin, platform: "yqq.json" },
    req_0: {
      module: "vkey.GetVkeyServer",
      method: "CgiGetVkey",
      param: {
        guid: "1234567890",
        songmid: [mid],
        filename: ["M500" + mid + ".mp3"],
        songtype: [0],
        uin: uin,
        loginflag: 1,
        platform: "20"
      }
    }
  };
  try {
    var body = JSON.stringify(payload);
    var sign = window.__qqsign(body);
    var url = "https://u.y.qq.com/cgi-bin/musicu.fcg?format=json&sign=" + encodeURIComponent(sign);
    var x = new XMLHttpRequest();
    x.open("POST", url, false);
    x.setRequestHeader("Content-Type", "application/json");
    x.send(body);
    var text = x.responseText || "";
    var purl = text.match(/"purl"\s*:\s*"([^"]*)"/);
    var ret = text.match(/"retcode"\s*:\s*(-?\d+)/);
    return "sign=" + sign.slice(0, 12) + "... HTTP " + x.status
      + " retcode=" + (ret ? ret[1] : "?")
      + " purlLen=" + (purl && purl[1] ? purl[1].length : 0)
      + " | " + text.slice(0, 120);
  } catch (e) {
    return "ERR " + e;
  }
})()

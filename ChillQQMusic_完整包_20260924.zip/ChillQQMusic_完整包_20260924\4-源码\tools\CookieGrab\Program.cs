// 开发工具：从 Chromium 系浏览器（Edge/Chrome）的 Cookies 库里读取指定域名下的 Cookie。
// 只读；用于把已有的 y.qq.com 登录态交给 ChillQQMusic 插件。
//
// 用法: CookieGrab.exe "<Cookies 数据库路径>" <域名关键字>
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32.SafeHandles;

internal static class Program
{
    // ---------------------------------------------------------------- 原始共享读

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern SafeFileHandle CreateFileW(string name, uint access, uint share,
        IntPtr securityAttributes, uint creationDisposition, uint flags, IntPtr template);

    private static byte[] ReadEvenIfLocked(string path)
    {
        try { return File.ReadAllBytes(path); }
        catch (IOException) { /* 被浏览器占用，走原始句柄 */ }

        const uint GENERIC_READ = 0x80000000;
        const uint OPEN_EXISTING = 3;
        const uint FILE_ATTRIBUTE_NORMAL = 0x80;

        // 依次尝试：允许读/写/删共享 -> 读/写 -> 只读
        foreach (var share in new uint[] { 7, 3, 1, 0 })
        {
            var handle = CreateFileW(path, GENERIC_READ, share, IntPtr.Zero, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, IntPtr.Zero);
            if (handle.IsInvalid) { handle.Dispose(); continue; }

            using (handle)
            using (var stream = new FileStream(handle, FileAccess.Read))
            using (var memory = new MemoryStream())
            {
                stream.CopyTo(memory);
                return memory.ToArray();
            }
        }

        // 最后尝试复制（部分情况下 Windows 允许复制但不允许直接打开）
        var temp = Path.Combine(Path.GetTempPath(), "cookies_copy_" + Guid.NewGuid().ToString("N") + ".db");
        File.Copy(path, temp, true);
        var data = File.ReadAllBytes(temp);
        File.Delete(temp);
        return data;
    }

    // ---------------------------------------------------------------- SQLite (winsqlite3)

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_open_v2(byte[] filename, out IntPtr db, int flags, IntPtr vfs);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_prepare_v2(IntPtr db, byte[] sql, int numBytes, out IntPtr stmt, IntPtr tail);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_step(IntPtr stmt);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern IntPtr sqlite3_column_text(IntPtr stmt, int index);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern IntPtr sqlite3_column_blob(IntPtr stmt, int index);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_column_bytes(IntPtr stmt, int index);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_finalize(IntPtr stmt);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_close(IntPtr db);

    private static int Main(string[] args)
    {
        if (args.Length < 2)
        {
            Console.WriteLine("usage:");
            Console.WriteLine("  CookieGrab list  <cookiesDb> <domainFilter>");
            Console.WriteLine("  CookieGrab probe <cookiesDb> <domainFilter> [localState]");
            Console.WriteLine("  CookieGrab write <cookiesDb> <domainFilter> <localState> <accountDat>");
            return 2;
        }

        var mode = args[0].ToLowerInvariant();
        if (mode == "list")
        {
            var db0 = args[1];
            var filter0 = args[2];
            var rows0 = QueryCookies(db0, filter0);
            Console.WriteLine("# 命中 " + rows0.Count + " 条");
            foreach (var r in rows0)
                Console.WriteLine(string.Format("  {0,-16} {1,-22} plain={2,-4} blob={3,-5} prefix={4}",
                    r.Host, r.Name, r.Plain.Length, r.Blob.Length, r.Prefix));
            return 0;
        }

        if (mode == "probe" || mode == "write")
        {
            var dbPath2 = args[1];
            var filter2 = args[2];
            var localState = mode == "write" ? args[3] : (args.Length > 3 ? args[3] : DefaultLocalState());
            var accountDat = mode == "write" ? args[4] : null;

            var rows = QueryCookies(dbPath2, filter2);
            Console.WriteLine("# 命中 " + rows.Count + " 条 Cookie");
            if (rows.Count == 0) { Console.WriteLine("# 该域下没有 Cookie"); return 6; }

            var key = LoadBrowserKey(localState);
            Console.WriteLine("# 浏览器密钥: " + (key == null ? "读取失败" : key.Length + " bytes"));

            var pairs = new List<string>();
            var v20 = 0;
            foreach (var row in rows)
            {
                string value = null;
                if (row.Plain.Length > 0) value = row.Plain;
                else if (row.Blob.Length > 0)
                {
                    if (row.Prefix == "v20") { v20++; continue; }          // 应用绑定加密：无法解密
                    value = DecryptCookieValue(row.Blob, key);
                }
                if (string.IsNullOrEmpty(value)) continue;

                pairs.Add(row.Name + "=" + value);
                Console.WriteLine(string.Format("  [ok] {0,-18} {1,-22} 值长度={2}", row.Host, row.Name, value.Length));
            }

            if (v20 > 0) Console.WriteLine("# 注意：" + v20 + " 条使用了 v20 应用绑定加密，无法解密");
            if (pairs.Count == 0) { Console.WriteLine("# 没有可用的 Cookie"); return 7; }

            var header = string.Join("; ", pairs);
            Console.WriteLine("# 组装完成，字段数 " + pairs.Count + "，总长度 " + header.Length);

            if (accountDat != null)
            {
                WriteAccountDat(accountDat, header);
                Console.WriteLine("# 已写入插件凭证: " + accountDat);
            }
            return 0;
        }

        Console.WriteLine("# 未知模式: " + mode);
        return 2;
    }

    private sealed class CookieRow
    {
        public string Host = string.Empty;
        public string Name = string.Empty;
        public string Plain = string.Empty;
        public byte[] Blob = new byte[0];
        public string Prefix = string.Empty;
    }

    private static string DefaultLocalState() =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Microsoft", "Edge", "User Data", "Local State");

    private static List<CookieRow> QueryCookies(string dbPath, string filter)
    {
        var result = new List<CookieRow>();

        byte[] raw;
        try
        {
            raw = ReadEvenIfLocked(dbPath);
            Console.WriteLine("# 数据库读取成功：" + raw.Length + " bytes");
        }
        catch (Exception e)
        {
            Console.WriteLine("# 读取失败：" + e.Message);
            return result;
        }

        // SQLite 需要真实文件：写一份临时副本（只读用途）
        var tempDb = Path.Combine(Path.GetTempPath(), "cookiegrab_" + Guid.NewGuid().ToString("N") + ".db");
        File.WriteAllBytes(tempDb, raw);

        IntPtr db;
        var rc = sqlite3_open_v2(Encoding.UTF8.GetBytes(tempDb + "\0"), out db, 0x00000001 /*READONLY*/, IntPtr.Zero);
        if (rc != 0)
        {
            Console.WriteLine("# sqlite3_open_v2 失败 rc=" + rc);
            return result;
        }

        IntPtr stmt;
        var sql = Encoding.UTF8.GetBytes(
            "select host_key,name,value,encrypted_value from cookies where host_key like '%" + filter + "%'\0");
        rc = sqlite3_prepare_v2(db, sql, sql.Length, out stmt, IntPtr.Zero);
        if (rc != 0)
        {
            Console.WriteLine("# prepare 失败 rc=" + rc);
            sqlite3_close(db);
            return result;
        }

        while (sqlite3_step(stmt) == 100 /*ROW*/)
        {
            var blobPtr = sqlite3_column_blob(stmt, 3);
            var blobLen = sqlite3_column_bytes(stmt, 3);
            var blob = new byte[Math.Max(0, blobLen)];
            if (blobPtr != IntPtr.Zero && blobLen > 0) Marshal.Copy(blobPtr, blob, 0, blobLen);

            result.Add(new CookieRow
            {
                Host = Utf8(sqlite3_column_text(stmt, 0)),
                Name = Utf8(sqlite3_column_text(stmt, 1)),
                Plain = Utf8(sqlite3_column_text(stmt, 2)),
                Blob = blob,
                Prefix = blob.Length >= 3 ? Encoding.ASCII.GetString(blob, 0, 3) : "(none)"
            });
        }

        sqlite3_finalize(stmt);
        sqlite3_close(db);
        try { File.Delete(tempDb); } catch { /* 忽略 */ }
        return result;
    }

    // ---------------------------------------------------------------- 浏览器密钥

    private static byte[] LoadBrowserKey(string localStatePath)
    {
        try
        {
            var text = File.ReadAllText(localStatePath);
            var match = System.Text.RegularExpressions.Regex.Match(text, "\"encrypted_key\"\\s*:\\s*\"([^\"]+)\"");
            if (!match.Success) return null;

            var blob = Convert.FromBase64String(match.Groups[1].Value);
            if (blob.Length <= 5) return null;

            var payload = new byte[blob.Length - 5];        // 去掉 "DPAPI" 前缀
            Buffer.BlockCopy(blob, 5, payload, 0, payload.Length);
            return ProtectedData.Unprotect(payload, null, DataProtectionScope.CurrentUser);
        }
        catch (Exception e)
        {
            Console.WriteLine("# LoadBrowserKey 异常: " + e.Message);
            return null;
        }
    }

    private static string DecryptCookieValue(byte[] blob, byte[] key)
    {
        try
        {
            if (blob.Length < 3 + 12 + 16) return null;
            if (key == null || key.Length != 32) return null;

            var nonce = new byte[12];
            Buffer.BlockCopy(blob, 3, nonce, 0, 12);
            var tag = new byte[16];
            Buffer.BlockCopy(blob, blob.Length - 16, tag, 0, 16);
            var cipher = new byte[blob.Length - 3 - 12 - 16];
            Buffer.BlockCopy(blob, 15, cipher, 0, cipher.Length);

            return AesGcmDecrypt(key, nonce, cipher, tag);
        }
        catch (Exception e)
        {
            Console.WriteLine("# DecryptCookieValue 异常: " + e.Message);
            return null;
        }
    }

    // ---------------------------------------------------------------- AES-GCM (bcrypt)

    [StructLayout(LayoutKind.Sequential)]
    private struct BcryptAuthInfo
    {
        public int cbSize;
        public int dwInfoVersion;
        public IntPtr pbNonce;
        public int cbNonce;
        public IntPtr pbAuthData;
        public int cbAuthData;
        public IntPtr pbTag;
        public int cbTag;
        public IntPtr pbMacContext;
        public int cbMacContext;
        public int cbAAD;
        public long cbData;
        public int dwFlags;
    }

    [DllImport("bcrypt.dll", CharSet = CharSet.Unicode)]
    private static extern int BCryptOpenAlgorithmProvider(out IntPtr phAlgorithm, string pszAlgId, string pszImplementation, int dwFlags);

    [DllImport("bcrypt.dll", CharSet = CharSet.Unicode)]
    private static extern int BCryptSetProperty(IntPtr hObject, string pszProperty, byte[] pbInput, int cbInput, int dwFlags);

    [DllImport("bcrypt.dll")]
    private static extern int BCryptGenerateSymmetricKey(IntPtr hAlgorithm, out IntPtr phKey, IntPtr pbKeyObject,
        int cbKeyObject, byte[] pbSecret, int cbSecret, int dwFlags);

    [DllImport("bcrypt.dll")]
    private static extern int BCryptDecrypt(IntPtr hKey, byte[] pbInput, int cbInput, ref BcryptAuthInfo pPaddingInfo,
        byte[] pbIV, int cbIV, byte[] pbOutput, int cbOutput, out int pcbResult, int dwFlags);

    [DllImport("bcrypt.dll")]
    private static extern int BCryptDestroyKey(IntPtr hKey);

    [DllImport("bcrypt.dll")]
    private static extern int BCryptCloseAlgorithmProvider(IntPtr hAlgorithm, int dwFlags);

    private static string AesGcmDecrypt(byte[] key, byte[] nonce, byte[] cipher, byte[] tag)
    {
        IntPtr algorithm = IntPtr.Zero, hKey = IntPtr.Zero;
        IntPtr noncePtr = IntPtr.Zero, tagPtr = IntPtr.Zero;
        try
        {
            if (BCryptOpenAlgorithmProvider(out algorithm, "AES", null, 0) != 0) return null;

            var mode = Encoding.Unicode.GetBytes("ChainingModeGCM\0");
            if (BCryptSetProperty(algorithm, "ChainingMode", mode, mode.Length, 0) != 0) return null;

            if (BCryptGenerateSymmetricKey(algorithm, out hKey, IntPtr.Zero, 0, key, key.Length, 0) != 0) return null;

            noncePtr = Marshal.AllocHGlobal(nonce.Length);
            Marshal.Copy(nonce, 0, noncePtr, nonce.Length);
            tagPtr = Marshal.AllocHGlobal(tag.Length);
            Marshal.Copy(tag, 0, tagPtr, tag.Length);

            var info = new BcryptAuthInfo
            {
                cbSize = Marshal.SizeOf(typeof(BcryptAuthInfo)),
                dwInfoVersion = 1,
                pbNonce = noncePtr,
                cbNonce = nonce.Length,
                pbTag = tagPtr,
                cbTag = tag.Length
            };

            var plain = new byte[cipher.Length];
            int produced;
            var status = BCryptDecrypt(hKey, cipher, cipher.Length, ref info, null, 0, plain, plain.Length, out produced, 0);
            if (status != 0) return null;

            return Encoding.UTF8.GetString(plain, 0, produced);
        }
        finally
        {
            if (noncePtr != IntPtr.Zero) Marshal.FreeHGlobal(noncePtr);
            if (tagPtr != IntPtr.Zero) Marshal.FreeHGlobal(tagPtr);
            if (hKey != IntPtr.Zero) BCryptDestroyKey(hKey);
            if (algorithm != IntPtr.Zero) BCryptCloseAlgorithmProvider(algorithm, 0);
        }
    }

    // ---------------------------------------------------------------- 写插件凭证

    private static void WriteAccountDat(string path, string cookieHeader)
    {
        var plain = Encoding.UTF8.GetBytes(cookieHeader);
        var entropy = Encoding.UTF8.GetBytes("ChillQQMusic.CookieStore.v1");
        var cipher = ProtectedData.Protect(plain, entropy, DataProtectionScope.CurrentUser);

        var magic = new byte[] { 0x43, 0x51, 0x4D, 0x31 };   // "CQM1"
        var body = new byte[magic.Length + 1 + cipher.Length];
        Buffer.BlockCopy(magic, 0, body, 0, magic.Length);
        body[magic.Length] = 1;                               // 1 = DPAPI
        Buffer.BlockCopy(cipher, 0, body, magic.Length + 1, cipher.Length);

        Directory.CreateDirectory(Path.GetDirectoryName(path));
        File.WriteAllBytes(path, body);
    }

    private static string Utf8(IntPtr ptr)
    {
        if (ptr == IntPtr.Zero) return string.Empty;
        var length = 0;
        while (Marshal.ReadByte(ptr, length) != 0) length++;
        var buffer = new byte[length];
        Marshal.Copy(ptr, buffer, 0, length);
        return Encoding.UTF8.GetString(buffer);
    }
}

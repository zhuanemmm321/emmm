using System;
using System.IO;
using System.Runtime.InteropServices;

namespace ChillQQMusic
{
    /// <summary>
    /// 通过自带的 MfDecode.dll 调用 Windows Media Foundation，把 m4a/AAC 解码成 16bit PCM WAV。
    ///
    /// 起因：Unity（Windows）的 UnityWebRequest 不支持 AAC 解码（AudioType.ACC 只在 iOS/Android 生效），
    /// 而 QQ 音乐 CDN 只会下发 m4a，所以必须借助系统解码器把容器转成 Unity 能读的 WAV。
    /// </summary>
    internal static class NativeMfDecode
    {
        [DllImport("MfDecode.dll", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        private static extern int MfDecodeToWav(string inPath, string outPath);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern IntPtr LoadLibraryW(string fileName);

        private static bool _preloaded;
        private static bool _available = true;

        /// <summary>
        /// 预加载 DLL：Mono 的 DllImport 搜索路径不一定包含插件目录，
        /// 这里先用绝对路径 LoadLibrary 一次，后续按名字加载即可命中已加载模块。
        /// </summary>
        internal static bool EnsureLoaded()
        {
            if (!_available) return false;
            if (_preloaded) return true;

            try
            {
                var pluginDir = Path.GetDirectoryName(typeof(NativeMfDecode).Assembly.Location);
                var candidate = Path.Combine(pluginDir ?? string.Empty, "MfDecode.dll");
                if (File.Exists(candidate))
                {
                    var handle = LoadLibraryW(candidate);
                    if (handle == IntPtr.Zero)
                    {
                        Plugin.Log?.LogWarning("LoadLibrary 失败（" + Marshal.GetLastWin32Error() + "）: " + candidate);
                    }
                }
                else
                {
                    Plugin.Log?.LogWarning("找不到 MfDecode.dll，m4a 将无法转码: " + candidate);
                }
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("预加载 MfDecode.dll 异常: " + e.Message);
            }

            _preloaded = true;
            return true;
        }

        /// <summary>解码成 WAV，返回写入的 PCM 字节数（&gt;0 表示成功）。</summary>
        internal static int DecodeToWav(string inputPath, string outputPath)
        {
            if (!EnsureLoaded()) return -100;
            try
            {
                return MfDecodeToWav(inputPath, outputPath);
            }
            catch (Exception e)
            {
                _available = false;
                Plugin.Log?.LogWarning("调用 MfDecode.dll 失败: " + e.Message);
                return -101;
            }
        }
    }
}

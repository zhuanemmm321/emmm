<#
  ChillQQMusic - clean uninstall / reinstall test harness.

  Phases (in order):
    1. preflight  : refuses to run while the game is running; validates paths and package hashes
    2. backup     : copies credentials / config / logs / current DLLs into backups\<ts>_before-uninstall
    3. uninstall  : deletes BepInEx + the mod from the game folder (everything is backed up in phase 2)
    4. install    : extracts the delivered package and installs BepInEx + the plugin exactly like a new user
    5. verify     : re-hashes what landed on disk and prints the manual test checklist

  Usage:
    # dry run - report only, change nothing
    powershell -ExecutionPolicy Bypass -File .\test-reinstall.ps1 -Check

    # phase 1 + 2 only - safe, read-only on the game folder
    powershell -ExecutionPolicy Bypass -File .\test-reinstall.ps1 -BackupOnly

    # full run: backup + wipe + install from the package
    powershell -ExecutionPolicy Bypass -File .\test-reinstall.ps1 -Yes

    # full run but keep the ~650 MB transcode cache (skips the cold first-play test)
    powershell -ExecutionPolicy Bypass -File .\test-reinstall.ps1 -Yes -KeepCache

    # roll back afterwards (restores credential / config / plugin DLLs, reinstalls the framework if needed)
    powershell -ExecutionPolicy Bypass -File .\test-reinstall.ps1 -Restore backups\20260924_180000_before-uninstall

  Safety rules baked in:
    * never touches a running game (no process kill, ever)
    * every delete target is resolved with GetFullPath and asserted to be inside the game folder
    * credentials / config / plugin DLLs are always copied out before anything is deleted
    * the transcode cache is regenerable; -KeepCache moves it aside instead of deleting it

  NOTE: keep this file ASCII-only. Windows PowerShell 5.1 reads BOM-less .ps1 as ANSI,
        and the delivered package folder names are non-ASCII, so we discover them by wildcard.
#>
param(
    [string]$GameDir   = 'D:\SteamLibrary\steamapps\common\Chill with You Lo-Fi Story',
    [string]$PackageZip,
    [string]$BackupRoot,
    [string]$Restore,
    [switch]$Check,
    [switch]$BackupOnly,
    [switch]$KeepCache,
    [switch]$Yes
)

$ErrorActionPreference = 'Stop'
$script:Fail = 0

# hashes this harness was written against (ASCII hex only)
$ExpectedPluginSha = '7E040FCC8B20C121F01D2CBD6279D19AB350F2183D01754EDDE164787FBAA71B'
$ExpectedCodecSha  = 'BB61381EB229ABC18DA07105DE0E7168D361E0885B1B9AB67C41FD6913B70CD0'
$ExpectedBepInExSha= '41A089E5B1B1F0713B331346BAF6677B1184C69EABEBF51101097954E854C749'

function Say([string]$m)  { Write-Host $m }
function Ok([string]$m)   { Write-Host "  [OK]   $m" -ForegroundColor Green }
function Warn([string]$m) { Write-Host "  [WARN] $m" -ForegroundColor Yellow }
function Bad([string]$m)  { Write-Host "  [FAIL] $m" -ForegroundColor Red; $script:Fail++ }
function Step([string]$m) { Write-Host $m -ForegroundColor Cyan }
function Hdr([string]$m)  { Write-Host ''; Write-Host $m -ForegroundColor White }

function Get-Sha256([string]$p) { (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash }

function Assert-InsideGame([string]$p) {
    $full = [IO.Path]::GetFullPath($p)
    $root = [IO.Path]::GetFullPath($GameDir).TrimEnd('\') + '\'
    if (-not $full.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) {
        throw "REFUSED: path is outside the game folder -> $full"
    }
    return $full
}

function Get-GameRunning {
    return @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -like '*Chill*' -or ($_.MainWindowTitle -and $_.MainWindowTitle -like '*Chill*')
    })
}

# ---------------------------------------------------------------- locate package
function Find-PackageZip {
    if ($PackageZip) { return $PackageZip }
    # the delivered package lives in a sibling folder of this script's folder
    $parent = Split-Path -Parent $PSScriptRoot
    $hit = Get-ChildItem -Path (Join-Path $parent '*\ChillQQMusic_*.zip') -File -ErrorAction SilentlyContinue |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($hit) { return $hit.FullName }
    return $null
}

function Get-PackageDirs([string]$extractRoot) {
    # package folders are named "1-...", "2-..." (non-ASCII tails) so we match by number prefix
    $one = Get-ChildItem $extractRoot -Directory | Where-Object { $_.Name -like '1-*' } | Select-Object -First 1
    $two = Get-ChildItem $extractRoot -Directory | Where-Object { $_.Name -like '2-*' } | Select-Object -First 1
    return @{ Plugin = $one; Framework = $two }
}

function Get-PackageRoot([string]$extractRoot) {
    # the delivered zip wraps everything in a single top-level folder; descend into it
    $dirs  = @(Get-ChildItem -LiteralPath $extractRoot -Directory)
    $files = @(Get-ChildItem -LiteralPath $extractRoot -File)
    if ($files.Count -eq 0 -and $dirs.Count -eq 1) { return $dirs[0].FullName }
    return $extractRoot
}

# ============================================================ RESTORE MODE
if ($Restore) {
    Hdr '=== RESTORE MODE ==='
    $rb = [IO.Path]::GetFullPath($Restore)
    if (-not (Test-Path -LiteralPath $rb)) { Bad "backup folder not found: $rb"; exit 2 }
    if (Get-GameRunning) { Bad 'the game is running - close it first (this script never kills it)'; exit 3 }
    Ok "backup folder: $rb"

    $map = @(
        @{ src = 'config-ChillQQMusic';    dst = 'BepInEx\config\ChillQQMusic' },
        @{ src = 'plugins-ChillQQMusic';   dst = 'BepInEx\plugins\ChillQQMusic' }
    )
    foreach ($m in $map) {
        $s = Join-Path $rb $m.src
        if (-not (Test-Path -LiteralPath $s)) { Warn "missing in backup, skipped: $($m.src)"; continue }
        $d = Assert-InsideGame (Join-Path $GameDir $m.dst)
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $d) | Out-Null
        if (Test-Path -LiteralPath $d) { Remove-Item -LiteralPath $d -Recurse -Force }
        Copy-Item -LiteralPath $s -Destination $d -Recurse -Force
        Ok "restored $($m.src) -> $d"
    }

    $cfg = Join-Path $rb 'com.codex.chillqqmusic.cfg'
    if (Test-Path -LiteralPath $cfg) {
        $d = Assert-InsideGame (Join-Path $GameDir 'BepInEx\config\com.codex.chillqqmusic.cfg')
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $d) | Out-Null
        Copy-Item -LiteralPath $cfg -Destination $d -Force
        Ok "restored config -> $d"
    } else { Warn 'no saved cfg in this backup (a fresh default one will be generated)' }

    # framework: restore the three root files + BepInEx\core if the backup has them
    $rootBk = Join-Path $rb 'root'
    if (Test-Path -LiteralPath $rootBk) {
        if (Test-Path -LiteralPath (Join-Path $rootBk 'BepInEx')) {
            $src = Join-Path $rootBk 'BepInEx'
            $dst = Assert-InsideGame (Join-Path $GameDir 'BepInEx')
            if (-not (Test-Path -LiteralPath (Join-Path $dst 'core\BepInEx.dll'))) {
                New-Item -ItemType Directory -Force -Path $dst | Out-Null
                Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
                Ok 'restored BepInEx framework from backup'
            } else { Ok 'BepInEx framework already present' }
        }
        foreach ($f in 'winhttp.dll', 'doorstop_config.ini', '.doorstop_version') {
            $s = Join-Path $rootBk $f
            if (Test-Path -LiteralPath $s) {
                Copy-Item -LiteralPath $s -Destination (Assert-InsideGame (Join-Path $GameDir $f)) -Force
                Ok "restored $f"
            }
        }
    }
    Say ''
    Say 'Restore done. Launch the game yourself to confirm the old state is back.'
    exit 0
}

# ============================================================ 1. PREFLIGHT
Hdr '=== [1/5] PREFLIGHT ==='

if (-not (Test-Path -LiteralPath (Join-Path $GameDir 'Chill With You.exe'))) {
    Bad "game exe not found - wrong -GameDir? $GameDir"; exit 2
}
Ok "game folder: $GameDir"

$running = Get-GameRunning
if ($running.Count -gt 0) {
    Bad "the game is running (PID $($running[0].Id)) - close it yourself first, this script never kills it"
    exit 3
}
Ok 'game is not running'

$zip = Find-PackageZip
if (-not $zip -or -not (Test-Path -LiteralPath $zip)) {
    Bad 'package zip not found. pass -PackageZip <path to ChillQQMusic_*.zip>'
    exit 2
}
Ok "package: $zip"

$sidecar = "$zip.sha256"
if (Test-Path -LiteralPath $sidecar) {
    $want = (Get-Content -LiteralPath $sidecar -Encoding UTF8 | Select-Object -First 1) -split '\s+' | Select-Object -First 1
    $got  = Get-Sha256 $zip
    if ($want -and $want -eq $got) { Ok "package sha256 matches its .sha256 sidecar" }
    else { Warn "package sha256 does NOT match the sidecar ($got vs $want) - continuing, but verify the zip" }
} else { Warn "no .sha256 sidecar next to the package" }

if ($Check) {
    Hdr '=== DRY RUN - nothing will be changed ==='
    Say 'Would back up : BepInEx\config\ChillQQMusic, BepInEx\plugins\ChillQQMusic,'
    Say '                BepInEx\LogOutput.log, com.codex.chillqqmusic.cfg,'
    Say '                winhttp.dll, doorstop_config.ini, .doorstop_version'
    Say 'Would delete  : the whole BepInEx\ folder, winhttp.dll, doorstop_config.ini, .doorstop_version'
    if ($KeepCache) { Say '                (the transcode cache is moved aside instead of deleted)' }
    else { Warn 'the ~650 MB transcode cache will be deleted; first play of each song will re-download + transcode' }
    Say "Would install : BepInEx 5.4.23.3 x64 (official zip) + plugins\ChillQQMusic\{ChillQQMusic.dll, MfDecode.dll}"
    Say '                both taken from the package, then re-hashed to verify what landed on disk'
    exit 0
}

# ============================================================ 2. BACKUP
Hdr '=== [2/5] BACKUP ==='
if (-not $BackupRoot) { $BackupRoot = Join-Path $PSScriptRoot 'backups' }
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupDir = Join-Path $BackupRoot ($stamp + '_before-uninstall')
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null

$plan = @(
    @{ src = 'BepInEx\config\ChillQQMusic';                dst = 'config-ChillQQMusic';     dir = $true  },
    @{ src = 'BepInEx\plugins\ChillQQMusic';               dst = 'plugins-ChillQQMusic';    dir = $true  },
    @{ src = 'BepInEx\config\com.codex.chillqqmusic.cfg';  dst = 'com.codex.chillqqmusic.cfg'; dir = $false },
    @{ src = 'BepInEx\LogOutput.log';                      dst = 'LogOutput.log';           dir = $false },
    @{ src = 'winhttp.dll';                                dst = 'root\winhttp.dll';        dir = $false },
    @{ src = 'doorstop_config.ini';                        dst = 'root\doorstop_config.ini';dir = $false },
    @{ src = '.doorstop_version';                          dst = 'root\.doorstop_version';  dir = $false }
)

$manifest = @()
foreach ($p in $plan) {
    $s = Join-Path $GameDir $p.src
    if (-not (Test-Path -LiteralPath $s)) { Warn "not present, skipped: $($p.src)"; continue }
    $d = Join-Path $backupDir $p.dst
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $d) | Out-Null
    Copy-Item -LiteralPath $s -Destination $d -Recurse -Force
    $files = if ($p.dir) { Get-ChildItem -LiteralPath $d -Recurse -File } else { Get-Item -LiteralPath $d }
    foreach ($f in $files) {
        $manifest += [pscustomobject]@{
            file = $f.FullName.Substring($backupDir.Length + 1)
            size = $f.Length
            sha256 = Get-Sha256 $f.FullName
        }
    }
    Ok "backed up $($p.src)  ($($files.Count) file(s))"
}

# keep a copy of the framework core so -Restore can rebuild a wiped BepInEx
$coreSrc = Join-Path $GameDir 'BepInEx\core'
if (Test-Path -LiteralPath $coreSrc) {
    $coreDst = Join-Path $backupDir 'root\BepInEx\core'
    New-Item -ItemType Directory -Force -Path $coreDst | Out-Null
    # NOTE: -Path (not -LiteralPath) here - we WANT the trailing wildcard expanded
    Copy-Item -Path (Join-Path $coreSrc '*') -Destination $coreDst -Recurse -Force
    Ok 'backed up BepInEx\core (so -Restore can rebuild the framework offline)'
}

$manifest | Format-Table -AutoSize | Out-String | Set-Content -LiteralPath (Join-Path $backupDir 'manifest.txt') -Encoding UTF8
Ok "backup folder: $backupDir"

if ($BackupOnly) {
    Say ''
    Say 'Backup-only run finished. Nothing in the game folder was changed.'
    exit 0
}

# ---------------------------------------------------------------- confirm
if (-not $Yes) {
    Say ''
    Warn 'this will DELETE BepInEx and the mod from the game folder (backup above is your safety net)'
    $ans = Read-Host 'type YES to continue'
    if ($ans -ne 'YES') { Say 'aborted by user.'; exit 0 }
}

# ============================================================ 3. UNINSTALL
Hdr '=== [3/5] UNINSTALL ==='

$cacheHold = $null
if ($KeepCache) {
    $cacheSrc = Assert-InsideGame (Join-Path $GameDir 'BepInEx\cache\ChillQQMusic')
    if (Test-Path -LiteralPath $cacheSrc) {
        $cacheHold = Join-Path $env:TEMP ('cqm_cache_' + [Guid]::NewGuid().ToString('N'))
        Move-Item -LiteralPath $cacheSrc -Destination $cacheHold -Force
        Ok "transcode cache moved aside: $cacheHold"
    }
}

$targets = @('BepInEx', 'winhttp.dll', 'doorstop_config.ini', '.doorstop_version')
foreach ($t in $targets) {
    $full = Assert-InsideGame (Join-Path $GameDir $t)
    if (Test-Path -LiteralPath $full) {
        $sizeMb = if ((Get-Item -LiteralPath $full).PSIsContainer) {
            [math]::Round(((Get-ChildItem -LiteralPath $full -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1MB), 1)
        } else { [math]::Round((Get-Item -LiteralPath $full).Length / 1MB, 3) }
        Remove-Item -LiteralPath $full -Recurse -Force
        Ok "deleted $t  ($sizeMb MB)"
    } else { Warn "already absent: $t" }
}

# ============================================================ 4. INSTALL
Hdr '=== [4/5] INSTALL (as a brand new user) ==='
$extract = Join-Path $env:TEMP ('cqm_pkg_' + [Guid]::NewGuid().ToString('N'))
Expand-Archive -LiteralPath $zip -DestinationPath $extract -Force
Ok "package extracted to $extract"

$pkgRoot = Get-PackageRoot $extract
if ($pkgRoot -ne $extract) { Ok "package root folder: $(Split-Path -Leaf $pkgRoot)" }

$dirs = Get-PackageDirs $pkgRoot
if (-not $dirs.Plugin)    { Bad 'package is missing the "1-*" plugin folder'; exit 2 }
if (-not $dirs.Framework) { Bad 'package is missing the "2-*" framework folder'; exit 2 }

$pluginSrc = Join-Path $dirs.Plugin.FullName 'plugins\ChillQQMusic'
if (-not (Test-Path -LiteralPath $pluginSrc)) { Bad "plugin folder missing inside package: $pluginSrc"; exit 2 }

$dllIn = Join-Path $pluginSrc 'ChillQQMusic.dll'
$cdcIn = Join-Path $pluginSrc 'MfDecode.dll'
if ((Get-Sha256 $dllIn) -ne $ExpectedPluginSha) { Warn 'ChillQQMusic.dll in the package differs from the hash this script expects' }
if ((Get-Sha256 $cdcIn) -ne $ExpectedCodecSha)  { Warn 'MfDecode.dll in the package differs from the hash this script expects' }

$bepZip = Join-Path $dirs.Framework.FullName 'BepInEx_win_x64_5.4.23.3.zip'
if (-not (Test-Path -LiteralPath $bepZip)) { Bad "official BepInEx zip missing in package: $bepZip"; exit 2 }
if ((Get-Sha256 $bepZip) -ne $ExpectedBepInExSha) {
    Bad 'the BepInEx zip inside the package does NOT match the official hash - refusing to install it'
    exit 4
}
Ok 'official BepInEx zip verified against its published SHA256'

# framework: reuse the package's own installer so that script gets exercised too
$installer = Join-Path $dirs.Framework.FullName 'install-bepinex.ps1'
if (Test-Path -LiteralPath $installer) {
    & powershell -ExecutionPolicy Bypass -File $installer -GameDir $GameDir -ZipPath $bepZip -ExpectedSha256 $ExpectedBepInExSha
    if ($LASTEXITCODE -ne 0) { Warn "install-bepinex.ps1 returned $LASTEXITCODE - falling back to manual copy" }
}

if (-not (Test-Path -LiteralPath (Join-Path $GameDir 'BepInEx\core\BepInEx.dll'))) {
    Warn 'framework still missing after installer - copying by hand'
    $bepTmp = Join-Path $extract '_bepinex'
    Expand-Archive -LiteralPath $bepZip -DestinationPath $bepTmp -Force
    Get-ChildItem -LiteralPath $bepTmp -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination (Assert-InsideGame (Join-Path $GameDir $_.Name)) -Recurse -Force
    }
    Ok 'framework copied manually'
}

# plugin
$pluginDst = Assert-InsideGame (Join-Path $GameDir 'BepInEx\plugins\ChillQQMusic')
New-Item -ItemType Directory -Force -Path $pluginDst | Out-Null
# NOTE: -Path (not -LiteralPath) - the wildcard must be expanded to copy the folder contents
Copy-Item -Path (Join-Path $pluginSrc '*') -Destination $pluginDst -Recurse -Force
Ok "plugin installed to $pluginDst"

if ($cacheHold) {
    $cacheBack = Assert-InsideGame (Join-Path $GameDir 'BepInEx\cache\ChillQQMusic')
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $cacheBack) | Out-Null
    Move-Item -LiteralPath $cacheHold -Destination $cacheBack -Force
    $n = (Get-ChildItem -LiteralPath $cacheBack -File | Measure-Object).Count
    Ok "transcode cache restored ($n files)"
}

# ============================================================ 5. VERIFY
Hdr '=== [5/5] VERIFY ==='
$dllDst = Join-Path $pluginDst 'ChillQQMusic.dll'
$cdcDst = Join-Path $pluginDst 'MfDecode.dll'
foreach ($pair in @(@{ f = $dllDst; name = 'ChillQQMusic.dll'; want = $ExpectedPluginSha },
                    @{ f = $cdcDst; name = 'MfDecode.dll';     want = $ExpectedCodecSha  })) {
    if (-not (Test-Path -LiteralPath $pair.f)) { Bad "$($pair.name) missing on disk"; continue }
    $h = Get-Sha256 $pair.f
    if ($h -eq $pair.want) { Ok "$($pair.name) sha256 OK" } else { Bad "$($pair.name) sha256 mismatch: $h" }
}
foreach ($f in 'BepInEx\core\BepInEx.dll', 'winhttp.dll', 'doorstop_config.ini', '.doorstop_version') {
    if (Test-Path -LiteralPath (Join-Path $GameDir $f)) { Ok "present: $f" } else { Bad "missing: $f" }
}
if (Test-Path -LiteralPath (Join-Path $GameDir 'BepInEx\config\com.codex.chillqqmusic.cfg')) {
    Warn 'a leftover cfg is still there - a true first run should NOT have one'
} else { Ok 'no leftover plugin cfg (true first-run state)' }

Remove-Item -LiteralPath $extract -Recurse -Force -ErrorAction SilentlyContinue

Hdr '=== NEXT: do this yourself ==='
Say '  1. launch the game and press F8 (or click the note button at the far left)'
Say '  2. the panel must start hidden, unlogged, with no playlist bound'
Say '  3. login: top-right person icon -> "open browser login" -> y.qq.com -> F12 ->'
Say '     Network -> refresh -> any request -> copy the whole Cookie header (needs qm_keyst)'
Say '     -> back in game click the clipboard-import button'
Say '  4. bind a playlist: top-right list icon -> type the playlist id -> click bind'
Say '  5. play a song, let it run a while, then close the game normally'
Say '  6. hand the two log files back for review:'
Say "       $GameDir\BepInEx\LogOutput.log"
Say "       $GameDir\BepInEx\config\ChillQQMusic\shutdown.log"
Say ''
Say "Backup of the pre-test state: $backupDir"
Say "Roll back with: powershell -ExecutionPolicy Bypass -File .\test-reinstall.ps1 -Restore `"$backupDir`""

if ($script:Fail -gt 0) { Say ''; Bad "$($script:Fail) check(s) failed"; exit 1 }
Say ''
Say 'All checks passed.'
exit 0

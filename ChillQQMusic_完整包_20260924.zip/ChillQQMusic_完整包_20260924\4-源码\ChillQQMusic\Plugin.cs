using System;
using System.IO;
using System.Threading.Tasks;
using BepInEx;
using BepInEx.Logging;
using UnityEngine;

namespace ChillQQMusic
{
    /// <summary>
    /// BepInEx 5 (Mono) 插件入口。
    ///
    /// 重要设计（针对本游戏实测）：
    /// 《Chill with You》在启动阶段会用 LoadSceneMode.Single 加载 Boot 场景，
    /// 这次加载会把 BepInEx 挂在 BepInEx_Manager 上的插件对象销毁掉。
    /// 因此这里遵守两条铁律：
    ///   1) Awake 里只做"不依赖 GameObject 生命周期"的初始化（配置、服务、Harmony 补丁、看门狗）；
    ///   2) AudioPlayer / UIManager 这些运行期组件延后到首个场景加载之后，
    ///      创建在带 HideFlags.DontSave 的持久 GameObject 上，并由 RuntimeWatchdog 兜底驱动。
    /// </summary>
    [BepInPlugin(PluginGuid, PluginDisplayName, PluginVersion)]
    public class Plugin : BaseUnityPlugin
    {
        /// <summary>
        /// 挂在运行期宿主上的退出探针：只负责在游戏退出时报一次到，
        /// 这样日志里能明确区分"游戏走到了退出流程"和"游戏在更早的地方就卡住了"。
        /// </summary>
        internal sealed class QuitHook : MonoBehaviour
        {
            private void OnApplicationQuit()
            {
                Plugin.Log?.LogInfo("游戏开始退出（运行期宿主 OnApplicationQuit）。");
                Trace("运行期宿主收到 OnApplicationQuit。");
                BeginShutdown("OnApplicationQuit(运行期宿主)");
            }

            private void OnDestroy()
            {
                Trace("运行期宿主被销毁。");
            }
        }

        public const string PluginGuid = "com.codex.chillqqmusic";
        public const string PluginDisplayName = "Chill QQ Music";
        public const string PluginVersion = "0.2.0";

        internal static Plugin Instance { get; private set; }
        internal static ManualLogSource Log { get; private set; }
        internal static ConfigManager Settings { get; private set; }
        internal static IQQMusicService Music { get; private set; }
        internal static LoginManager Login { get; private set; }
        internal static AudioPlayer Audio { get; private set; }
        internal static PlaylistManager Playlist { get; private set; }
        internal static UIManager UI { get; private set; }
        internal static AudioCache Cache { get; private set; }

        private static NativeMediaBridge _mediaBridge;

        private static KeyCode _toggleKey = KeyCode.F8;
        private static KeyCode _playPauseKey = KeyCode.F9;
        private static KeyCode _nextKey = KeyCode.F10;
        private static KeyCode _prevKey = KeyCode.F7;
        private static KeyCode _safeQuitKey = KeyCode.None;

        private static GameObject _runtimeHost;
        private static bool _shuttingDown;
        private static bool _shutdownDone;
        private static bool _firstFrameLogged;
        private static bool _startupRoutineStarted;

        // ------------------------------------------------------------------ 生命周期

        private void Awake()
        {
            Instance = this;
            Log = Logger;

            Log.LogInfo(PluginDisplayName + " " + PluginVersion + " 正在加载（Unity " + Application.unityVersion + "）…");
            TraceSessionStart();

            // 退出钩子：wantsToQuit 是 Unity 能提供的最早时机（在 quitting / OnApplicationQuit /
            // 对象销毁之前），用它把"播放中的 UnityWebRequest / AudioClip / 媒体键线程"
            // 提前释放掉，避免拖到 Unity 拆子系统的时候卡住主线程。
            try { Application.wantsToQuit += OnWantsToQuit; } catch (Exception e) { Log.LogDebug("注册 wantsToQuit 失败: " + e.Message); }
            Application.quitting += OnApplicationQuitting;

            Settings = new ConfigManager(Config);
            MainThreadDispatcher.Initialize(gameObject);

            Cache = new AudioCache(Path.Combine(Paths.CachePath, "ChillQQMusic"),
                Settings.EnableDiskCache.Value, Settings.CacheMaxMegabytes.Value);

            QQHttp.Configure(Settings);
            Music = QQMusicServiceFactory.Create(Settings);
            Login = new LoginManager(Settings, Music);
            Playlist = new PlaylistManager(Settings, Music);

            // 注意：AudioPlayer / UIManager 故意不在这里创建，见 EnsureRuntime()。

            ParseHotkeys();
            Settings.HotkeyToggleUi.SettingChanged += (_, __) => ParseHotkeys();
            Settings.HotkeyPlayPause.SettingChanged += (_, __) => ParseHotkeys();
            Settings.HotkeyNext.SettingChanged += (_, __) => ParseHotkeys();
            Settings.HotkeyPrev.SettingChanged += (_, __) => ParseHotkeys();
            Settings.DuckDecibels.SettingChanged += (_, __) =>
            {
                Patches.UpdateDuckDecibels(Settings.DuckDecibels.Value);
            };

            if (Settings.EnableMediaKeys.Value)
            {
                _mediaBridge = new NativeMediaBridge();
                _mediaBridge.Triggered += OnMediaKey;
                _mediaBridge.Start();
            }

            // Harmony 补丁：只新增按钮 + 借游戏自身的音量代码压低 BGM。
            Patches.Apply(Settings);

            // 看门狗：静态回调驱动，不依赖本对象是否存活。
            RuntimeWatchdog.Install();

            Log.LogInfo("插件初始化完成。歌单ID = " + (string.IsNullOrEmpty(Settings.ResolvePlaylistId())
                ? "(未配置)" : Settings.ResolvePlaylistId()) + "；运行期组件将在首个场景加载后创建。");
        }

        private static void OnApplicationQuitting()
        {
            BeginShutdown("Application.quitting");
        }

        private static bool OnWantsToQuit()
        {
            BeginShutdown("Application.wantsToQuit");
            return true;      // 不拦截，正常退出
        }

        /// <summary>
        /// 统一的退出清理（幂等）。
        ///
        /// 为什么要提前做：游戏关闭时如果还留着"播放中的
        /// UnityWebRequestMultimedia.GetAudioClip 请求"（它整个播放期间都必须保持存活），
        /// Unity 在拆音频/网络子系统时会卡住主线程 —— 表现就是窗口"无响应"、关不掉。
        /// 这里在 Unity 销毁对象之前先把它们主动释放掉，并逐条写日志，
        /// 万一还是卡住，日志能直接指出卡在哪一步。
        /// </summary>
        internal static void BeginShutdown(string reason)
        {
            if (_shutdownDone) return;
            _shutdownDone = true;
            _shuttingDown = true;

            SafeLog("开始退出清理（" + reason + "）…");

            SafeLog("  · 1/9 卸载看门狗");
            try { RuntimeWatchdog.Uninstall(); } catch (Exception e) { SafeLog("卸载看门狗异常: " + e.Message); }

            SafeLog("  · 2/9 释放悬浮窗（含封面下载请求）");
            try { UI?.PrepareForShutdown(); } catch (Exception e) { SafeLog("释放悬浮窗异常: " + e.Message); }

            SafeLog("  · 3/9 停止音频并释放 UnityWebRequest / AudioClip");
            try { Audio?.PrepareForShutdown(); } catch (Exception e) { SafeLog("停止音频异常: " + e.Message); }

            SafeLog("  · 4/9 取消歌单 / 预取任务");
            try { Playlist?.PrepareForShutdown(); } catch (Exception e) { SafeLog("取消歌单异常: " + e.Message); }

            SafeLog("  · 5/9 释放登录与服务");
            try { Login?.Dispose(); } catch (Exception e) { SafeLog("释放登录异常: " + e.Message); }
            try { Music?.Dispose(); } catch (Exception e) { SafeLog("释放服务异常: " + e.Message); }

            SafeLog("  · 6/9 注销媒体键线程");
            try { _mediaBridge?.Dispose(); } catch (Exception e) { SafeLog("注销媒体键异常: " + e.Message); }

            SafeLog("  · 7/9 卸载 Harmony 补丁");
            try { Patches.SetDucking(false); } catch { /* 忽略 */ }
            try { Patches.Unapply(); } catch (Exception e) { SafeLog("卸载补丁异常: " + e.Message); }

            SafeLog("  · 8/9 保存配置");
            try { Settings?.Save(); } catch (Exception e) { SafeLog("保存配置异常: " + e.Message); }

            SafeLog("  · 9/9 清理贴图缓存");
            try { LoFiTheme.ClearCache(); } catch (Exception e) { SafeLog("清理贴图缓存异常: " + e.Message); }

            Instance = null;
            SafeLog("退出清理完成。");
        }

        private void OnApplicationQuit() => BeginShutdown("OnApplicationQuit(插件对象)");

        private static void SafeLog(string message)
        {
            try { Log?.LogInfo(message); } catch { /* 退出阶段日志也可能不可用 */ }
            Trace(message);
        }

        /// <summary>
        /// 退出追踪：直接追加写文件，**不走 BepInEx 的日志系统**。
        ///
        /// 原因：BepInEx 自己在退出时会先一步关掉 LogOutput.log 的监听器，
        /// 那之后我们写进 LogOutput.log 的内容会被静默丢掉 —— 之前"关游戏卡死"
        /// 排查不到任何线索就是这个原因（日志停在最后一个正常操作上，之后全没了）。
        /// 这个文件能如实记录退出流程走到哪一步。
        /// </summary>
        internal static void Trace(string message)
        {
            try
            {
                var dir = Path.Combine(Paths.ConfigPath, "ChillQQMusic");
                Directory.CreateDirectory(dir);
                File.AppendAllText(Path.Combine(dir, "shutdown.log"),
                    DateTime.Now.ToString("HH:mm:ss.fff") + "  " + message + Environment.NewLine);
            }
            catch { /* 追踪本身绝不允许抛异常 */ }
        }

        /// <summary>每次启动在追踪文件里画一条分隔线，便于区分会话。</summary>
        private static void TraceSessionStart()
        {
            Trace(string.Empty);
            Trace("================ 启动（" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "）================");
        }

        private void Update()
        {
            try
            {
                RuntimeWatchdog.NotifyMonoUpdate();
                LogFirstFrameOnce();
                MainThreadDispatcher.PumpOnMainThread();
                Playlist?.Tick();
                HandleHotkeys();
                EnsureRuntime("Update 自检");
            }
            catch (Exception e)
            {
                Log.LogError("Update 异常: " + e);
            }
        }

        private static void LogFirstFrameOnce()
        {
            if (_firstFrameLogged) return;
            _firstFrameLogged = true;
            Log?.LogInfo("插件主循环已启动，当前场景 = " +
                         UnityEngine.SceneManagement.SceneManager.GetActiveScene().name);
        }

        /// <summary>
        /// 游戏销毁 BepInEx 插件对象时会触发。
        /// 关键：**不能**在这里拆卸 Harmony / 释放管理器 —— 那正是之前"按钮不出现、热键失效"的原因。
        /// 只有游戏真正退出时才做完整清理。
        /// </summary>
        private void OnDestroy()
        {
            if (!_shuttingDown)
            {
                Log?.LogWarning("插件宿主对象被游戏销毁（启动阶段场景加载所致）。"
                    + "静态模块与 Harmony 补丁会保留，运行期组件改由 RuntimeWatchdog 驱动。");
                Trace("插件宿主对象被销毁（非退出，启动阶段场景加载）。");
                Instance = null;
                return;
            }

            Log?.LogInfo("游戏退出，开始清理插件资源…");
            Trace("插件宿主 OnDestroy（游戏退出中）。");
            BeginShutdown("插件对象 OnDestroy");
        }

        // ------------------------------------------------------------------ 运行期组件（延后创建 + 自愈）

        /// <summary>创建或重建 AudioPlayer + UIManager。任何一步都不会影响游戏本体。</summary>
        internal static void EnsureRuntime(string reason)
        {
            if (_shutdownDone) return;                          // 退出清理后绝不再重建 UI
            if (RuntimeWatchdog.ScenesLoaded == 0) return;      // 还在"第一个场景加载前"的危险期
            if (Audio != null && UI != null && UI.IsHealthy) return;

            try
            {
                Log?.LogInfo("准备运行期组件（" + reason + "）");
                var host = GetOrCreateRuntimeHost();
                MainThreadDispatcher.Initialize(host);

                if (Audio == null)
                {
                    Audio = host.AddComponent<AudioPlayer>();
                    Audio.Initialize(Settings, Cache);
                    Audio.StateChanged += OnPlaybackStateChangedForDucking;
                    Playlist?.AttachAudio(Audio);
                    Log?.LogInfo("AudioPlayer 已创建（宿主 " + host.name + "）");
                }

                if (UI == null || !UI.IsHealthy)
                {
                    if (UI != null)
                    {
                        try { Destroy(UI.gameObject); } catch { /* 忽略 */ }
                    }

                    UI = host.AddComponent<UIManager>();
                    UI.Build(Settings, Playlist, Audio, Login, Cache);
                    UI.ApplyConfig();
                    Log?.LogInfo("UIManager 已创建（宿主 " + host.name + "）");
                }

                if (!_startupRoutineStarted)
                {
                    _startupRoutineStarted = true;
                    _ = StartupAsync();
                }
            }
            catch (Exception e)
            {
                Log?.LogError("创建运行期组件失败: " + e);
            }
        }

        private static GameObject GetOrCreateRuntimeHost()
        {
            if (_runtimeHost != null) return _runtimeHost;

            _runtimeHost = new GameObject("ChillQQMusicRuntime");
            _runtimeHost.hideFlags = HideFlags.DontSave;   // 场景切换不销毁
            DontDestroyOnLoad(_runtimeHost);
            // 退出钩子：插件对象在启动阶段就被游戏销毁了，收不到 OnApplicationQuit，
            // 所以把钩子挂在这个持久宿主上（它一定能收到）。
            _runtimeHost.AddComponent<QuitHook>();
            Log?.LogInfo("已创建持久宿主 GameObject：ChillQQMusicRuntime");
            return _runtimeHost;
        }

        private static async Task StartupAsync()
        {
            try
            {
                var restored = await Login.TryRestoreAsync().ConfigureAwait(true);
                if (restored) Log?.LogInfo("已用本地凭证恢复登录。");

                if (Settings.AutoPlayOnStart.Value)
                    await Playlist.RefreshAsync().ConfigureAwait(true);
            }
            catch (Exception e)
            {
                Log?.LogError("启动流程异常: " + e);
            }
        }

        // ------------------------------------------------------------------ 兜底循环

        /// <summary>由 RuntimeWatchdog 每帧驱动（MonoBehaviour.Update 不可用时）。</summary>
        internal static void FallbackTick()
        {
            try { MainThreadDispatcher.PumpOnMainThread(); } catch (Exception e) { Log?.LogDebug(e.Message); }
            try { Playlist?.Tick(); } catch (Exception e) { Log?.LogDebug(e.Message); }
            try { HandleHotkeys(); } catch (Exception e) { Log?.LogDebug(e.Message); }
            try { EnsureRuntime("兜底循环"); } catch (Exception e) { Log?.LogDebug(e.Message); }
            try { if (UI != null) UI.TickExternal(); } catch (Exception e) { Log?.LogDebug(e.Message); }
        }

        // ------------------------------------------------------------------ 热键

        private static void ParseHotkeys()
        {
            _toggleKey = ParseKey(Settings.HotkeyToggleUi.Value, KeyCode.F8);
            _playPauseKey = ParseKey(Settings.HotkeyPlayPause.Value, KeyCode.F9);
            _nextKey = ParseKey(Settings.HotkeyNext.Value, KeyCode.F10);
            _prevKey = ParseKey(Settings.HotkeyPrev.Value, KeyCode.F7);
            _safeQuitKey = ParseKey(Settings.HotkeySafeQuit.Value, KeyCode.None);
        }

        private static KeyCode ParseKey(string text, KeyCode fallback)
        {
            if (string.IsNullOrWhiteSpace(text)) return KeyCode.None;
            try
            {
                return (KeyCode)Enum.Parse(typeof(KeyCode), text.Trim(), true);
            }
            catch
            {
                Log?.LogWarning("无法识别快捷键 \"" + text + "\"，回退到 " + fallback);
                return fallback;
            }
        }

        internal static void HandleHotkeys()
        {
            if (_toggleKey != KeyCode.None && Input.GetKeyDown(_toggleKey))
            {
                Log?.LogInfo("检测到热键 " + _toggleKey + "（UI 显隐）");
                if (UI != null) UI.ToggleVisible();
                else Log?.LogWarning("UI 尚未就绪，稍后再按一次。");
            }

            if (_playPauseKey != KeyCode.None && Input.GetKeyDown(_playPauseKey))
            {
                Log?.LogInfo("检测到热键 " + _playPauseKey + "（播放/暂停）");
                Playlist?.TogglePlayPause();
            }

            if (_nextKey != KeyCode.None && Input.GetKeyDown(_nextKey)) _ = Playlist?.NextAsync();
            if (_prevKey != KeyCode.None && Input.GetKeyDown(_prevKey)) _ = Playlist?.PrevAsync();

            // 兜底：先卸载插件资源，再退出游戏。游戏自己的关闭流程如果会卡住，
            // 用这个键可以干净退出（也能帮我们判断"卡住"到底是不是插件资源引起的）。
            if (_safeQuitKey != KeyCode.None && Input.GetKeyDown(_safeQuitKey))
            {
                Log?.LogInfo("检测到热键 " + _safeQuitKey + "（安全退出）");
                BeginShutdown("安全退出热键");
                try { Application.Quit(); } catch (Exception e) { Log?.LogError("退出游戏失败: " + e); }
            }
        }

        // ------------------------------------------------------------------ 媒体键

        private void OnMediaKey(MediaKeyAction action)
        {
            switch (action)
            {
                case MediaKeyAction.PlayPause:
                    Playlist?.TogglePlayPause();
                    break;
                case MediaKeyAction.Next:
                    _ = Playlist?.NextAsync();
                    break;
                case MediaKeyAction.Previous:
                    _ = Playlist?.PrevAsync();
                    break;
                case MediaKeyAction.Stop:
                    Audio?.StopPlayback();
                    break;
            }
        }

        private static void OnPlaybackStateChangedForDucking(PlayerState state, string message)
        {
            try { Patches.SetDucking(state == PlayerState.Playing); }
            catch (Exception e) { Log?.LogDebug("切换 BGM 压低失败: " + e.Message); }
        }
    }
}

using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace ChillQQMusic
{
    /// <summary>LRC 歌词解析（支持一行多时间戳与翻译对齐）。</summary>
    internal static class LyricsParser
    {
        private static readonly Regex TimeTag = new Regex(@"\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]", RegexOptions.Compiled);

        internal static Lyrics Parse(string lrc, string translation)
        {
            var result = new Lyrics { Raw = lrc ?? string.Empty };
            if (string.IsNullOrWhiteSpace(lrc)) return result;

            var lines = ParseSingle(lrc);
            var trans = ParseSingle(translation);

            foreach (var line in lines)
            {
                if (IsMetaLine(line.Text)) continue;
                foreach (var t in trans)
                {
                    if (Math.Abs(t.Time - line.Time) < 0.35 && !string.IsNullOrWhiteSpace(t.Text))
                    {
                        line.Translation = t.Text;
                        break;
                    }
                }
                result.Lines.Add(line);
            }

            result.Lines.Sort((a, b) => a.Time.CompareTo(b.Time));
            return result;
        }

        private static List<LyricLine> ParseSingle(string text)
        {
            var list = new List<LyricLine>();
            if (string.IsNullOrWhiteSpace(text)) return list;

            foreach (var raw in text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
            {
                var matches = TimeTag.Matches(raw);
                if (matches.Count == 0) continue;

                var content = TimeTag.Replace(raw, string.Empty).Trim();
                foreach (Match m in matches)
                {
                    var minutes = int.Parse(m.Groups[1].Value);
                    var seconds = int.Parse(m.Groups[2].Value);
                    var fractionText = m.Groups[3].Value;
                    double fraction = 0;
                    if (!string.IsNullOrEmpty(fractionText))
                    {
                        var value = int.Parse(fractionText);
                        fraction = fractionText.Length == 1 ? value / 10.0
                                 : fractionText.Length == 2 ? value / 100.0
                                 : value / 1000.0;
                    }

                    list.Add(new LyricLine
                    {
                        Time = minutes * 60 + seconds + fraction,
                        Text = content
                    });
                }
            }

            list.Sort((a, b) => a.Time.CompareTo(b.Time));
            return list;
        }

        private static bool IsMetaLine(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return true;
            var t = text.TrimStart();
            return t.StartsWith("作词", StringComparison.Ordinal) || t.StartsWith("作曲", StringComparison.Ordinal)
                || t.StartsWith("编曲", StringComparison.Ordinal) || t.StartsWith("制作", StringComparison.Ordinal)
                || t.StartsWith("QQ音乐", StringComparison.OrdinalIgnoreCase) || t.StartsWith("混音", StringComparison.Ordinal);
        }

        /// <summary>返回当前时间对应的歌词行索引，找不到返回 -1。</summary>
        internal static int FindIndex(IReadOnlyList<LyricLine> lines, double time)
        {
            if (lines == null || lines.Count == 0) return -1;
            int index = -1;
            for (int i = 0; i < lines.Count; i++)
            {
                if (lines[i].Time <= time + 0.15) index = i;
                else break;
            }
            return index;
        }
    }
}

// MfDecode.dll —— 用 Windows 自带的 Media Foundation 把 m4a/AAC 解码成 16bit PCM WAV。
//
// 为什么需要它：Unity（Windows 平台）的 UnityWebRequest 不支持 AAC/m4a 解码
// （AudioType.ACC 只在 iOS/Android 生效），而 QQ 音乐 CDN 只会下发 m4a。
// 这里调用系统解码器（Media Foundation Source Reader）转成 Unity 能直接吃的 WAV。
//
// 导出： int __stdcall MfDecodeToWav(const wchar_t* inPath, const wchar_t* outPath)
//        成功返回写入的 PCM 字节数（>0），失败返回负值。
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <mferror.h>
#include <string>

#pragma comment(lib, "mfplat.lib")
#pragma comment(lib, "mfreadwrite.lib")
#pragma comment(lib, "mfuuid.lib")
#pragma comment(lib, "ole32.lib")

template <class T> static void SafeRelease(T** pp)
{
    if (*pp) { (*pp)->Release(); *pp = NULL; }
}

static DWORD WriteAll(HANDLE file, const void* data, DWORD size)
{
    DWORD written = 0;
    return WriteFile(file, data, size, &written, NULL) ? written : 0;
}

static void WriteLE32(BYTE* p, DWORD v) { p[0] = (BYTE)v; p[1] = (BYTE)(v >> 8); p[2] = (BYTE)(v >> 16); p[3] = (BYTE)(v >> 24); }
static void WriteLE16(BYTE* p, WORD v) { p[0] = (BYTE)v; p[1] = (BYTE)(v >> 8); }

/// 写标准 44 字节 WAV 头（PCM）
static void WriteWavHeader(HANDLE file, const WAVEFORMATEX* wfx, DWORD dataSize)
{
    BYTE h[44];
    DWORD riffSize = 36 + dataSize;
    memcpy(h + 0, "RIFF", 4);
    WriteLE32(h + 4, riffSize);
    memcpy(h + 8, "WAVE", 4);
    memcpy(h + 12, "fmt ", 4);
    WriteLE32(h + 16, 16);
    WriteLE16(h + 20, 1);                       // PCM
    WriteLE16(h + 22, wfx->nChannels);
    WriteLE32(h + 24, wfx->nSamplesPerSec);
    WriteLE32(h + 28, wfx->nAvgBytesPerSec);
    WriteLE16(h + 32, wfx->nBlockAlign);
    WriteLE16(h + 34, wfx->wBitsPerSample);
    memcpy(h + 36, "data", 4);
    WriteLE32(h + 40, dataSize);
    SetFilePointer(file, 0, NULL, FILE_BEGIN);
    WriteAll(file, h, sizeof(h));
}

extern "C" __declspec(dllexport) int __stdcall MfDecodeToWav(const wchar_t* inPath, const wchar_t* outPath)
{
    if (!inPath || !outPath) return -1;

    HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
    bool comInitialized = SUCCEEDED(hr);

    hr = MFStartup(MF_VERSION, MFSTARTUP_LITE);
    if (FAILED(hr)) { if (comInitialized) CoUninitialize(); return -2; }

    int result = -3;
    IMFSourceReader* reader = NULL;
    IMFMediaType* outType = NULL;
    IMFMediaType* actualType = NULL;
    WAVEFORMATEX* wfx = NULL;
    HANDLE outFile = INVALID_HANDLE_VALUE;

    // Media Foundation 需要 URL 形式：本地路径要转成 file:/// 形式
    std::wstring url(inPath);
    for (size_t i = 0; i < url.size(); i++) if (url[i] == L'\\') url[i] = L'/';
    if (url.find(L"://") == std::wstring::npos)
    {
        if (url.size() >= 2 && url[1] == L':') url = L"file:///" + url;   // D:/xxx → file:///D:/xxx
        else url = L"file:///" + url;
    }

    hr = MFCreateSourceReaderFromURL(url.c_str(), NULL, &reader);
    if (FAILED(hr)) goto cleanup;

    reader->SetStreamSelection(MF_SOURCE_READER_ALL_STREAMS, FALSE);
    reader->SetStreamSelection(MF_SOURCE_READER_FIRST_AUDIO_STREAM, TRUE);

    hr = MFCreateMediaType(&outType);
    if (FAILED(hr)) goto cleanup;
    outType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Audio);
    outType->SetGUID(MF_MT_SUBTYPE, MFAudioFormat_PCM);
    outType->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE, 16);

    hr = reader->SetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM, NULL, outType);
    if (FAILED(hr)) goto cleanup;

    hr = reader->GetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM, &actualType);
    if (FAILED(hr)) goto cleanup;

    UINT32 wfxSize = 0;
    hr = MFCreateWaveFormatExFromMFMediaType(actualType, &wfx, &wfxSize);
    if (FAILED(hr) || !wfx) goto cleanup;

    outFile = CreateFileW(outPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (outFile == INVALID_HANDLE_VALUE) { result = -4; goto cleanup; }

    WriteWavHeader(outFile, wfx, 0);            // 先占位，最后回填真实大小
    SetFilePointer(outFile, 44, NULL, FILE_BEGIN);

    {
        DWORD total = 0;
        for (;;)
        {
            DWORD flags = 0;
            LONGLONG timestamp = 0;
            IMFSample* sample = NULL;
            hr = reader->ReadSample(MF_SOURCE_READER_FIRST_AUDIO_STREAM, 0, NULL, &flags, &timestamp, &sample);
            if (FAILED(hr)) break;
            if (flags & MF_SOURCE_READERF_ENDOFSTREAM) { SafeRelease(&sample); break; }

            if (sample)
            {
                IMFMediaBuffer* buffer = NULL;
                if (SUCCEEDED(sample->ConvertToContiguousBuffer(&buffer)) && buffer)
                {
                    BYTE* data = NULL;
                    DWORD length = 0;
                    if (SUCCEEDED(buffer->Lock(&data, NULL, &length)) && data && length > 0)
                    {
                        total += WriteAll(outFile, data, length);
                        buffer->Unlock();
                    }
                    SafeRelease(&buffer);
                }
                SafeRelease(&sample);
            }
        }

        WriteWavHeader(outFile, wfx, total);    // 回填大小
        result = (int)total;
    }

cleanup:
    if (outFile != INVALID_HANDLE_VALUE) CloseHandle(outFile);
    if (wfx) CoTaskMemFree(wfx);
    SafeRelease(&actualType);
    SafeRelease(&outType);
    SafeRelease(&reader);
    MFShutdown();
    if (comInitialized) CoUninitialize();
    return result;
}

BOOL WINAPI DllMain(HINSTANCE, DWORD, LPVOID) { return TRUE; }

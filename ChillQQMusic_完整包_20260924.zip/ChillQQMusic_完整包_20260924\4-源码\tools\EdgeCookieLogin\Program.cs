// 开发工具：通过 Edge 的 DevTools 协议(CDP)获取 qq.com 的 Cookie。
//
// 为什么这样做：Chromium 127+ 的 Cookie 使用 v20 应用绑定加密，第三方进程无法解密；
// 但浏览器自己有明文（它本来就负责解密），CDP 的 Network.getAllCookies 会把明文交给我们。
//
// 流程：启动一个独立的 Edge 实例（临时用户配置 + 调试端口）→ 打开 QQ 登录页
//       → 每 3 秒轮询一次全部 Cookie → 一旦出现 qm_keyst/qqmusic_key 就写出 Cookie 头。
// 用户只需要在弹出的窗口里扫码。
//
// 用法: EdgeCookieLogin.exe <edge.exe> <tempUserDataDir> <loginUrl> <outCookieFile> <accountDatPath> [timeoutSec]
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

internal static class Program
{
    /// <summary>QQ 音乐网页登录页（含扫码），作为 loginUrl 参数传 "-" 时使用。</summary>
    private const string BuiltInLoginUrl =
        "https://xui.ptlogin2.qq.com/cgi-bin/xlogin?appid=716027609&daid=383&style=33"
        + "&hide_title_bar=1&hide_border=1&target=self&s_url=https%3A%2F%2Fy.qq.com%2F&pt_3rd_aid=100497308";

    private static int Main(string[] args)
    {
        Console.WriteLine("# EdgeCookieLogin 启动，参数 " + args.Length + " 个");
        Console.Out.Flush();

        if (args.Length < 4)
        {
            Console.WriteLine("usage: EdgeCookieLogin <edgeExe> <tempUserDataDir> <loginUrl> <outCookieFile> [timeoutSec]");
            return 2;
        }

        var edgeExe = args[0];
        var userDataDir = args[1];
        var loginUrl = args[2];
        var outFile = args[3];
        var accountDatPath = args[4];
        int timeoutSec;
        if (args.Length <= 5 || !int.TryParse(args[5], out timeoutSec) || timeoutSec <= 0) timeoutSec = 300;

        // 允许用 "-" 表示内置的 QQ 音乐扫码登录页（避免命令行里的 & 被 shell 解释）
        if (loginUrl == "-") loginUrl = BuiltInLoginUrl;

        const int port = 9333;

        Console.WriteLine("# 参数: edge=" + edgeExe);
        Console.WriteLine("#       profile=" + userDataDir);
        Console.WriteLine("#       url=" + loginUrl);
        Console.WriteLine("#       timeout=" + timeoutSec + "s");
        Console.Out.Flush();

        Directory.CreateDirectory(userDataDir);

        var arguments = "--remote-debugging-port=" + port
                        + " --user-data-dir=\"" + userDataDir + "\""
                        + " --no-first-run --no-default-browser-check --disable-features=msEdgeSidebarV2"
                        + " \"" + loginUrl + "\"";

        Console.WriteLine("# 启动 Edge（独立临时配置，不影响你原来的窗口）…");
        Process process = null;

        // 如果调试端口已经在监听（说明已有可用窗口），就直接附着，不再新开窗口
        if (PortAlive(port))
        {
            Console.WriteLine("# 检测到已存在的调试端口，直接附着到现有 Edge 窗口（不再新开）。");
        }
        else
        {
            process = Process.Start(new ProcessStartInfo(edgeExe, arguments) { UseShellExecute = false });
        }

        var deadline = DateTime.UtcNow.AddSeconds(timeoutSec);
        string wsUrl = null;

        // 1) 等调试端口可用
        while (DateTime.UtcNow < deadline && wsUrl == null)
        {
            try
            {
                var json = HttpGet("http://127.0.0.1:" + port + "/json/list");
                var match = Regex.Match(json, "\"type\"\\s*:\\s*\"page\"[^}]*\"webSocketDebuggerUrl\"\\s*:\\s*\"(?<u>[^\"]+)\"");
                if (!match.Success)
                    match = Regex.Match(json, "\"webSocketDebuggerUrl\"\\s*:\\s*\"(?<u>[^\"]+)\"");
                if (match.Success) wsUrl = match.Groups["u"].Value.Replace("\\/", "/");
            }
            catch { /* 还没起来 */ }

            if (wsUrl == null) Thread.Sleep(1000);
        }

        if (wsUrl == null)
        {
            Console.WriteLine("# 无法连接到 Edge 调试端口，已放弃。");
            return 3;
        }

        Console.WriteLine("# 已连接调试端口，等待扫码登录…（最多 " + timeoutSec + " 秒）");

        using (var socket = new ClientWebSocket())
        {
            socket.ConnectAsync(new Uri(wsUrl), CancellationToken.None).Wait();
            Send(socket, "{\"id\":1,\"method\":\"Network.enable\"}");

            var id = 2;
            while (DateTime.UtcNow < deadline)
            {
                Thread.Sleep(3000);
                try
                {
                    Send(socket, "{\"id\":" + id + ",\"method\":\"Network.getAllCookies\"}");
                    // 注意：启用了 Network 域之后浏览器会不停推事件消息，
                    // 必须一直读到"id 匹配的那条回复"，否则会误读事件、得到 0 条 Cookie。
                    var reply = ReceiveReply(socket, id, 20000);
                    id++;
                    if (string.IsNullOrEmpty(reply)) continue;

                    if (reply.IndexOf("\"error\"", StringComparison.Ordinal) >= 0)
                    {
                        var errorMatch = Regex.Match(reply, "\"message\"\\s*:\\s*\"([^\"]*)\"");
                        Console.WriteLine("# CDP 返回错误: " + (errorMatch.Success ? errorMatch.Groups[1].Value : reply.Substring(0, Math.Min(160, reply.Length))));
                    }

                    var cookies = Parse(qqCookies(reply));
                    var hasKey = cookies.Exists(c => c.Name == "qm_keyst" || c.Name == "qqmusic_key");
                    Console.WriteLine("# 轮询: qq.com Cookie " + cookies.Count + " 条"
                        + (hasKey ? "，已发现音乐 Key ✅" : "（尚未登录）"));
                    Console.Out.Flush();

                    if (hasKey && cookies.Count > 0)
                    {
                        var header = string.Join("; ", cookies.ConvertAll(c => c.Name + "=" + c.Value));
                        File.WriteAllText(outFile, header, new UTF8Encoding(false));
                        Console.WriteLine("# 已写出 Cookie 头（" + header.Length + " 字符）到 " + outFile);
                        Console.WriteLine("# 字段: " + string.Join(", ", cookies.ConvertAll(c => c.Name)));

                        var purlOk = VerifyPlayback(header);
                        Console.WriteLine("# 播放地址校验: " + (purlOk
                            ? "通过 ✅ 已能获取 purl，登录确定可用"
                            : "未通过 ⚠ 可能只是探测歌曲无版权，插件里仍可再试"));

                        if (accountDatPath.EndsWith(".b64", StringComparison.OrdinalIgnoreCase))
                        {
                            // 跨用户场景：写 base64 明文导入文件，由游戏用自己的身份加密保存
                            var b64 = "base64:" + Convert.ToBase64String(Encoding.UTF8.GetBytes(header));
                            File.WriteAllText(accountDatPath, b64, new UTF8Encoding(false));
                            Console.WriteLine("# 已写出导入文件（base64）: " + accountDatPath);
                        }
                        else
                        {
                            WriteAccountDat(accountDatPath, header);
                            Console.WriteLine("# 已写入插件凭证（DPAPI 加密）: " + accountDatPath);
                        }
                        Console.WriteLine("# === 全部完成，可以启动游戏了 ===");

                        // 只关掉我们自己启动的这个 Edge 实例（附着模式下不动你的窗口）
                        try { process?.Kill(); } catch { }
                        return 0;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("# 轮询异常: " + e.Message);
                }
            }
        }

        Console.WriteLine("# 超时：没有检测到登录完成。");
        if (process != null) { try { process.Kill(); } catch { } }
        else Console.WriteLine("# （附着模式：保留你的窗口不关闭）");
        return 4;
    }

    private static bool PortAlive(int port)
    {
        try
        {
            using (var client = new WebClient())
            {
                client.Proxy = null;
                var text = client.DownloadString("http://127.0.0.1:" + port + "/json/version");
                return text.Length > 0;
            }
        }
        catch
        {
            return false;
        }
    }

    private sealed class Cookie
    {
        public string Name = string.Empty;
        public string Value = string.Empty;
    }

    private static List<string> qqCookies(string json)
    {
        var list = new List<string>();
        foreach (Match m in Regex.Matches(json, "\\{[^{}]*\\}"))
        {
            var block = m.Value;
            if (block.IndexOf("\"name\"", StringComparison.Ordinal) < 0) continue;
            if (block.IndexOf("qq.com", StringComparison.OrdinalIgnoreCase) < 0) continue;
            list.Add(block);
        }
        return list;
    }

    private static List<Cookie> Parse(List<string> blocks)
    {
        var result = new List<Cookie>();
        foreach (var block in blocks)
        {
            var name = Field(block, "name");
            var value = Field(block, "value");
            var domain = Field(block, "domain");
            if (string.IsNullOrEmpty(name)) continue;
            if (!domain.EndsWith("qq.com", StringComparison.OrdinalIgnoreCase)) continue;
            if (result.Exists(c => c.Name == name)) continue;
            result.Add(new Cookie { Name = name, Value = value });
        }
        return result;
    }

    private static string Field(string json, string key)
    {
        var match = Regex.Match(json, "\"" + key + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
        return match.Success ? Unescape(match.Groups[1].Value) : string.Empty;
    }

    private static string Unescape(string text)
    {
        var sb = new StringBuilder(text.Length);
        for (var i = 0; i < text.Length; i++)
        {
            if (text[i] != '\\' || i + 1 >= text.Length) { sb.Append(text[i]); continue; }
            var c = text[++i];
            switch (c)
            {
                case 'n': sb.Append('\n'); break;
                case 'r': sb.Append('\r'); break;
                case 't': sb.Append('\t'); break;
                case 'u':
                    if (i + 4 < text.Length)
                    {
                        sb.Append((char)Convert.ToInt32(text.Substring(i + 1, 4), 16));
                        i += 4;
                    }
                    break;
                default: sb.Append(c); break;
            }
        }
        return sb.ToString();
    }

    private static string HttpGet(string url)
    {
        using (var client = new WebClient())
        {
            client.Proxy = null;
            client.Encoding = Encoding.UTF8;
            return client.DownloadString(url);
        }
    }

    /// <summary>用拿到的 Cookie 请求一次 vkey，确认真的能拿到播放地址。</summary>
    private static bool VerifyPlayback(string cookieHeader)
    {
        try
        {
            var uinMatch = Regex.Match(cookieHeader, "(?:^|;\\s*)uin=o?(\\d+)", RegexOptions.IgnoreCase);
            var uin = uinMatch.Success ? uinMatch.Groups[1].Value : "0";
            var guid = "1234567890";
            var mids = new[] { "000Ms8EM0k35Ms", "002eq4xl3DVpJX", "004E3bPP0BkUX3" };
            var okCount = 0;

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromSeconds(15);
                client.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
                client.DefaultRequestHeaders.TryAddWithoutValidation("Referer", "https://y.qq.com/");
                client.DefaultRequestHeaders.TryAddWithoutValidation("Cookie", cookieHeader);

                foreach (var mid in mids)
                {
                    var payload = "{\"comm\":{\"ct\":24,\"cv\":0,\"format\":\"json\",\"uin\":\"" + uin + "\",\"platform\":\"yqq.json\"},"
                        + "\"req_0\":{\"module\":\"vkey.GetVkeyServer\",\"method\":\"CgiGetVkey\",\"param\":{\"guid\":\"" + guid + "\","
                        + "\"songmid\":[\"" + mid + "\"],\"songtype\":[0],\"uin\":\"" + uin + "\",\"loginflag\":1,\"platform\":\"20\"}}}";

                    var content = new StringContent(payload, Encoding.UTF8, "application/json");
                    var response = client.PostAsync("https://u.y.qq.com/cgi-bin/musicu.fcg", content).Result;
                    var text = response.Content.ReadAsStringAsync().Result;
                    if (Regex.IsMatch(text, "\"purl\"\\s*:\\s*\"[^\"]+\"")) okCount++;
                }
            }

            Console.WriteLine("# 探测 " + mids.Length + " 首，拿到播放地址的有 " + okCount + " 首");
            return okCount > 0;
        }
        catch (Exception e)
        {
            Console.WriteLine("# 校验异常: " + e.Message);
            return false;
        }
    }

    /// <summary>按插件 SecureCookieStore 的格式写入凭证文件。</summary>
    private static void WriteAccountDat(string path, string cookieHeader)
    {
        var plain = Encoding.UTF8.GetBytes(cookieHeader);
        var entropy = Encoding.UTF8.GetBytes("ChillQQMusic.CookieStore.v1");
        var cipher = ProtectedData.Protect(plain, entropy, DataProtectionScope.CurrentUser);

        var magic = new byte[] { 0x43, 0x51, 0x4D, 0x31 };   // "CQM1"
        var body = new byte[magic.Length + 1 + cipher.Length];
        Buffer.BlockCopy(magic, 0, body, 0, magic.Length);
        body[magic.Length] = 1;                               // 1 = DPAPI
        Buffer.BlockCopy(cipher, 0, body, magic.Length + 1, cipher.Length);

        Directory.CreateDirectory(Path.GetDirectoryName(path));
        File.WriteAllBytes(path, body);
    }

    private static void Send(ClientWebSocket socket, string text)
    {
        var bytes = Encoding.UTF8.GetBytes(text);
        socket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None).Wait();
    }

    private static string Receive(ClientWebSocket socket, int timeoutMs)
    {
        var buffer = new byte[1024 * 1024];
        var builder = new StringBuilder();
        var deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs);

        while (DateTime.UtcNow < deadline)
        {
            var task = socket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
            if (!task.Wait(Math.Max(1, (int)(deadline - DateTime.UtcNow).TotalMilliseconds))) return builder.ToString();
            var result = task.Result;
            if (result.MessageType == WebSocketMessageType.Close) return builder.ToString();
            builder.Append(Encoding.UTF8.GetString(buffer, 0, result.Count));
            if (result.EndOfMessage) return builder.ToString();
        }
        return builder.ToString();
    }

    /// <summary>读到指定 id 的命令回复为止（跳过浏览器主动推送的事件）。</summary>
    private static string ReceiveReply(ClientWebSocket socket, int id, int timeoutMs)
    {
        var deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs);
        while (DateTime.UtcNow < deadline)
        {
            var remaining = (int)Math.Max(1, (deadline - DateTime.UtcNow).TotalMilliseconds);
            var message = Receive(socket, remaining);
            if (string.IsNullOrEmpty(message)) continue;
            if (message.IndexOf("\"id\":" + id, StringComparison.Ordinal) >= 0) return message;
        }
        return null;
    }
}

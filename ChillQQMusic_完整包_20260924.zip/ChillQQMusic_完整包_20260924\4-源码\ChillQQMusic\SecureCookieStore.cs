using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using BepInEx;

namespace ChillQQMusic
{
    /// <summary>
    /// 登录凭证持久化。
    /// 首选 Windows DPAPI（CryptProtectData，绑定当前用户账户）加密；
    /// 若运行环境不支持 DPAPI，则退化为「机器+用户」派生密钥的 AES 混淆，并明确警告。
    /// 任何情况下都不会把 Cookie 明文写进 BepInEx 配置。
    /// </summary>
    internal static class SecureCookieStore
    {
        private const string EntropyText = "ChillQQMusic.CookieStore.v1";
        private static readonly byte[] Magic = { (byte)'C', (byte)'Q', (byte)'M', (byte)'1' };

        internal static string DirectoryPath
        {
            get
            {
                var dir = Path.Combine(Paths.ConfigPath, "ChillQQMusic");
                Directory.CreateDirectory(dir);
                return dir;
            }
        }

        internal static string FilePath => Path.Combine(DirectoryPath, "account.dat");

        internal static bool UsesDpapi { get; private set; } = true;

        internal static void Save(string payload)
        {
            if (string.IsNullOrEmpty(payload))
            {
                Clear();
                return;
            }

            byte[] plain = Encoding.UTF8.GetBytes(payload);
            byte[] body = Protect(plain);

            // 先写临时文件再替换，避免写一半崩溃导致凭证损坏。
            var tmp = FilePath + ".tmp";
            File.WriteAllBytes(tmp, body);
            if (System.IO.File.Exists(FilePath)) System.IO.File.Delete(FilePath);
            System.IO.File.Move(tmp, FilePath);
            Plugin.Log?.LogInfo("登录凭证已保存（" + (UsesDpapi ? "DPAPI 加密" : "AES 混淆") + "）: " + FilePath);
        }

        internal static string Load()
        {
            try
            {
                if (!System.IO.File.Exists(FilePath)) return null;
                var body = System.IO.File.ReadAllBytes(FilePath);
                var plain = Unprotect(body);
                return plain == null ? null : Encoding.UTF8.GetString(plain);
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("读取登录凭证失败，将忽略: " + e.Message);
                return null;
            }
        }

        internal static void Clear()
        {
            try
            {
                if (System.IO.File.Exists(FilePath)) System.IO.File.Delete(FilePath);
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("删除登录凭证失败: " + e.Message);
            }
        }

        private static byte[] Protect(byte[] plain)
        {
            try
            {
                var entropy = Encoding.UTF8.GetBytes(EntropyText);
                var cipher = ProtectedData.Protect(plain, entropy, DataProtectionScope.CurrentUser);
                UsesDpapi = true;
                return Concat(Magic, new byte[] { 1 }, cipher);
            }
            catch (Exception e)
            {
                UsesDpapi = false;
                Plugin.Log?.LogWarning("DPAPI 不可用（" + e.GetType().Name + "），退化为 AES 混淆存储。");
                return Concat(Magic, new byte[] { 2 }, FallbackEncrypt(plain));
            }
        }

        private static byte[] Unprotect(byte[] body)
        {
            if (body.Length < 6) throw new InvalidDataException("凭证文件损坏");
            for (int i = 0; i < Magic.Length; i++)
                if (body[i] != Magic[i]) throw new InvalidDataException("凭证文件格式不匹配");

            byte mode = body[4];
            var payload = new byte[body.Length - 5];
            Buffer.BlockCopy(body, 5, payload, 0, payload.Length);

            if (mode == 1)
            {
                UsesDpapi = true;
                var entropy = Encoding.UTF8.GetBytes(EntropyText);
                return ProtectedData.Unprotect(payload, entropy, DataProtectionScope.CurrentUser);
            }

            UsesDpapi = false;
            return FallbackDecrypt(payload);
        }

        private static byte[] FallbackEncrypt(byte[] plain)
        {
            using (var aes = Aes.Create())
            {
                aes.Key = DeriveKey();
                aes.GenerateIV();
                using (var enc = aes.CreateEncryptor())
                {
                    var cipher = enc.TransformFinalBlock(plain, 0, plain.Length);
                    return Concat(aes.IV, cipher);
                }
            }
        }

        private static byte[] FallbackDecrypt(byte[] body)
        {
            using (var aes = Aes.Create())
            {
                aes.Key = DeriveKey();
                var iv = new byte[16];
                Buffer.BlockCopy(body, 0, iv, 0, 16);
                aes.IV = iv;
                using (var dec = aes.CreateDecryptor())
                {
                    return dec.TransformFinalBlock(body, 16, body.Length - 16);
                }
            }
        }

        private static byte[] DeriveKey()
        {
            // 注意：这是「混淆」而不是强加密，只为在 DPAPI 不可用时避免明文落盘。
            var material = Environment.MachineName + "|" + Environment.UserName + "|ChillQQMusic";
            using (var kdf = new Rfc2898DeriveBytes(material, Encoding.UTF8.GetBytes("ChillQQMusicSaltV1"), 20000))
                return kdf.GetBytes(32);
        }

        private static byte[] Concat(byte[] a, byte[] b)
        {
            var r = new byte[a.Length + b.Length];
            Buffer.BlockCopy(a, 0, r, 0, a.Length);
            Buffer.BlockCopy(b, 0, r, a.Length, b.Length);
            return r;
        }

        private static byte[] Concat(byte[] a, byte[] b, byte[] c)
        {
            var r = new byte[a.Length + b.Length + c.Length];
            Buffer.BlockCopy(a, 0, r, 0, a.Length);
            Buffer.BlockCopy(b, 0, r, a.Length, b.Length);
            Buffer.BlockCopy(c, 0, r, a.Length + b.Length, c.Length);
            return r;
        }
    }
}

using System;
using System.IO;
using BepInEx.Configuration;

namespace ChillQQMusic
{
    /// <summary>集中管理 BepInEx 配置项，UI / 播放 / 网络全部通过它读取参数。</summary>
    public sealed class ConfigManager
    {
        public ConfigFile File { get; }

        // ---- 一、通用 ----
        public ConfigEntry<string> PlaylistId { get; private set; }
        public ConfigEntry<string> PlaylistUrl { get; private set; }
        public ConfigEntry<string> UserUid { get; private set; }
        public ConfigEntry<ApiMode> ApiMode { get; private set; }
        public ConfigEntry<string> ApiBaseUrl { get; private set; }
        public ConfigEntry<string> ApiToken { get; private set; }
        public ConfigEntry<AudioQuality> Quality { get; private set; }
        public ConfigEntry<string> DeviceGuid { get; private set; }

        // ---- 二、快捷键 ----
        public ConfigEntry<string> HotkeyToggleUi { get; private set; }
        public ConfigEntry<string> HotkeyPlayPause { get; private set; }
        public ConfigEntry<string> HotkeyNext { get; private set; }
        public ConfigEntry<string> HotkeyPrev { get; private set; }
        public ConfigEntry<string> HotkeySafeQuit { get; private set; }
        public ConfigEntry<bool> EnableMediaKeys { get; private set; }

        // ---- 三、播放 ----
        public ConfigEntry<float> Volume { get; private set; }
        public ConfigEntry<PlayMode> DefaultPlayMode { get; private set; }
        public ConfigEntry<bool> AutoPlayOnStart { get; private set; }
        public ConfigEntry<bool> IgnoreListenerPause { get; private set; }
        public ConfigEntry<bool> EnableDiskCache { get; private set; }
        public ConfigEntry<int> CacheMaxMegabytes { get; private set; }
        public ConfigEntry<bool> StreamWhileDownloading { get; private set; }
        public ConfigEntry<int> PrefetchSeconds { get; private set; }

        // ---- 四、UI ----
        public ConfigEntry<float> UiPosX { get; private set; }
        public ConfigEntry<float> UiPosY { get; private set; }
        public ConfigEntry<float> UiScale { get; private set; }
        public ConfigEntry<float> UiOpacity { get; private set; }
        public ConfigEntry<float> UiIdleOpacity { get; private set; }
        public ConfigEntry<float> FadeDelaySeconds { get; private set; }
        public ConfigEntry<bool> ShowLyrics { get; private set; }
        public ConfigEntry<bool> IdleFade { get; private set; }
        public ConfigEntry<float> ShowOnStartSeconds { get; private set; }
        public ConfigEntry<bool> ShowUiOnStart { get; private set; }
        public ConfigEntry<bool> ShowSideButton { get; private set; }
        public ConfigEntry<float> SideButtonOffsetY { get; private set; }

        // ---- 五、网络 ----
        public ConfigEntry<int> TimeoutSeconds { get; private set; }
        public ConfigEntry<int> RetryCount { get; private set; }
        public ConfigEntry<bool> VerboseLogging { get; private set; }

        // ---- 六、Harmony 补丁 ----
        public ConfigEntry<bool> EnableHarmonyPatches { get; private set; }
        public ConfigEntry<bool> InjectGameUiButton { get; private set; }
        public ConfigEntry<bool> DuckGameBgm { get; private set; }
        public ConfigEntry<float> DuckDecibels { get; private set; }

        public ConfigManager(ConfigFile file)
        {
            File = file ?? throw new ArgumentNullException(nameof(file));
            BindAll();
        }

        private void BindAll()
        {
            const string general = "01-通用";
            PlaylistId = File.Bind(general, "歌单ID", "",
                "QQ 音乐歌单 ID（纯数字）。留空即可 —— 默认走「游戏内绑定」："
                + "打开播放器面板 → 点右上角「歌单」按钮 → 填歌单 ID（或分享链接/短码）→ 点「绑定」，"
                + "插件会把它写回这里。与「歌单链接」二选一，两个都填时以链接为准。");
            PlaylistUrl = File.Bind(general, "歌单链接", "",
                "QQ 音乐歌单分享链接 / 分享短码，插件会自动提取其中的数字 ID。");
            UserUid = File.Bind(general, "用户UID", "",
                "QQ 音乐用户主页 UID（形如 y.qq.com/n/ryqq/profile?uid=GQ7L16LGB 里的那串）。"
                + "仅当「歌单ID」「歌单链接」都为空时生效：插件会加载该用户的公开歌单合集。"
                + "也可以在游戏内「歌单」面板的第二个输入框里填写并点「列歌单」。"
                + "注意：uid 解析成数字 uin 需要登录态。");
            ApiMode = File.Bind(general, "API模式", ChillQQMusic.ApiMode.DirectQqWeb,
                "DirectQqWeb = 直连 QQ 音乐 Web 接口（默认）；CustomRest = 使用自定义 REST API（需填写 API 地址）。");
            ApiBaseUrl = File.Bind(general, "自定义API地址", "http://127.0.0.1:8080",
                "仅当 API模式 = CustomRest 时生效。约定见 README：/playlist /songurl /lyric /user/playlists。");
            ApiToken = File.Bind(general, "自定义API令牌", "",
                "可选。会以 Authorization: Bearer <token> 发送给自定义 API。");
            Quality = File.Bind(general, "音质", AudioQuality.MP3_320,
                "默认 320K。M4A_128 / MP3_128 无需会员；MP3_320 与 FLAC 通常需要绿钻，"
                + "失败时插件按 320K → 128K → M4A 顺序自动降级。");
            DeviceGuid = File.Bind(general, "设备GUID", "",
                "调用 VKey 接口用的 10 位设备号，留空则首次运行时自动生成并写回。");

            const string hotkey = "02-快捷键";
            HotkeyToggleUi = File.Bind(hotkey, "显示隐藏UI", "F8",
                "KeyCode 名称，例如 F8 / F9 / BackQuote / Home。");
            HotkeyPlayPause = File.Bind(hotkey, "播放暂停", "F9", "留空则禁用。");
            HotkeyNext = File.Bind(hotkey, "下一首", "F10", "留空则禁用。");
            HotkeyPrev = File.Bind(hotkey, "上一首", "F7", "留空则禁用。");
            HotkeySafeQuit = File.Bind(hotkey, "安全退出", "",
                "留空 = 禁用（默认）。填一个 KeyCode（例如 F11）后，按它会先卸载插件资源"
                + "（停播、释放播放中的网络请求与 AudioClip、注销媒体键）再退出游戏。"
                + "这是个兜底开关：如果直接关游戏会卡住，用它可以干净退出。");
            EnableMediaKeys = File.Bind(hotkey, "系统媒体键", true,
                "注册键盘上的 播放/暂停、上一首、下一首 媒体键。注意：注册成功后其他程序在游戏运行期间收不到这些按键。");

            const string playback = "03-播放";
            Volume = File.Bind(playback, "音量", 0.65f, "0~1。");
            DefaultPlayMode = File.Bind(playback, "播放模式", PlayMode.Sequential, "Sequential / RepeatOne / Shuffle。");
            AutoPlayOnStart = File.Bind(playback, "启动后自动播放", false, "游戏启动并加载歌单后自动开始播放。");
            IgnoreListenerPause = File.Bind(playback, "忽略游戏暂停", true,
                "游戏切到后台/暂停时仍然继续播放音乐。");
            EnableDiskCache = File.Bind(playback, "启用磁盘缓存", true,
                "完整下载过的歌曲会缓存到本地，下次秒开（不会绕过任何版权限制，仅缓存已成功播放的内容）。");
            CacheMaxMegabytes = File.Bind(playback, "缓存上限MB", 1024, "超过后按最久未使用自动清理，最低 128。");
            StreamWhileDownloading = File.Bind(playback, "边下边播", true,
                "已停用：实测本作 Unity 2022.3 的流式播放会导致时长恒为 0、不发声、进度条不动，"
                + "插件固定改为\"完整下载后再播放\"（每首约 2~5 秒，有缓冲进度提示）。此开关目前仅作记录。");
            PrefetchSeconds = File.Bind(playback, "预取下一首提前秒数", 15, "距离歌曲结束还有多少秒时开始解析下一首地址。");

            const string ui = "04-界面";
            UiPosX = File.Bind(ui, "X坐标", 60f, "悬浮窗位置（相对屏幕左下角，UI 参考分辨率 1920x1080）。");
            UiPosY = File.Bind(ui, "Y坐标", 140f, "见上。");
            UiScale = File.Bind(ui, "缩放", 1.0f, "0.6 ~ 2.0。");
            UiOpacity = File.Bind(ui, "显示时透明度", 0.94f, "0~1。");
            UiIdleOpacity = File.Bind(ui, "闲置时透明度", 0.25f,
                "鼠标离开一段时间后淡出的目标透明度，0 表示完全隐藏。默认 0.25 是为了「一眼能看到悬浮窗在哪」。");
            FadeDelaySeconds = File.Bind(ui, "淡出延迟秒数", 4f, "鼠标离开悬浮窗多久后开始淡出。");
            ShowLyrics = File.Bind(ui, "显示歌词", true, "是否显示歌词区域。");
            IdleFade = File.Bind(ui, "鼠标离开后淡出", false,
                "默认关闭：鼠标离开时悬浮窗保持「显示时透明度」不淡出。想要淡出效果时改成 true。");
            ShowOnStartSeconds = File.Bind(ui, "启动时完整显示秒数", 20f,
                "游戏启动后先完整显示这么久，方便确认 UI 位置；0 = 不特殊处理。");
            ShowUiOnStart = File.Bind(ui, "启动时显示UI", false,
                "false（默认）= 进游戏时悬浮窗保持隐藏，按 F8 或点游戏内音符按钮才出现；true = 启动即显示。");
            ShowSideButton = File.Bind(ui, "左侧呼出按钮", true,
                "在屏幕最左侧放一个圆形音符按钮（与游戏原生按钮同风格、同尺寸），点击即可显示/隐藏播放器。");
            SideButtonOffsetY = File.Bind(ui, "左侧按钮纵向偏移", 0f,
                "相对屏幕垂直中心的偏移（正数向上）。默认 0 = 正中间。");

            const string network = "05-网络";
            TimeoutSeconds = File.Bind(network, "超时秒数", 15, "单次请求超时。");
            RetryCount = File.Bind(network, "重试次数", 2, "失败后的重试次数（指数退避）。");
            VerboseLogging = File.Bind(network, "详细日志", false, "输出调试日志。");

            const string patches = "06-Harmony补丁";
            EnableHarmonyPatches = File.Bind(patches, "启用Harmony补丁", true,
                "总开关。关闭后插件只用快捷键/悬浮窗，不碰游戏任何代码。");
            InjectGameUiButton = File.Bind(patches, "注入游戏UI按钮", false,
                "挂钩 Bulbul.ExitUI.Setup() 克隆退出按钮加音乐入口。默认关闭：改用屏幕左侧的独立呼出按钮，"
                + "避免和游戏退出按钮混淆。");
            DuckGameBgm = File.Bind(patches, "播放时压低游戏BGM", false,
                "挂钩 Bulbul.AudioMixerGroupContainer.GetDecibel()，播放时把 Music/AmbientBGM 压低，暂停/停止立刻恢复；"
                + "全程走游戏自身的音量代码。默认关闭：播放音乐时不影响游戏原声。");
            DuckDecibels = File.Bind(patches, "压低分贝", 8f, "3~24 dB，越大游戏背景音越小。");

            EnsureDeviceGuid();
        }

        private void EnsureDeviceGuid()
        {
            if (!string.IsNullOrEmpty(DeviceGuid.Value) && DeviceGuid.Value.Length == 10) return;
            var rnd = new System.Random();
            var guid = string.Empty;
            for (int i = 0; i < 10; i++) guid += rnd.Next(0, 10).ToString();
            DeviceGuid.Value = guid;
            try { File.Save(); } catch (Exception e) { Plugin.Log?.LogWarning("保存设备GUID失败: " + e.Message); }
        }

        /// <summary>解析用户填写的歌单（ID 优先，链接其次）。</summary>
        public string ResolvePlaylistId()
        {
            var fromUrl = PlaylistUrl != null ? PlaylistUrl.Value : null;
            if (!string.IsNullOrWhiteSpace(fromUrl))
            {
                var extracted = PlaylistManager.ExtractPlaylistId(fromUrl);
                if (!string.IsNullOrEmpty(extracted)) return extracted;
            }
            return (PlaylistId?.Value ?? string.Empty).Trim();
        }

        public string ConfigDirectory
        {
            get
            {
                var dir = Path.Combine(BepInEx.Paths.ConfigPath, "ChillQQMusic");
                try { Directory.CreateDirectory(dir); } catch { /* 忽略 */ }
                return dir;
            }
        }

        public void Save()
        {
            try { File.Save(); }
            catch (Exception e) { Plugin.Log?.LogWarning("保存配置失败: " + e.Message); }
        }
    }
}

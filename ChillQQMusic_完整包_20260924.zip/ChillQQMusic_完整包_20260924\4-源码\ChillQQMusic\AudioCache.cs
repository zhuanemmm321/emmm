using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace ChillQQMusic
{
    /// <summary>已完整播放过的音频文件缓存（LRU 清理）。</summary>
    internal sealed class AudioCache
    {
        private readonly long _maxBytes;
        private readonly object _sync = new object();

        internal string Root { get; }
        internal bool Enabled { get; }

        internal AudioCache(string root, bool enabled, int maxMegabytes)
        {
            Root = root;
            Enabled = enabled;
            _maxBytes = Math.Max(128, maxMegabytes) * 1024L * 1024L;
            if (!Enabled) return;
            try { Directory.CreateDirectory(Root); }
            catch (Exception e) { Plugin.Log?.LogWarning("创建缓存目录失败: " + e.Message); }
        }

        internal string GetPath(SongInfo song, AudioQuality quality, string container)
        {
            var key = (song?.Mid ?? song?.SongId.ToString() ?? "unknown") + "|" + quality + "|" + container;
            var hash = Hash(key);
            var ext = string.IsNullOrEmpty(container) ? "bin" : container;
            return Path.Combine(Root, hash + "." + ext);
        }

        internal bool TryGetFile(SongInfo song, AudioQuality quality, string container, out string path)
        {
            path = null;
            if (!Enabled) return false;
            try
            {
                var candidate = GetPath(song, quality, container);
                if (!File.Exists(candidate)) return false;
                if (new FileInfo(candidate).Length < 32 * 1024) return false;   // 视为不完整
                File.SetLastAccessTimeUtc(candidate, DateTime.UtcNow);
                path = candidate;
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>后台线程写盘，避免卡住主线程。</summary>
        internal void SaveAsync(string path, byte[] data)
        {
            if (!Enabled || data == null || data.Length < 32 * 1024 || string.IsNullOrEmpty(path)) return;
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    lock (_sync)
                    {
                        var tmp = path + ".part";
                        File.WriteAllBytes(tmp, data);
                        if (File.Exists(path)) File.Delete(path);
                        File.Move(tmp, path);
                    }
                    Trim();
                }
                catch (Exception e)
                {
                    Plugin.Log?.LogDebug("写入缓存失败: " + e.Message);
                }
            });
        }

        /// <summary>超过上限时删除最久未使用的文件。</summary>
        internal void Trim()
        {
            if (!Enabled) return;
            try
            {
                lock (_sync)
                {
                    var files = new DirectoryInfo(Root).GetFiles("*", SearchOption.TopDirectoryOnly)
                        .Where(f => !f.Name.EndsWith(".part"))
                        .OrderBy(f => f.LastAccessTimeUtc)
                        .ToList();
                    long total = files.Sum(f => f.Length);
                    foreach (var f in files)
                    {
                        if (total <= _maxBytes) break;
                        total -= f.Length;
                        try { f.Delete(); } catch { /* 忽略 */ }
                    }
                }
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("清理缓存失败: " + e.Message);
            }
        }

        internal void ClearAll()
        {
            try
            {
                lock (_sync)
                {
                    if (!Directory.Exists(Root)) return;
                    foreach (var f in new DirectoryInfo(Root).GetFiles("*", SearchOption.TopDirectoryOnly))
                    {
                        try { f.Delete(); } catch { /* 忽略 */ }
                    }
                }
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("清空缓存失败: " + e.Message);
            }
        }

        private static string Hash(string text)
        {
            using (var md5 = MD5.Create())
            {
                var bytes = md5.ComputeHash(Encoding.UTF8.GetBytes(text));
                var sb = new StringBuilder(bytes.Length * 2);
                foreach (var b in bytes) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }
    }
}

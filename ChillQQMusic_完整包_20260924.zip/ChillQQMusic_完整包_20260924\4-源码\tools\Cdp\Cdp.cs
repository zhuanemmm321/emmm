// 开发工具：通过 DevTools 协议驱动一个带 --remote-debugging-port 的 Edge/Chrome 页面。
//   Cdp.exe eval  "<javascript>"   → 执行 JS 并打印结果
//   Cdp.exe nav   <url>            → 导航到指定地址
//   Cdp.exe title                  → 打印页面标题
// 端口通过环境变量 CDP_PORT 指定，默认 9333。
using System;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

internal static class Program
{
    private static int Main(string[] args)
    {
        if (args.Length < 1) { Console.WriteLine("usage: Cdp <eval|nav|title> [arg]"); return 2; }

        var port = Environment.GetEnvironmentVariable("CDP_PORT");
        if (string.IsNullOrEmpty(port)) port = "9333";

        var wsUrl = FindPageTarget(port);
        if (wsUrl == null) { Console.WriteLine("# 找不到可调试的页面（端口 " + port + "）"); return 3; }

        using (var socket = new ClientWebSocket())
        {
            socket.ConnectAsync(new Uri(wsUrl), CancellationToken.None).Wait();
            Thread.Sleep(200);

            var command = args[0].ToLowerInvariant();
            string request;
            switch (command)
            {
                case "eval":
                    var js = string.Join(" ", args, 1, args.Length - 1);
                    request = "{\"id\":1,\"method\":\"Runtime.evaluate\",\"params\":{\"expression\":"
                              + Json(js) + ",\"returnByValue\":true,\"awaitPromise\":false}}";
                    break;
                case "evalfile":
                    var fileJs = System.IO.File.ReadAllText(args[1], Encoding.UTF8);
                    request = "{\"id\":1,\"method\":\"Runtime.evaluate\",\"params\":{\"expression\":"
                              + Json(fileJs) + ",\"returnByValue\":true,\"awaitPromise\":false}}";
                    break;
                case "nav":
                    request = "{\"id\":1,\"method\":\"Page.navigate\",\"params\":{\"url\":" + Json(args[1]) + "}}";
                    break;
                case "title":
                    request = "{\"id\":1,\"method\":\"Runtime.evaluate\",\"params\":{\"expression\":\"document.title\",\"returnByValue\":true}}";
                    break;
                default:
                    Console.WriteLine("# 未知命令");
                    return 2;
            }

            Send(socket, request);
            var reply = Receive(socket, 20000);

            var result = Regex.Match(reply, "\"result\"\\s*:\\s*\\{\\s*\"type\"[^}]*\"value\"\\s*:\\s*(\"(?:[^\"\\\\]|\\\\.)*\"|[^,}]+)");
            Console.WriteLine(result.Success ? Unquote(result.Groups[1].Value) : reply);
            return 0;
        }
    }

    private static string FindPageTarget(string port)
    {
        try
        {
            using (var client = new WebClient())
            {
                client.Proxy = null;
                var json = client.DownloadString("http://127.0.0.1:" + port + "/json/list");
                var match = Regex.Match(json, "\\{[^{}]*\"type\"\\s*:\\s*\"page\"[^{}]*\\}");
                if (!match.Success) return null;
                var url = Regex.Match(match.Value, "\"webSocketDebuggerUrl\"\\s*:\\s*\"([^\"]+)\"");
                return url.Success ? url.Groups[1].Value.Replace("\\/", "/") : null;
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("# 端口探测失败: " + e.Message);
            return null;
        }
    }

    private static string Json(string text)
    {
        var sb = new StringBuilder("\"");
        foreach (var c in text)
        {
            switch (c)
            {
                case '"': sb.Append("\\\""); break;
                case '\\': sb.Append("\\\\"); break;
                case '\n': sb.Append("\\n"); break;
                case '\r': sb.Append("\\r"); break;
                case '\t': sb.Append("\\t"); break;
                default:
                    if (c < 0x20) sb.Append("\\u").Append(((int)c).ToString("x4"));
                    else sb.Append(c);
                    break;
            }
        }
        return sb.Append('"').ToString();
    }

    private static string Unquote(string text)
    {
        if (text.Length >= 2 && text[0] == '"' && text[text.Length - 1] == '"') text = text.Substring(1, text.Length - 2);
        var sb = new StringBuilder();
        for (var i = 0; i < text.Length; i++)
        {
            if (text[i] != '\\' || i + 1 >= text.Length) { sb.Append(text[i]); continue; }
            var c = text[++i];
            switch (c)
            {
                case 'n': sb.Append('\n'); break;
                case 'r': sb.Append('\r'); break;
                case 't': sb.Append('\t'); break;
                case 'u':
                    if (i + 4 < text.Length) { sb.Append((char)Convert.ToInt32(text.Substring(i + 1, 4), 16)); i += 4; }
                    break;
                default: sb.Append(c); break;
            }
        }
        return sb.ToString();
    }

    private static void Send(ClientWebSocket socket, string text)
    {
        var bytes = Encoding.UTF8.GetBytes(text);
        socket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None).Wait();
    }

    private static string Receive(ClientWebSocket socket, int timeoutMs)
    {
        var buffer = new byte[1024 * 512];
        var builder = new StringBuilder();
        var deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs);
        while (DateTime.UtcNow < deadline)
        {
            var task = socket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
            if (!task.Wait(Math.Max(1, (int)(deadline - DateTime.UtcNow).TotalMilliseconds))) break;
            var result = task.Result;
            if (result.MessageType == WebSocketMessageType.Close) break;
            builder.Append(Encoding.UTF8.GetString(buffer, 0, result.Count));
            if (result.EndOfMessage) break;
        }
        return builder.ToString();
    }
}

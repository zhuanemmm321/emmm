using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace ChillQQMusic
{
    public enum LoginState
    {
        LoggedOut,
        RequestingQr,
        WaitingScan,
        Scanned,
        LoggedIn,
        Failed
    }

    /// <summary>
    /// QQ 扫码登录。流程：ptqrshow 拿二维码 → hash33 算 ptqrtoken → ptqrlogin 轮询 → 落地 Cookie → DPAPI 加密保存。
    /// 另提供「手动粘贴 Cookie」兜底，避免腾讯改接口导致完全不可用。
    /// </summary>
    public sealed class LoginManager : IDisposable
    {
        private const string QrShowUrl =
            "https://ssl.ptlogin2.qq.com/ptqrshow?appid=716027609&e=2&l=M&s=3&d=72&v=4&t={0}&daid=383&pt_3rd_aid=100497308";
        private const string QrLoginUrl =
            "https://ssl.ptlogin2.qq.com/ptqrlogin?u1={0}&ptqrtoken={1}&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052"
            + "&action=0-0-{2}&js_ver=20102616&js_type=1&login_sig=&pt_uistyle=40&aid=716027609&daid=383&pt_3rd_aid=100497308&has_onekey=1";
        /// <summary>
        /// OAuth 跳转地址（已 URL 编码）。必须是**带完整参数的 login_jump**，
        /// 否则扫码成功后跳转链是空转的，拿不到 uin / skey / p_skey，也就换不到 qm_keyst。
        /// client_id = 100497308 就是 QQ 音乐在 QQ 互联的 appid（对应 pt_3rd_aid）。
        /// </summary>
        private static string BuildOAuthJumpUrl()
        {
            var state = Guid.NewGuid().ToString("N");
            var raw = "https://graph.qq.com/oauth2.0/login_jump"
                      + "?response_type=code"
                      + "&client_id=100497308"
                      + "&redirect_uri=" + Uri.EscapeDataString("https://y.qq.com/portal/profile.html")
                      + "&state=" + state;
            return Uri.EscapeDataString(raw);
        }

        private readonly ConfigManager _settings;
        private readonly IQQMusicService _service;

        private CancellationTokenSource _qrCts;

        public event Action<LoginState, string> StateChanged;   // 主线程
        public event Action<Texture2D> QrCodeReady;             // 主线程

        public LoginState State { get; private set; } = LoginState.LoggedOut;
        public QQUserInfo User { get; private set; } = new QQUserInfo();
        public bool IsLoggedIn => State == LoginState.LoggedIn;
        public string StatusText { get; private set; } = "未登录";
        public string QrImagePath => Path.Combine(SecureCookieStore.DirectoryPath, "login_qr.png");

        public LoginManager(ConfigManager settings, IQQMusicService service)
        {
            _settings = settings;
            _service = service;
        }

        public void Dispose() => CancelQrLogin();

        private void SetState(LoginState state, string message)
        {
            State = state;
            StatusText = message;
            Plugin.Log?.LogInfo("[登录] " + state + "：" + message);   // 关键：让登录过程可追踪
            MainThreadDispatcher.Post(() => StateChanged?.Invoke(state, message));
        }

        /// <summary>
        /// 读取配置目录下的 cookie.txt / cookie.b64（可带 base64: 前缀）。
        /// 读完立刻删除，之后由插件用**自己的**用户身份加密保存（解决跨用户写入凭证的问题）。
        /// </summary>
        private static string TryTakeCookieImportFile()
        {
            try
            {
                var dir = SecureCookieStore.DirectoryPath;
                foreach (var name in new[] { "cookie.txt", "cookie.b64" })
                {
                    var path = Path.Combine(dir, name);
                    if (!File.Exists(path)) continue;

                    var text = File.ReadAllText(path).Trim();
                    try { File.Delete(path); } catch { /* 忽略 */ }

                    if (string.IsNullOrWhiteSpace(text)) continue;
                    if (text.StartsWith("base64:", StringComparison.OrdinalIgnoreCase))
                        text = Encoding.UTF8.GetString(Convert.FromBase64String(text.Substring(7).Trim()));

                    return text;
                }
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("[登录] 读取外部导入文件失败: " + e.Message);
            }
            return null;
        }

        // ------------------------------------------------------------------ 恢复 / 导入 / 登出

        /// <summary>启动时尝试用本地保存的凭证恢复登录。</summary>
        public async Task<bool> TryRestoreAsync()
        {
            // 0) 外部导入文件优先（用于跨用户写入凭证的场景：例如助手程序代为获取 Cookie）
            var imported = TryTakeCookieImportFile();
            if (!string.IsNullOrWhiteSpace(imported))
            {
                Plugin.Log?.LogInfo("[登录] 发现外部导入的 Cookie 文件，开始导入…");
                var ok = await ImportCookieHeaderAsync(imported).ConfigureAwait(false);
                if (ok) return true;
            }

            var saved = SecureCookieStore.Load();
            if (string.IsNullOrWhiteSpace(saved))
            {
                SetState(LoginState.LoggedOut, "未登录（可扫码登录以访问私人歌单）");
                return false;
            }

            _service.ApplyCookies(saved);
            var uin = ExtractUinFromHeader(saved);
            User.Uin = uin;

            if (!QQHttp.HasLoginCookie())
            {
                SetState(LoginState.LoggedOut, "本地凭证已失效，请重新扫码登录");
                return false;
            }

            try
            {
                await _service.PingAsync(CancellationToken.None).ConfigureAwait(false);
                SetState(LoginState.LoggedIn, "已登录" + (string.IsNullOrEmpty(uin) ? "" : "（uin " + uin + "）"));
                return true;
            }
            catch (Exception e)
            {
                SetState(LoginState.Failed, "凭证校验失败：" + e.Message);
                return false;
            }
        }

        /// <summary>手动粘贴 Cookie 兜底（例如从浏览器复制）。</summary>
        public async Task<bool> ImportCookieHeaderAsync(string header)
        {
            header = NormalizeCookieHeader(header);
            if (string.IsNullOrWhiteSpace(header) || header.IndexOf('=') < 0)
            {
                SetState(LoginState.Failed, "Cookie 格式不正确，应形如 uin=o0123456; qm_keyst=xxx; qqmusic_key=xxx");
                return false;
            }

            var names = ExtractCookieNames(header);
            Plugin.Log?.LogInfo("[登录] 收到 Cookie，字段: " + (names.Count == 0 ? "(无)" : string.Join(", ", names))
                + "（只记录字段名，不记录值）");

            _service.ApplyCookies(header);
            var hasKey = names.Exists(n => n.Equals("qm_keyst", StringComparison.OrdinalIgnoreCase)
                                        || n.Equals("qqmusic_key", StringComparison.OrdinalIgnoreCase));
            var hasUin = names.Exists(n => n.Equals("uin", StringComparison.OrdinalIgnoreCase));

            if (!hasKey)
            {
                SetState(LoginState.Failed,
                    "这份 Cookie 里没有 qm_keyst / qqmusic_key —— 请确认是在「已登录 y.qq.com」的标签页里复制的。"
                    + "（只复制 uin 是不够的）");
                return false;
            }

            if (!QQHttp.HasLoginCookie())
            {
                SetState(LoginState.Failed, "Cookie 已解析但装载失败（内部错误），请把日志发给开发者。");
                return false;
            }

            SecureCookieStore.Save(header);

            var uin = ExtractUinFromHeader(header);
            User.Uin = uin;

            // 尽力验证一次（不作为硬性门槛，避免误报失败）
            var verified = await VerifyLoginAsync().ConfigureAwait(false);

            SetState(LoginState.LoggedIn,
                "登录凭证已保存" + (string.IsNullOrEmpty(uin) ? "" : "（uin " + uin + "）")
                + (verified ? "，已校验可获取播放地址" : "，但未能校验播放地址（可能探测歌曲无版权，播放时若失败请重新导入）")
                + (hasUin ? "" : "；注意 Cookie 里没有 uin 字段"));

            await Task.CompletedTask.ConfigureAwait(false);
            return verified;
        }

        private static List<string> ExtractCookieNames(string header)
        {
            var names = new List<string>();
            foreach (Match match in Regex.Matches(header ?? string.Empty, @"(?:^|;)\s*([A-Za-z0-9_\-\.]+)\s*="))
            {
                var name = match.Groups[1].Value;
                if (!names.Contains(name)) names.Add(name);
            }
            return names;
        }

        /// <summary>
        /// 尽力校验：先看能否读取个人歌单（只依赖 Cookie），再探测一个播放地址。
        /// 任何一项通过就算通过；两项都失败也只当作"未验证"，不阻断登录。
        /// </summary>
        private async Task<bool> VerifyLoginAsync()
        {
            if (!string.IsNullOrEmpty(User.Uin))
            {
                try
                {
                    var playlists = await _service.GetUserPlaylistsAsync(User.Uin, CancellationToken.None)
                        .ConfigureAwait(false);
                    Plugin.Log?.LogInfo("[登录] 校验通过：可读取个人歌单，共 " + playlists.Count + " 个。");
                    return true;
                }
                catch (Exception e)
                {
                    Plugin.Log?.LogDebug("[登录] 个人歌单校验未通过: " + e.Message);
                }
            }

            try
            {
                var probe = new SongInfo { Mid = "0039MnYb0qxYhV", Title = "验证用" };
                await _service.GetSongUrlAsync(probe, AudioQuality.MP3_128, CancellationToken.None)
                    .ConfigureAwait(false);
                Plugin.Log?.LogInfo("[登录] 凭证校验通过：已能获取播放地址。");
                return true;
            }
            catch (Exception e)
            {
                Plugin.Log?.LogInfo("[登录] 播放地址探测未通过（可能只是探测歌曲无版权）: " + e.Message);
                return false;
            }
        }

        public async Task LogoutAsync()
        {
            CancelQrLogin();
            SecureCookieStore.Clear();
            User = new QQUserInfo();
            SetState(LoginState.LoggedOut, "已退出登录");
            await Task.CompletedTask.ConfigureAwait(false);
        }

        // ------------------------------------------------------------------ 扫码登录

        public async Task StartQrLoginAsync()
        {
            CancelQrLogin();
            _qrCts = new CancellationTokenSource();
            var ct = _qrCts.Token;
            SetState(LoginState.RequestingQr, "正在获取二维码...");

            try
            {
                await RequestQrCodeAsync(ct).ConfigureAwait(false);
                if (ct.IsCancellationRequested) return;
                SetState(LoginState.WaitingScan, "请用手机 QQ 扫描二维码");
                await PollLoopAsync(ct).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                SetState(LoginState.LoggedOut, "已取消登录");
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("扫码登录失败: " + e);
                SetState(LoginState.Failed, "登录失败：" + e.Message);
            }
        }

        public void CancelQrLogin()
        {
            var old = _qrCts;
            _qrCts = null;
            if (old == null) return;

            try { old.Cancel(); } catch (Exception e) { Plugin.Log?.LogDebug("取消扫码登录异常: " + e.Message); }
            // 同上：轮询请求可能仍在飞，延迟释放更安全。
            Task.Delay(TimeSpan.FromSeconds(5))
                .ContinueWith(_ => { try { old.Dispose(); } catch { /* 忽略 */ } });
        }

        private async Task RequestQrCodeAsync(CancellationToken ct)
        {
            var url = string.Format(QrShowUrl, DateTime.Now.Ticks / 10000000.0);
            using (var response = await QQHttp.SendAsync(() => new HttpRequestMessageEx(url), ct).ConfigureAwait(false))
            {
                if (!response.IsSuccessStatusCode)
                    throw new QQMusicException("获取二维码失败：HTTP " + (int)response.StatusCode);
                var bytes = await response.Content.ReadAsByteArrayAsync().ConfigureAwait(false);
                if (bytes == null || bytes.Length < 100)
                    throw new QQMusicException("二维码下载失败（返回内容为空）。");

                try { File.WriteAllBytes(QrImagePath, bytes); }
                catch (Exception e) { Plugin.Log?.LogDebug("保存二维码图片失败: " + e.Message); }

                MainThreadDispatcher.Post(() =>
                {
                    var texture = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                    if (texture.LoadImage(bytes))
                    {
                        QrCodeReady?.Invoke(texture);
                    }
                    else
                    {
                        UnityEngine.Object.Destroy(texture);
                        Plugin.Log?.LogWarning("二维码图片解析失败，可手动打开：" + QrImagePath);
                    }
                });
            }
        }

        private async Task PollLoopAsync(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                await Task.Delay(2000, ct).ConfigureAwait(false);
                // action=0-0-<unix 秒>，腾讯前端就是这么传的
                var unixSeconds = (long)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
                var url = string.Format(QrLoginUrl, BuildOAuthJumpUrl(), PtqrToken(), unixSeconds);

                string body;
                var statusCode = 0;
                using (var response = await QQHttp.SendAsync(() => new HttpRequestMessageEx(url), ct).ConfigureAwait(false))
                {
                    statusCode = (int)response.StatusCode;
                    body = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }

                // 关键修复：之前没有检查状态码，403 的空响应被当成"无进展"，
                // 于是状态永远停在"请扫码"，用户完全不知道发生了什么。
                if (statusCode == 403)
                {
                    SetState(LoginState.Failed,
                        "腾讯扫码接口返回 403（风控拒绝，该老接口已不接受本客户端）。"
                        + "请改用「打开浏览器登录 + 从剪贴板导入 Cookie」，见登录面板里的说明。");
                    return;
                }

                if (statusCode < 200 || statusCode >= 300)
                {
                    SetState(LoginState.Failed, "扫码轮询失败：HTTP " + statusCode);
                    return;
                }

                var parsed = ParsePtuiCb(body);
                Plugin.Log?.LogInfo("[扫码] code=" + parsed.Code + " msg=" + parsed.Message);
                switch (parsed.Code)
                {
                    case "0":
                        SetState(LoginState.Scanned, "扫码成功，正在获取凭证...");
                        await CompleteLoginAsync(parsed, ct).ConfigureAwait(false);
                        return;
                    case "65":
                        SetState(LoginState.WaitingScan, "二维码已过期，正在重新获取...");
                        await RequestQrCodeAsync(ct).ConfigureAwait(false);
                        SetState(LoginState.WaitingScan, "请用手机 QQ 扫描二维码");
                        break;
                    case "66":
                        break;
                    case "67":
                        SetState(LoginState.Scanned, "已扫码，请在手机上确认登录");
                        break;
                    default:
                        // 解析不出 code（响应结构变了）也直接告知，避免静默空转
                        SetState(LoginState.Failed,
                            "扫码接口返回了无法识别的响应（可能已改版）。请改用浏览器 Cookie 导入。"
                            + " 原始内容前 80 字：" + (body ?? "").Substring(0, Math.Min(80, (body ?? "").Length)));
                        return;
                }
            }
        }

        private async Task CompleteLoginAsync(PtuiCbResult result, CancellationToken ct)
        {
            // 1. 跟随 ptuiCB 返回的跳转地址，让服务端种下 qm_keyst / p_skey 等 Cookie。
            if (!string.IsNullOrEmpty(result.Url))
            {
                try
                {
                    Plugin.Log?.LogInfo("[登录] 跟随登录票据: " + Shorten(result.Url));
                    using (var response = await QQHttp.SendAsync(() => new HttpRequestMessageEx(result.Url), ct).ConfigureAwait(false))
                    {
                        await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                        // 记录最终落地的地址，便于确认 OAuth 跳转链是否真的走通
                        Plugin.Log?.LogInfo("[登录] 跳转链最终落地: "
                            + (response.RequestMessage?.RequestUri?.ToString() ?? "(未知)")
                            + "；此时字段 " + ExtractCookieNames(_service.ExportCookieHeader()).Count + " 个");
                    }
                }
                catch (Exception e)
                {
                    Plugin.Log?.LogDebug("跟随登录跳转失败（可能不影响）: " + e.Message);
                }
            }

            // 2. 依次尝试多个"真实网页会经过"的入口，直到拿到音乐域 Cookie（qm_keyst / qqmusic_key）。
            await TryObtainMusicKeyAsync(ct).ConfigureAwait(false);

            var header = _service.ExportCookieHeader();
            Plugin.Log?.LogInfo("[登录] 登录跳转完成，当前 Cookie 字段: "
                + (string.IsNullOrEmpty(header) ? "(空)" : string.Join(", ", ExtractCookieNames(header))));

            if (string.IsNullOrEmpty(header) || !QQHttp.HasLoginCookie())
            {
                SetState(LoginState.Failed,
                    "拿到了登录票据，但没有换取到音乐域 Cookie（qm_keyst / qqmusic_key）。"
                    + "请改用「打开浏览器登录 + 从剪贴板导入 Cookie」。");
                return;
            }

            SecureCookieStore.Save(header);
            User.Uin = ExtractUinFromHeader(header);
            User.Nickname = result.Nickname ?? string.Empty;

            var verified = await VerifyLoginAsync().ConfigureAwait(false);
            SetState(verified ? LoginState.LoggedIn : LoginState.Failed,
                verified
                    ? (string.IsNullOrEmpty(User.Nickname) ? "登录成功" : "登录成功：" + User.Nickname)
                    : "登录票据已保存，但校验播放地址失败，请尝试浏览器 Cookie 导入。");
            await Task.CompletedTask.ConfigureAwait(false);
        }

        /// <summary>
        /// 换取音乐域 Cookie。腾讯不同时期用的入口不同，这里按"真实网页登录会经过的顺序"逐个尝试，
        /// 任何一个成功（出现 qm_keyst / qqmusic_key）就立刻停下。
        /// </summary>
        private async Task TryObtainMusicKeyAsync(CancellationToken ct)
        {
            var uin = ExtractUinFromHeader(_service.ExportCookieHeader());
            if (string.IsNullOrEmpty(uin)) uin = "0";

            var attempts = new[]
            {
                "https://y.qq.com/portal/profile.html",
                "https://y.qq.com/",
                "https://c.y.qq.com/rsc/fcgi-bin/fcg_user_created_diss?hostuin=" + uin
                    + "&sin=0&size=1&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq.json&needNewCode=0",
                "https://u.y.qq.com/cgi-bin/musicu.fcg?format=json&data=%7B%22comm%22%3A%7B%22ct%22%3A24%2C%22cv%22%3A0%7D%7D",
                "https://y.qq.com/n/ryqq/profile",
                "https://i.y.qq.com/n2/m/index.html"
            };

            foreach (var url in attempts)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    using (var response = await QQHttp.SendAsync(() => new HttpRequestMessageEx(url), ct).ConfigureAwait(false))
                    {
                        await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    }

                    var cookieNames = ExtractCookieNames(_service.ExportCookieHeader());
                    Plugin.Log?.LogInfo("[登录] 尝试 " + Shorten(url) + " → 现有字段 "
                        + cookieNames.Count + " 个" + (QQHttp.HasLoginCookie() ? "，已拿到音乐 Key ✅" : ""));

                    if (QQHttp.HasLoginCookie()) return;
                }
                catch (Exception e)
                {
                    Plugin.Log?.LogDebug("[登录] 换取音乐 Key 的尝试失败（" + Shorten(url) + "）: " + e.Message);
                }
            }
        }

        private static string Shorten(string text) =>
            string.IsNullOrEmpty(text) ? string.Empty : (text.Length > 70 ? text.Substring(0, 70) + "…" : text);

        // ------------------------------------------------------------------ 工具

        private string PtqrToken()
        {
            var qrsig = string.Empty;
            try
            {
                var cookie = QQHttp.Cookies.GetCookies(new Uri("https://ssl.ptlogin2.qq.com/"))["qrsig"];
                if (cookie != null) qrsig = cookie.Value;
            }
            catch { /* 忽略 */ }

            if (string.IsNullOrEmpty(qrsig)) throw new QQMusicException("未拿到 qrsig，二维码会话失效，请重试。");
            return Hash33(qrsig).ToString();
        }

        /// <summary>腾讯的 hash33：t += (t &lt;&lt; 5) + charCode，最后 &amp; 0x7FFFFFFF。</summary>
        private static int Hash33(string input)
        {
            int hash = 0;
            foreach (var c in input) hash += (hash << 5) + c;
            return hash & 0x7FFFFFFF;
        }

        private sealed class PtuiCbResult
        {
            public string Code = string.Empty;
            public string Url = string.Empty;
            public string Message = string.Empty;
            public string Nickname = string.Empty;
        }

        /// <summary>
        /// 腾讯的 ptuiCB 回包参数个数会变：登录成功时常常只有 5 个参数（没有昵称），
        /// 早期版本是 6 个。这里把昵称设为可选，避免把成功误判成"无法识别的响应"。
        /// </summary>
        private static readonly Regex PtuiCbRegex =
            new Regex(@"ptuiCB\('(?<code>\d+)','[^']*','(?<url>[^']*)','[^']*','(?<msg>[^']*)'(?:\s*,\s*'(?<nick>[^']*)')?\s*\)",
                RegexOptions.Compiled | RegexOptions.Singleline);

        private static readonly Regex PtuiCodeOnlyRegex = new Regex(@"ptuiCB\('(?<code>\d+)'", RegexOptions.Compiled);

        private static PtuiCbResult ParsePtuiCb(string body)
        {
            var result = new PtuiCbResult();
            if (string.IsNullOrEmpty(body)) return result;
            var match = PtuiCbRegex.Match(body);
            if (!match.Success)
            {
                // 兜底：至少把 code 抠出来，别让一次成功白白浪费掉
                var codeOnly = PtuiCodeOnlyRegex.Match(body);
                if (codeOnly.Success)
                {
                    result.Code = codeOnly.Groups["code"].Value;
                    var urlMatch = Regex.Match(body, "'(?<url>https?://[^']*)'");
                    if (urlMatch.Success) result.Url = urlMatch.Groups["url"].Value;
                    result.Message = "（宽松解析）";
                    return result;
                }

                result.Message = body.Length > 120 ? body.Substring(0, 120) : body;
                return result;
            }
            result.Code = match.Groups["code"].Value;
            result.Url = match.Groups["url"].Value;
            result.Message = match.Groups["msg"].Value;
            result.Nickname = match.Groups["nick"].Value;
            return result;
        }

        private static string ExtractUinFromHeader(string header)
        {
            if (string.IsNullOrEmpty(header)) return string.Empty;
            var m = Regex.Match(header, @"(?:^|;\s*)uin=o?(\d+)", RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value : string.Empty;
        }

        private static string NormalizeCookieHeader(string header)
        {
            if (string.IsNullOrWhiteSpace(header)) return string.Empty;
            header = header.Trim();

            // ① DevTools 里 "Copy as cURL" 的整段命令：从 -H 'cookie: ...' 里提取
            var curl = Regex.Match(header,
                @"(?:-H|--header)\s+(?<q>['""])cookie:\s*(?<v>.*?)\k<q>",
                RegexOptions.IgnoreCase | RegexOptions.Singleline);
            if (curl.Success) header = curl.Groups["v"].Value;

            // ② Headers 面板 JSON 形式： "cookie": "xxx"
            var json = Regex.Match(header, @"""cookie""\s*:\s*""(?<v>.*?)""",
                RegexOptions.IgnoreCase | RegexOptions.Singleline);
            if (json.Success) header = json.Groups["v"].Value;

            // ③ 直接就是 "Cookie: xxx"
            if (header.StartsWith("Cookie:", StringComparison.OrdinalIgnoreCase))
                header = header.Substring(7).Trim();

            // 转义换行 / 反斜杠续行都拍平
            header = header.Replace("\\r", " ").Replace("\\n", " ")
                           .Replace("\r", " ").Replace("\n", " ");
            return header;
        }

        /// <summary>QQHttp 需要一个 HttpRequestMessage 工厂，这里包一层方便加 Referer。</summary>
        private sealed class HttpRequestMessageEx : System.Net.Http.HttpRequestMessage
        {
            internal HttpRequestMessageEx(string url) : base(System.Net.Http.HttpMethod.Get, url)
            {
                Headers.TryAddWithoutValidation("Referer", "https://xui.ptlogin2.qq.com/");
            }
        }
    }
}

using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace ChillQQMusic
{
    internal enum MediaKeyAction
    {
        PlayPause,
        Next,
        Previous,
        Stop
    }

    /// <summary>
    /// 键盘媒体键（播放/暂停、上一首、下一首）的全局注册。
    ///
    /// 实现方式：专用后台线程 RegisterHotKey(NULL, ...) + GetMessage 循环，
    /// 收到 WM_HOTKEY 后 PostThreadMessage(WM_QUIT) 之外的按键统一 Post 回 Unity 主线程。
    /// Mono 下调用 user32.dll 是可行的（P/Invoke 直接可用），不需要额外的原生插件。
    ///
    /// 关于 SMTC（Windows 系统媒体控制中心 / 播放信息悬浮窗）：
    ///   WinRT 的 Windows.Media.Playback / SystemMediaTransportControls 需要 Windows.winmd 与
    ///   System.Runtime.WindowsRuntime 投影，游戏自带的 Unity Mono 运行时不提供这套投影，
    ///   在进程内不可行。如果需要系统级媒体会话，只能外挂一个独立的 .NET 辅助进程（见 README）。
    /// </summary>
    internal sealed class NativeMediaBridge : IDisposable
    {
        private const int WmHotkey = 0x0312;
        private const uint WmQuit = 0x0012;

        private const uint VkMediaNextTrack = 0xB0;
        private const uint VkMediaPrevTrack = 0xB1;
        private const uint VkMediaStop = 0xB2;
        private const uint VkMediaPlayPause = 0xB3;

        private const int IdPlayPause = 0x51A1;
        private const int IdNext = 0x51A2;
        private const int IdPrev = 0x51A3;
        private const int IdStop = 0x51A4;

        [StructLayout(LayoutKind.Sequential)]
        private struct Msg
        {
            public IntPtr Hwnd;
            public uint Message;
            public IntPtr WParam;
            public IntPtr LParam;
            public uint Time;
            public int PointX;
            public int PointY;
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetMessage(out Msg lpMsg, IntPtr hWnd, uint wMsgFilterMin, uint wMsgFilterMax);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool PostThreadMessage(uint idThread, uint msg, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll")]
        private static extern uint GetCurrentThreadId();

        private Thread _thread;
        private uint _threadId;
        private volatile bool _running;
        private int _registered;

        internal event Action<MediaKeyAction> Triggered;

        internal bool IsActive => _running && _registered > 0;

        internal bool Start()
        {
            if (_running) return IsActive;
            _running = true;

            try
            {
                _thread = new Thread(MessageLoop)
                {
                    IsBackground = true,
                    Name = "ChillQQMusic.MediaKeys"
                };
                _thread.Start();
                return true;
            }
            catch (Exception e)
            {
                _running = false;
                Plugin.Log?.LogWarning("注册媒体键失败: " + e.Message);
                return false;
            }
        }

        private void MessageLoop()
        {
            _threadId = GetCurrentThreadId();

            var ok = 0;
            ok += Register(IdPlayPause, VkMediaPlayPause) ? 1 : 0;
            ok += Register(IdNext, VkMediaNextTrack) ? 1 : 0;
            ok += Register(IdPrev, VkMediaPrevTrack) ? 1 : 0;
            ok += Register(IdStop, VkMediaStop) ? 1 : 0;
            _registered = ok;

            if (ok == 0)
            {
                Plugin.Log?.LogWarning("媒体键全部注册失败（可能被其他软件占用），已跳过。");
                _running = false;
                return;
            }

            Plugin.Log?.LogInfo("媒体键已注册 " + ok + " 个（播放/暂停、上一首、下一首）。");

            while (_running && GetMessage(out var msg, IntPtr.Zero, 0, 0) > 0)
            {
                if (msg.Message != WmHotkey) continue;
                var id = msg.WParam.ToInt32();
                var action = Resolve(id);
                if (action == null) continue;
                var value = action.Value;
                MainThreadDispatcher.Post(() => Triggered?.Invoke(value));
            }

            UnregisterHotKey(IntPtr.Zero, IdPlayPause);
            UnregisterHotKey(IntPtr.Zero, IdNext);
            UnregisterHotKey(IntPtr.Zero, IdPrev);
            UnregisterHotKey(IntPtr.Zero, IdStop);
            _registered = 0;
        }

        private static bool Register(int id, uint vk)
        {
            try
            {
                // 0 修饰键 + MOD_NOREPEAT(0x4000)，避免长按重复触发
                return RegisterHotKey(IntPtr.Zero, id, 0x4000, vk);
            }
            catch
            {
                return false;
            }
        }

        private static MediaKeyAction? Resolve(int id)
        {
            switch (id)
            {
                case IdPlayPause: return MediaKeyAction.PlayPause;
                case IdNext: return MediaKeyAction.Next;
                case IdPrev: return MediaKeyAction.Previous;
                case IdStop: return MediaKeyAction.Stop;
                default: return null;
            }
        }

        public void Dispose()
        {
            if (!_running) return;
            _running = false;
            try
            {
                if (_threadId != 0) PostThreadMessage(_threadId, WmQuit, IntPtr.Zero, IntPtr.Zero);
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("停止媒体键线程失败: " + e.Message);
            }
            _thread = null;
        }
    }
}

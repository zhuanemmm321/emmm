# ChillQQMusic 进度交接

> 最后更新：**2026-09-24 13:40**
> 状态：**功能全部打通，界面已对齐游戏风格，"关游戏卡死"已修复并有实测证据 —— 可以日常使用了。**

---

## 一、结论速览

| 模块 | 状态 | 依据 |
| --- | --- | --- |
| BepInEx 5.4.23.3 (x64) 安装 | ✅ | 日志 `BepInEx 5.4.23.3 - Chill With You` |
| 插件加载 / 启动阶段对象被销毁的自愈 | ✅ | `RuntimeWatchdog` 兜底循环 |
| QQ 音乐登录（浏览器凭证导入 + DPAPI 保存） | ✅ | `已登录（uin 1831290549）` |
| 歌单加载（chang，492 首） | ✅ | `歌单已加载：chang（492 首）` |
| 取播放地址（320K→128K→m4a 自动降级） | ✅ | 每首都有 `取得播放地址` |
| 下载 + **m4a→WAV 系统转码** + 播放 | ✅ | 09-23 22:12 用户确认听到声音 |
| 悬浮窗 UI（黑胶 / 进度 / 音量 / 歌词 / 按钮） | ✅ | 09-24 13:00 全屏截图核对 |
| 界面配色与图标对齐游戏原生 UI | ✅ | 09-24 13:13 部署，逐项修正 |
| 左侧呼出按钮（尺寸对齐原生、随游戏 UI 淡入淡出） | ✅ | 日志实测 `尺寸=(88,88)` → 屏幕 **117px**，原生按钮约 107~117px |
| **关闭游戏卡死** | ✅ **已修复** | `shutdown.log` 13:33:57 完整跑完 1/9→9/9，耗时 **332 ms** |
| 关闭时不再压低游戏原声 | ✅ | `播放时压低游戏BGM = false` |
| 启动时不显示 UI、不自动播放 | ✅ | `启动时显示UI = false` / `启动后自动播放 = false` |
| **歌单 / 用户UID 改为游戏内绑定**（cfg 默认值留空） | ✅ 已部署 09-24 17:12（见"批次四"） |
| 未绑定歌单的提示改为中性色 / 播放键自动先加载歌单 | ✅ 已部署 09-24 17:27（见"批次五"） |
| 关闭游戏 | ✅ 实测通过，17:20 那次 385 ms 干净退出（且当时播放请求是活的） |

**当前部署版本**

```
<游戏>\BepInEx\plugins\ChillQQMusic\
  ChillQQMusic.dll   202,240 B   2026-09-24 17:27:12   SHA256 7E040FCC8B20C121F01D2CBD6279D19A…
  MfDecode.dll       121,344 B   2026-09-23 22:06:48   （原生 m4a→WAV 解码器）
```

---

## 二、今天（09-24）做完的两批打磨

### 批次二：外观对齐游戏 UI（13:13 部署）

依据：13:00 的全屏截图 + 对游戏自带播放条的像素级取样。

1. **"进度条过粗"的真正根因（用户反馈了两轮）**：`UiKit.LofiSlider.Apply()` 里
   `Fill.rectTransform.anchorMax = new Vector2(_value, 1f)` —— y 写成 `1f`，填充块就从
   "半个滑条高度 + trackHeight"起算。实测**填充 16px、轨道只有 4px**，填充鼓出 4 倍。
   改成 `0.5f`。**之前几轮一直在改贴图，方向是错的。**
2. **滑条改成"空心凹槽 + 细填充"**：凹槽 10px 空心圆角描边（取自游戏媒体条样式），
   填充 4px，滑块 11/10px。
3. **随机播放图标**：旧版线宽 0.05、箭头 0.30、只画到 x=0.72 → 缩到 25px 糊成一个"✕"。
   改成 Material shuffle 比例（线宽 0.085、箭头 0.24、铺到 0.09~0.91）。
4. **账号图标**：旧版"小圆环 + 大圆环"→ 25px 下就是个"8"。改成实心圆头 + 弧线肩膀。
5. **刷新图标**：旧版"整圆 + 乱放的三角"→ 像"♀"。改成留缺口的圆弧 + 切线箭头。
6. **单曲循环图标**：环 0.07 太粗把中间的"1"挤糊 → 环收细到 0.065，"1"放大。
7. **音量图标**：图形只占 x 0.07~0.80、重心偏左看着"歪" → 重排到 0.155~0.835 居中，声波加粗。
8. **播放键改成游戏同款**：游戏自己的播放键是"**透明底 + 青→品红渐变描边 + 白色三角**"，
   我们原来是"纯白实心圆盘 + 深色图形"——这是与游戏风格差得最远的一处。
9. **次级图标配色**：对游戏原生按钮取样得到 底 `#292842`、描边/图形 `#9292B5`（淡紫白，不是纯白）。
   新增 `IconLav #C6C6E2` / `RingLav #9292B5`，顶栏与播放控制排统一换色。
10. **黑胶封面被裁成多边形**：UGUI 的 `Mask` 是**按网格**裁剪，而圆形贴图运行时生成的
    Tight 网格只有十几个顶点 → 封面变成十来条边的多边形。改为下载后**在贴图里做圆形 alpha 裁切**
    （`CreateRoundCoverSprite`；同时把 `GetTexture(url, true)` 的 `nonReadable` 改成 `false`，
    否则根本读不到像素）。封面 92px，另加一颗 11px 中心轴孔。
11. **左侧呼出按钮偏小**：实测只有 66 屏幕像素，原生按钮 107 像素（差 40%）。
    改为挂进 `LeftIcons` 后**量一个原生兄弟按钮的尺寸**照抄，并 `SetSiblingIndex(0)` 排到最左。

### 批次三：修"关闭游戏卡死"（13:28 部署）

**症状**：关闭游戏时窗口变"无响应"，只能强杀。

**排查过程（这段经验很值钱）**

1. 读 `LogOutput.log`：日志**停在最后一个正常操作**（F8 隐藏面板）上，连
   `游戏退出，开始清理插件资源…` 都没有 → 一度以为是"退出清理里卡住"，但清理代码根本没跑到。
2. 想通原因：**BepInEx 自己在退出时会先一步关掉 `LogOutput.log` 的监听器**
   （`Chainloader` 的 OnApplicationQuit 早于我们），之后写进去的内容被静默丢弃。
   → **旧日志对"退出阶段"是瞎的**，不能据此判断任何事。
3. 于是新增独立追踪文件（绕开 BepInEx 日志，直接 `File.AppendAllText`）：
   `<游戏>\BepInEx\config\ChillQQMusic\shutdown.log`，由 `Plugin.Trace()` 写入。
4. 定位到最可疑的元凶：**播放期间必须全程存活的
   `UnityWebRequestMultimedia.GetAudioClip` 请求**（`AudioPlayer._request`，本地 file:// 加载 WAV，
   为了保住 AudioClip 不能提前 Dispose）。Unity 关游戏时会拆音频/网络子系统，
   此时还有这种原生请求没释放 → 主线程卡住。这条线索与时间线完全吻合：**能播放之后才开始关不掉。**

**改动**

12. `Plugin.BeginShutdown(reason)`：**幂等**的统一退出清理，9 步逐条写日志，
    每步独立 try/catch，任何一步失败都不影响后续。
13. 退出钩子挂了**三个**时机（越早越好）：`Application.wantsToQuit`（最早）→
    `Application.quitting` → `OnApplicationQuit`；另外在运行期宿主 `ChillQQMusicRuntime` 上
    加了 `QuitHook`——因为插件对象在启动阶段就被游戏销毁了，它自己的 `OnApplicationQuit` 收不到。
14. 清理内容：卸载看门狗 → 释放 UI（含在途封面请求 Abort+Dispose）→
    **停播并释放 UnityWebRequest / AudioClip** → 取消歌单/预取任务 → 释放登录与服务 →
    注销媒体键线程 → 卸载 Harmony → 保存配置 → 清理贴图缓存。
15. `EnsureRuntime` 增加 `_shutdownDone` 闸门：退出后**绝不重建 UI**
    （否则看门狗兜底循环可能在退出阶段发现 UI 不健康，然后每帧重建整个界面）。
16. 新增配置 `02-快捷键/安全退出`（默认空=禁用）。填 `F11` 之类可"先卸载插件资源再退出游戏"，
    既是兜底手段，也是"卡死是不是插件引起的"对照实验。

**实测结果（13:33:57）**

```
13:33:57.501  开始退出清理（Application.wantsToQuit）…
              1/9 卸载看门狗 → 2/9 释放悬浮窗 → 3/9 停止音频（在途请求=有）
              → 4/9 取消歌单 → 5/9 释放登录与服务 → 6/9 注销媒体键
              → 7/9 卸载 Harmony → 8/9 保存配置 → 9/9 清理贴图缓存
13:33:57.513  退出清理完成。
13:33:57.514  运行期宿主收到 OnApplicationQuit。
13:33:57.833  运行期宿主被销毁 / AudioPlayer 被销毁。
```

全程 **332 ms**，干净退出 ✅（本次会话只出现 1 次预期的 320K 404 回退，无其它告警）

---

## 三、怎么用（操作手册）

### 热键（可在 cfg 的 `02-快捷键` 改）

| 键 | 作用 |
| --- | --- |
| `F8` | 显示 / 隐藏播放器面板 |
| `F9` | 播放 / 暂停 |
| `F10` | 下一首 |
| `F7` | 上一首 |
| （空） | `安全退出`：填了键位后按它 = 卸载插件资源 + 退出游戏 |

游戏**最左侧**那个音符按钮 = 鼠标党的 F8，外观与原生按钮同尺寸同风格，
并且跟随游戏 UI 一起淡入淡出（它被挂进了游戏自己的 `LeftIcons` 节点）。

### 面板元素

从上到下：标题栏（拖拽移动）→ 右侧 5 个按钮（歌词 / 歌单 / 刷新 / 账号 / 关闭）
→ 黑胶封面（播放时自转）→ 歌名 / 歌手 / 专辑 → 进度条（可拖动）→
播放模式 / 上一首 / 播放暂停 / 下一首 / 音量 → 歌词区 → 歌单与状态信息。

### 登录

扫码接口被腾讯风控拦死，实际走**浏览器凭证导入**：面板里"账号/登录"→"打开浏览器登录"
→ 在浏览器登录 y.qq.com → 复制 Cookie → 粘回输入框导入。
凭证由游戏进程自己用 DPAPI 加密保存到 `config\ChillQQMusic\account.dat`（**别删**），
重启后自动恢复（日志 `已用本地凭证恢复登录`）。Cookie 过期后重新导入一次即可。

---

## 四、当前配置项快照

文件：`<游戏>\BepInEx\config\com.codex.chillqqmusic.cfg`

| 分组 | 键 | 当前值 | 说明 |
| --- | --- | --- | --- |
| 01-通用 | 歌单ID | **`(空)`** | 09-24 17:12 起改为**游戏内绑定**；绑定后插件会写回这里 |
| | 用户UID | **`(空)`** | 同上；仅当歌单ID/链接都为空时用于列该用户歌单（可在游戏内填） |
| | API模式 | `DirectQqWeb` | 另一个选项是 `CustomRest` |
| | 音质 | `MP3_320` | 失败自动降级 320K→128K→m4a |
| 02-快捷键 | 显示隐藏UI / 播放暂停 / 下一首 / 上一首 | `F8` / `F9` / `F10` / `F7` | |
| | 安全退出 | `(空)` | 填 `F11` 可启用"清理后退出" |
| | 系统媒体键 | `true` | 实测被其它程序占用时注册失败，不影响 F 键 |
| 03-播放 | 音量 | `0.61` | |
| | 播放模式 | `Shuffle` | 当前用随机播放 |
| | 启动后自动播放 | `false` | |
| | 忽略游戏暂停 | `true` | 切后台继续放 |
| | 启用磁盘缓存 / 缓存上限MB | `true` / `1024` | |
| | 边下边播 | `true` | **已停用**：本作流式播放会导致时长恒 0，插件固定"完整下载后播放" |
| | 预取下一首提前秒数 | `15` | |
| 04-界面 | X坐标 / Y坐标 | `195` / `269` | 面板位置（参考分辨率 1920×1080） |
| | 缩放 / 显示时透明度 | `1` / `0.94` | |
| | 鼠标离开后淡出 | `false` | 用户不喜欢淡出效果，已关 |
| | 启动时显示UI | `false` | 进游戏不弹面板 |
| | 左侧呼出按钮 | `true` | |
| 05-网络 | 超时秒数 / 重试次数 | `15` / `2` | |
| 06-Harmony补丁 | 启用Harmony补丁 | `true` | 但下方两个都关，实测命中 **0 处**，等于没打补丁 |
| | 注入游戏UI按钮 / 播放时压低游戏BGM | `false` / `false` | 保持关闭，避免动原版逻辑 |

---

## 五、源码结构

工程：`D:\ppvvzz\play？\test\ChillQQMusic\`（19 个 .cs，约 7,500 行）

| 文件 | 行数 | 职责 |
| --- | --- | --- |
| `Plugin.cs` | 440 | BepInEx 入口、生命周期、热键、**退出清理 `BeginShutdown` + 追踪 `Trace`** |
| `ConfigManager.cs` | 197 | 全部 cfg 项与默认值 |
| `QQMusicService.cs` | 968 | 直连 QQ 音乐 Web 接口：歌单 / 取址 / 歌词 / 用户歌单；`IQQMusicService` 接口可替换 |
| `QQHttp.cs` | 241 | 统一 HTTP 层（超时、重试、Cookie、Expect100Continue 关闭） |
| `QQMusicModels.cs` | 125 | 数据模型 |
| `LoginManager.cs` | 600 | 登录态、扫码、浏览器凭证导入、凭证落盘 |
| `SecureCookieStore.cs` | 173 | DPAPI 加密保存凭证 |
| `PlaylistManager.cs` | 530 | 播放队列、顺序/单曲/随机、切歌、预取、进度与状态事件 |
| `AudioPlayer.cs` | 683 | 下载 → 容器判定 → 转码 → 解码 → AudioSource 播放、淡入淡出、Seek |
| `NativeMfDecode.cs` | 75 | 调用 `MfDecode.dll` 做 m4a→WAV |
| `AudioCache.cs` | 138 | 磁盘缓存与 LRU 清理 |
| `LyricsParser.cs` | 97 | LRC 解析 |
| `UIManager.cs` | 1353 | 全部 UGUI：面板、黑胶、滑条、歌词、歌单/登录覆盖层、左侧呼出按钮、退出清理 |
| `UiKit.cs` | 355 | 控件工厂 + **`LofiSlider`**（今天修的就是这里的锚点 bug） |
| `LoFiTheme.cs` | 618 | 全程序化贴图：圆角矩形、渐变环、黑胶、噪点、**矢量图标** |
| `RuntimeWatchdog.cs` | 150 | `onBeforeRender` + `sceneLoaded` 静态兜底 |
| `MainThreadDispatcher.cs` | 80 | 后台线程 → 主线程任务泵 |
| `NativeMediaBridge.cs` | 178 | 键盘媒体键注册（Win32 hotkey 线程） |
| `Patches.cs` | 304 | 可选的 Harmony 补丁（当前全部未启用） |

原生解码器：`tools\MfDecode\MfDecode.cpp` → `MfDecode.dll`（Windows Media Foundation）

---

## 六、构建 / 部署 / 调试

```powershell
cd "D:\ppvvzz\play？\test"
powershell -ExecutionPolicy Bypass -File .\build.ps1            # 编译 + 部署（游戏必须关闭）
powershell -ExecutionPolicy Bypass -File .\build.ps1 -CheckOnly  # 只校验语法（不用关游戏）
```

重编原生解码器（只有改了 `MfDecode.cpp` 才需要）：

```powershell
$vcvars = 'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat'
cmd /c "call `"$vcvars`" >nul 2>&1 && cd /d tools\MfDecode && cl /nologo /utf-8 /LD /O2 /EHsc /D_USRDLL MfDecode.cpp /link /OUT:MfDecode.dll mfplat.lib mfreadwrite.lib mfuuid.lib ole32.lib"
```

调试用的小工具（都在 `tools\`，不碰游戏目录）：

| 工具 | 用途 |
| --- | --- |
| `tools\crop.ps1` | 从截图裁一块并放大（看 UI 细节） |
| `tools\montage.ps1` | 把一堆图标 PNG 拼成对照图 |
| `tools\IconTest\IconTest.exe` | 单独渲染全部图标（64px + 按钮实际尺寸 25px），改图标后先用它验收 |

重编 IconTest（需要 Roslyn csc，**不能用** .NET Framework 自带的 csc，它不支持元组语法）：

```powershell
& 'C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\Roslyn\csc.exe' `
  /nologo /target:exe /out:IconTest.exe /r:System.Drawing.dll Program.cs
```

> **调试小技巧（今天踩到的）**：想在编译好的 DLL 里确认某段代码/文案在不在，
> 直接按 UTF-16 搜字符串**会漏掉大约一半** —— .NET 的 #US 堆条目长度前缀是变长的，
> 后面的字符串会落在**奇数字节偏移**上。要**偶、奇两种对齐各搜一遍**：
> `Encoding.Unicode.GetString(bytes)` 和 `Encoding.Unicode.GetString(bytes, 1, len-1)`。

**关键文件位置**

| 项 | 路径 |
| --- | --- |
| 游戏 | `D:\SteamLibrary\steamapps\common\Chill with You Lo-Fi Story` |
| 日志 | `<游戏>\BepInEx\LogOutput.log` |
| **退出追踪** | `<游戏>\BepInEx\config\ChillQQMusic\shutdown.log` |
| 凭证 | `<游戏>\BepInEx\config\ChillQQMusic\account.dat`（**别删**） |
| 缓存 | `<游戏>\BepInEx\cache\ChillQQMusic\`（原始 m4a + 转码 wav，30~40 MB/首） |

---

## 七、备份与回退

每次大改动前都新建 `backups\ChillQQMusic_<时间戳>_<说明>\`。

| 备份 | 内容 |
| --- | --- |
| `ChillQQMusic_20260923_223252` | 打磨一之前（可播放的初版） |
| `ChillQQMusic_20260923_235935_打磨一` | 打磨一之后 |
| `ChillQQMusic_20260924_131130_打磨二前` | 打磨二之前（含当时的 cfg） |
| `ChillQQMusic_20260924_1329_关服修复` | 含 `ChillQQMusic_修复前.dll` / `ChillQQMusic_修复后.dll` / 源码 zip |
| **`ChillQQMusic_20260924_1340_功能完成`** | **今日完成快照**：DLL（`C31AAC8A1DF2…`）+ cfg + `shutdown.log` + `source_full.zip`（全部源码 / 构建脚本 / 工具 / 本文档） |
| `ChillQQMusic_20260924_171256_游戏内绑定前` | 游戏内绑定之前：`ChillQQMusic.dll`(200,704) + 改动前的 cfg（`歌单ID=9697794311` / `用户UID=GQ7L16LGB`） |
| `ChillQQMusic_20260924_172711_播放兜底前` | 批次五之前：`ChillQQMusic.dll`(`C81FCE25710EAFE3…`) + 当时的 cfg |
| `ChillQQMusic_20260924_171525_首次登录前` | 首次登录模拟之前：`account.dat` + `login_qr.png` + cfg + DLL |

回退（游戏必须先关闭）：

```powershell
$bk  = 'D:\ppvvzz\play？\test\backups\ChillQQMusic_20260924_1329_关服修复'
$dst = 'D:\SteamLibrary\steamapps\common\Chill with You Lo-Fi Story\BepInEx\plugins\ChillQQMusic'
Copy-Item "$bk\ChillQQMusic_修复前.dll" "$dst\ChillQQMusic.dll" -Force
```

---

## 八、历史问题档案（都已解决，备查）

**接入 / 登录**

1. 腾讯 `ptuiCB` 回包只有 5 个参数（无昵称），旧正则要求 6 个 → 成功被误判为失败
2. 插件内扫码换不到音乐域 Cookie（服务端不下发 `qm_keyst`）→ 改用浏览器凭证导入
3. 跨用户 DPAPI 问题（沙箱账户写的凭证游戏读不了）→ `cookie.txt` / `cookie.b64` 导入通道，
   由游戏自己加密保存
4. **`CookieContainer.SetCookies(uri, "Cookie: ...")` 只存第一个字段** → 改为逐个 `Add`，域 `.qq.com`
5. **POST 静默挂起**：.NET 默认发 `Expect: 100-continue` → `Expect100Continue = false` + 硬超时

**播放链路**

6. **Unity 禁止明文 HTTP**：播放地址是 `http://aqqmusic.tc.qq.com/...` → 自动升级 https
7. **`streamAudio` 流式播放不可用**（clip.length 恒为 0、不发声）→ 改为完整下载后播放
8. **腾讯"挂羊头卖狗肉"**：请求 `.mp3` 实际下发 **m4a**（`ftypmp42`）→ 读文件头判断真实容器
9. **Unity（Windows）不支持 AAC 解码** → 自带 `MfDecode.dll`（Media Foundation）转 16bit PCM WAV
10. 缓存键相同导致坏的 m4a 反复命中 → 缓存命中时用文件头校验容器，不符则丢弃重下

**插件生命周期 / UI**

11. 游戏启动时用 `LoadSceneMode.Single` 加载 Boot 场景，**销毁了 BepInEx 的插件对象** →
    `RuntimeWatchdog`（`onBeforeRender` + `sceneLoaded`）静态驱动 + 运行期组件延后创建 +
    `HideFlags.DontSave`
12. `OnDestroy` 误拆卸（把 Harmony 补丁和看门狗一起撤掉）→ 只在真正退出时清理
13. UI 启动即淡到 12% 不可见 / 首次 F8 变成"隐藏" → 启动显示策略 + "近乎不可见时按热键必为显示"
14. 游戏内按钮与退出按钮外观雷同导致误点 → 暖黄底色区分（后来改用独立的左侧按钮，此项已废弃）
15. **图标 SDF bug**：`SdTriangle` 对逆时针三角形用 `-max` 错误（应 `-min`）→ 整个图标被涂满
16. **图标偏小根因**：图形只占贴图宽度一半 → 改为铺满 0.06~0.94
17. **UGUI `Mask` 按网格裁剪**：圆形贴图用 `FullRect` 会裁成方形；改用 `Tight` 又会裁成
    十几条边的多边形 → 最终改为**在贴图阶段做圆形 alpha 裁切**，彻底不用 Mask
18. **滑条填充块比轨道粗 4 倍** → `LofiSlider.Apply()` 里 `anchorMax.y` 写成了 `1f`，应为 `0.5f`
19. **BepInEx 退出时先关自己的日志监听器** → 退出阶段的日志全丢，必须用独立的
    `shutdown.log` 才能看到退出流程
20. **播放期间存活的 `UnityWebRequestMultimedia` 请求**会让 Unity 关游戏时卡住主线程 →
    在 `Application.wantsToQuit` 里提前释放

---

## 九、已知限制

- 音乐域 Cookie 依赖"浏览器登录一次 + 导入"，过期后需重新导入
- 320K/MP3 地址在该账号下恒 404，实际使用 CDN 下发的 m4a（约 128K 级别）；
  每首会多花约 200 ms 在注定失败的 320K 请求上
- 转码缓存 WAV 较大（30~40 MB/首，上限 1 GB，LRU 清理）
- 键盘媒体键常被其它程序占用而注册失败；F7/F8/F9/F10 始终可用
- 系统媒体控制中心（SMTC）在 Unity Mono 进程内不可行，需要外挂独立进程
- `06-Harmony补丁` 里两个开关都是关的，等于没打补丁；如果哪天想用，需要重新验证命中情况

## 十、想做但还没做的（可选）

### 批次四（**已于 09-24 17:12 部署**）：歌单 / 用户UID 改为游戏内绑定

目的：让这份 mod 能给别人用 —— 复制过去之后不用改文本文件，直接在游戏里绑定自己的歌单。

1. `ConfigManager`：`歌单ID` 与 `用户UID` 的**默认值改为空**（描述改成"留空即走游戏内绑定"）。
   注意改默认值只影响"首次生成 cfg"，**已有 cfg 的旧值不会被覆盖** ——
   部署时要顺手把现有 cfg 这两个值清空（必须游戏关闭状态）。
2. `UIManager.BuildPlaylistPanel`：在「我的歌单」面板顶部加两行输入区 ——
   `歌单 ID / 分享链接 / 短码` + `绑定` 按钮；`用户 UID` + `列歌单` 按钮；
   歌单列表下移到 y=150、高度 310（可容纳 7 项）。
3. `BindPlaylistFromInput()`：解析输入（复用 `PlaylistManager.ExtractPlaylistId`，
   支持纯数字 ID / 分享短码 / 完整分享链接）→ 写 `歌单ID`、清空 `歌单链接`、保存 →
   关面板、刷新标题、`RefreshAsync()` 立即加载。
4. `ApplyUserUidFromInput()`：保存 `用户UID` 并重新列歌单（未登录时的备用通道）。
5. 每次打开「歌单」面板会把输入框同步为当前绑定值。
6. 文案统一引导到游戏内绑定：主面板状态行（未绑定时提示"点右上角「歌单」按钮…"）、
   歌单名占位、空列表提示、`PlaylistManager` 的"未绑定"错误提示。

**部署完成**：① 新 DLL 已部署（202,240 B / 17:12:56）；② cfg 里
`歌单ID` / `用户UID` 已清空（备份见 `backups\ChillQQMusic_20260924_171256_游戏内绑定前\`）。
首次使用需要在游戏内绑定一次：打开面板 → `≡` → 填 `9697794311` → `绑定`。

---

### 其它可选

1. 跳过注定 404 的 320K 请求，省约 200 ms/首
2. 歌词滚动/高亮当前行（当前是"当前行 + 下一行"两行显示）
3. 系统托盘 / SMTC 外挂进程（要做的话是独立项目）
4. 首次运行引导（未绑定时自动弹一次「歌单」面板）

---

### 批次五（**已于 09-24 17:27 部署**）：两处边界路径打磨

背景：09-24 17:16~17:20 那次"首次登录"实测暴露出来的两个小问题。

1. **"还没绑定歌单"不再用红字报错**。`PlaylistManager.RefreshAsync` 里那处
   `Notify(LastError, true)` 改成 `false` —— 未绑定是正常初始状态（引导），
   不是故障；之前登录成功那一刻会立刻弹一条红字，观感像出错。
2. **播放/切歌时歌单还没加载 → 先自动加载再播**。新增
   `PlaylistManager.EnsurePlaylistLoaded(autoPlay)`，`TogglePlayPause / NextAsync / PrevAsync`
   在 `Playlist == null` 时调用它。
   触发场景：启动时登录已失效（Cookie 过期）→ 恢复登录失败 →
   "登录后自动刷新歌单"那步没跑 → 以前按播放键**静默无反应**；现在会先加载歌单再自动开播。
   日志标记：`歌单尚未加载，先自动加载一次（加载完自动播放=True）。`

> 这两处都是边界路径，**正常流程（登录能恢复 + 歌单已绑定）看不出差别** ——
> 正常启动时登录恢复会触发 `LoginStateChanged` → `RefreshAsync(autoPlayIfIdle:false)`，
> 歌单在启动阶段就已经加载好了。

---

## 十一、协作约定（重要，2026-09-24 用户明确要求）

1. **绝不自行关闭游戏进程**。任何需要写游戏目录的改动（部署 DLL / 改配置）之前，
   必须先提示用户"请关闭游戏"，然后**等用户确认已关闭**才能继续。
2. 不依赖"优雅关闭/强制关闭"等任何自动手段 —— 除非用户当次明确说"帮我关"。
3. 与游戏文件无关的工作可以提前做：改源码、跑 `build.ps1 -CheckOnly`（只编译不部署）、
   写文档、用 `tools\IconTest` 验收图标 —— 这些都不碰游戏目录。
4. 部署流程：`改源码 → -CheckOnly 校验 → 提示用户关游戏 → 用户确认 → build.ps1 部署`。
5. 部署后让用户自己启动游戏（不要代启动），验证结果以 `LogOutput.log` /
   `shutdown.log` / 用户截图为准。

---

## 十二、分发打包（2026-09-24 17:34）

**成品包**：`D:\ppvvzz\play？\备份\ChillQQMusic_完整包_20260924.zip`（约 2.00 MB）

> 压缩包**自身**的 SHA256 请以同目录下的 `ChillQQMusic_完整包_20260924.zip.sha256` 为准 ——
> 哈希没法写进它自己的内容里（写了就会变），所以放在旁边的校验文件里。
> 重新打包后记得一起更新那个文件。

打包暂存目录（工作区内，可随时重新压）：
`D:\ppvvzz\play？\test\_package\ChillQQMusic_完整包_20260924\`

**包内结构**

```
ChillQQMusic_完整包_20260924/
├─ 0-先读我.txt                 安装步骤 + 首次使用 + 限制 + 校验值
├─ 1-插件-必须/plugins/ChillQQMusic/
│     ChillQQMusic.dll          202,240 B  SHA256 7E040FCC8B20C121…
│     MfDecode.dll              121,344 B  SHA256 BB61381EB229ABC1…
├─ 2-BepInEx框架-可选/
│     BepInEx_win_x64_5.4.23.3.zip  官方原包 638,885 B  SHA256 41A089E5B1B1F071…
│     install-bepinex.ps1
├─ 3-参考资料/  com.codex.chillqqmusic.cfg（对照用）、PROGRESS.md（本文档）
└─ 4-源码/      19 个 .cs + csproj + build.ps1 + tools\（含 MfDecode.cpp、IconTest 等）
```

**为"换机器可用"做过的核对（都已验证）**

1. 插件源码**无绝对路径**、无硬编码账号 —— 落盘位置全部走 `Paths.ConfigPath` / `Paths.CachePath`。
2. 插件引用的程序集全部能在"同款游戏 + BepInEx 5"环境里找到：
   BepInEx 5.4.23.3、0Harmony 2.9.0.0、Newtonsoft.Json 13.0.0.0、
   mscorlib/System/System.Core/System.Net.Http/System.Security、以及 12 个 UnityEngine.* 模块。
3. `MfDecode.dll` 是 x64，只依赖 MFPlat / mfreadwrite / KERNEL32 / OLE32（系统自带），
   **不需要 VC++ 运行库**。
4. 压缩包做了**解包回环校验：123/123 个文件逐字节 SHA256 一致**，中文文件名完好。
5. BepInEx 官方包 SHA256 与官方值一致（`41A089E5B1B1F0713B331346BAF6677B1184C69EABEBF51101097954E854C749`）。

**包内不含、也不该含的东西**

- ❌ `account.dat`（登录凭证）：DPAPI + 机器名/用户名 双重绑定，拷过去必定解不开；
  且那等于把账号凭证送人。对方必须自己登录一次。
- ❌ `BepInEx\cache\ChillQQMusic\`（转码缓存）：几十 MB~GB，且是版权音频。
- ❌ 用户的 `BepInEx\config\ChillQQMusic\`：会在首次运行时自动重建（默认值已是空歌单/空UID）。

> 打包时核对到的两件事，记录备查：
> ① `install-bepinex.ps1` 里的 SHA256 常量**本来是对的**（64 位十六进制）。
>    我一度以为它少了一位，那是我自己比对时抄错/控制台显示掉字符导致的**误报**，
>    已用"从文件里正则提取常量再和 `Get-FileHash` 对比"的方式确认无误。
> ② `tools\qqapi\src\...\util\privateKey.js` 里那个 `ipPrivateKey` 是开源项目
>    QQMusicApi 自带的**占位符**（值为 `xixixixixixixixix`），不是真密钥，可以随包分发。

---

## 十三、卸载重装测试工具（2026-09-24 17:45）

**脚本**：`D:\ppvvzz\play？\test\test-reinstall.ps1`（18.5 KB，**纯 ASCII**，PS 5.1 编码安全）

用途：把 mod 从本机卸干净、再照"新用户"流程从压缩包装一遍，用于验证安装全流程。

```powershell
cd "D:\ppvvzz\play？\test"
powershell -ExecutionPolicy Bypass -File .\test-reinstall.ps1 -Check        # 只看会做什么，不改任何东西
powershell -ExecutionPolicy Bypass -File .\test-reinstall.ps1 -BackupOnly   # 只备份（对游戏目录只读）
powershell -ExecutionPolicy Bypass -File .\test-reinstall.ps1 -Yes          # 备份 + 卸载 + 从包装回
powershell -ExecutionPolicy Bypass -File .\test-reinstall.ps1 -Yes -KeepCache # 同上但保留 647 MB 转码缓存
powershell -ExecutionPolicy Bypass -File .\test-reinstall.ps1 -Restore <备份目录>  # 回退到测试前
```

**五个阶段**：preflight（**游戏在运行就直接拒绝，绝不强杀**）→ backup（凭证/配置/日志/当前 DLL
→ `backups\<时间戳>_before-uninstall\`，含 manifest 指纹）→ uninstall（删除 `BepInEx\` 与三个
根文件）→ install（解压压缩包、校验官方 BepInEx 的 SHA256、用**包内自带的**
`install-bepinex.ps1` 装框架、再放插件）→ verify（重新哈希落地文件 + 打印人工测试清单）。

删除目标全部经 `GetFullPath` 解析并**断言落在游戏目录内**才动手；转码缓存是可再生数据，
默认删除、`-KeepCache` 时改为移出再移回。

### 已实测（本机）

| 项目 | 结果 |
| --- | --- |
| 语法 + 纯 ASCII | ✅ 解析通过、非 ASCII 字节 0 |
| `-Check` 干跑 | ✅ 能自动定位到 `备份\ChillQQMusic_完整包_20260924.zip` 并核对旁挂 .sha256 |
| `-BackupOnly` | ✅ 产出 `backups\20260924_174404_before-uninstall\`（凭证、cfg、日志、DLL、框架 core） |
| `-Restore` | ✅ **逐字节比对：config / cfg / plugins 与回退前完全一致**，凭证与歌单绑定无损 |
| 安装阶段彩排 | ✅ 在临时"假游戏目录"里跑完整安装：框架落地、插件落地、两个 DLL 哈希、四个框架文件、无残留 cfg，全部通过；目录结构与真安装一致（core 18 个文件） |

### 彩排抓出的两个真 bug（已修）

1. `Copy-Item -LiteralPath (Join-Path $x '*')` —— **`-LiteralPath` 不展开通配符**，
   两处"复制目录内容"会直接报错。已改成 `-Path`。
2. 压缩包解出来外面**还套着一层同名文件夹**，脚本原来直接找 `1-*` 找不到 →
   新增 `Get-PackageRoot()`：只有单层目录且无文件时自动下钻。

> 结论：**安全网本身已经验证过**（备份 + 回退 + 安装彩排都实跑成功），
> 可以放心用它做"卸掉重装"的全流程测试。真机全流程（卸载→装→进游戏→登录→绑定→播放→
> 正常退出）仍需用户本人跑一遍，之后由我读 `LogOutput.log` / `shutdown.log` 判读。

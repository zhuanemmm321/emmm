(function () {
  var uin = "1831290549";
  var mid = "000Ms8EM0k35Ms";
  var payload = {
    comm: { ct: 24, cv: 0, format: "json", uin: uin, platform: "yqq.json" },
    req_0: {
      module: "vkey.GetVkeyServer",
      method: "CgiGetVkey",
      param: {
        guid: "1234567890",
        songmid: [mid],
        filename: ["M500" + mid + ".mp3"],
        songtype: [0],
        uin: uin,
        loginflag: 1,
        platform: "20"
      }
    }
  };
  window.__vkeyResult = "pending";
  try {
    var body = JSON.stringify(payload);
    var sign = window.__qqsign(body);
    window.__vkeySign = sign;
    fetch("https://u.y.qq.com/cgi-bin/musicu.fcg?format=json&sign=" + encodeURIComponent(sign), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: body,
      credentials: "include"
    }).then(function (r) { return r.text(); })
      .then(function (t) { window.__vkeyResult = t.slice(0, 400); })
      .catch(function (e) { window.__vkeyResult = "FETCH_ERR " + e; });
    return "started sign=" + sign;
  } catch (e) {
    window.__vkeyResult = "ERR " + e;
    return "ERR " + e;
  }
})()

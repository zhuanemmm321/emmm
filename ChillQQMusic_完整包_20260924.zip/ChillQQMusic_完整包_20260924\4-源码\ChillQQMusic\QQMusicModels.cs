using System;
using System.Collections.Generic;

namespace ChillQQMusic
{
    /// <summary>音质（对应 QQ 音乐的文件名前缀）。</summary>
    public enum AudioQuality
    {
        /// <summary>C400，m4a/AAC，兼容性最好，无需会员。</summary>
        M4A_128 = 0,
        /// <summary>M500，mp3 128kbps，最稳的流派。</summary>
        MP3_128 = 1,
        /// <summary>M800，mp3 320kbps，多数歌曲需要绿钻。</summary>
        MP3_320 = 2,
        /// <summary>F000，flac。Unity 的 UnityWebRequest 无法解码 flac，会自动降级。</summary>
        FLAC = 3
    }

    public enum PlayMode
    {
        /// <summary>顺序播放，播到末尾停止。</summary>
        Sequential = 0,
        /// <summary>单曲循环。</summary>
        RepeatOne = 1,
        /// <summary>随机播放。</summary>
        Shuffle = 2
    }

    public enum ApiMode
    {
        /// <summary>直接调用 QQ 音乐官方 Web 接口（默认，无需额外服务）。</summary>
        DirectQqWeb = 0,
        /// <summary>走自建/第三方聚合 API（实现 IQQMusicService 的 REST 约定）。</summary>
        CustomRest = 1
    }

    /// <summary>一首歌的元数据。</summary>
    public sealed class SongInfo
    {
        public string Mid = string.Empty;
        public string Title = string.Empty;
        public string Artist = string.Empty;
        public string Album = string.Empty;
        public string CoverUrl = string.Empty;
        public int DurationSeconds;
        public int SongId;
        public int FileSizeBytes;

        public string DisplayName =>
            string.IsNullOrEmpty(Artist) ? Title : Title + " - " + Artist;

        public override string ToString() => DisplayName;
    }

    public sealed class PlaylistSummary
    {
        public string Id = string.Empty;
        public string Name = string.Empty;
        public int SongCount;

        public override string ToString() => string.IsNullOrEmpty(Name) ? Id : Name + " (" + SongCount + ")";
    }

    public sealed class PlaylistInfo
    {
        public string Id = string.Empty;
        public string Name = string.Empty;
        public readonly List<SongInfo> Songs = new List<SongInfo>();
        public DateTime FetchedAt = DateTime.Now;
    }

    /// <summary>解析出来的播放地址。</summary>
    public sealed class SongUrl
    {
        public string Url = string.Empty;
        /// <summary>
        /// 备用地址：优先用我们指定的 MP3（req_1），它 404 时回退到接口按 songmid 给的地址（req_0，通常是 m4a）。
        /// </summary>
        public string FallbackUrl = string.Empty;
        public string Container = "mp3";     // mp3 / m4a / flac
        public string QualityLabel = string.Empty;
        public int BitrateKbps;
        public DateTime ExpireAt = DateTime.MaxValue;
        public AudioQuality RequestedQuality = AudioQuality.MP3_320;

        public bool IsExpired => DateTime.Now >= ExpireAt - TimeSpan.FromMinutes(2);
    }

    public sealed class LyricLine
    {
        public double Time;
        public string Text = string.Empty;
        public string Translation = string.Empty;

        public string Display =>
            string.IsNullOrEmpty(Translation) ? Text : Text + "\n" + Translation;
    }

    public sealed class Lyrics
    {
        public readonly List<LyricLine> Lines = new List<LyricLine>();
        public string Raw = string.Empty;
        public bool IsEmpty => Lines.Count == 0;
    }

    /// <summary>网络 / 接口层错误，UI 会把它翻译成友好提示。</summary>
    public sealed class QQMusicException : Exception
    {
        public QQMusicException(string message) : base(message) { }
        public QQMusicException(string message, Exception inner) : base(message, inner) { }

        /// <summary>
        /// true 表示"没拿到播放地址是因为缺少登录态"。
        /// 这种情况下不要去跑音质降级链（三次请求都注定失败），直接给用户可操作的提示。
        /// </summary>
        public bool LoginRequired { get; set; }
    }

    public sealed class QQUserInfo
    {
        public string Uin = string.Empty;
        public string Nickname = string.Empty;
        public string AvatarUrl = string.Empty;
    }
}

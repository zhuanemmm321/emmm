// 仅用于「离线编译校验」的最小 BepInEx 桩实现。
// 不参与正式插件编译（正式工程引用真实 BepInEx.dll）。
// 目的：在没有安装 BepInEx 的机器上，也能用真实 Unity 程序集验证插件源码能否编译。
using System;
using System.Collections.Generic;
using UnityEngine;

namespace BepInEx
{
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class BepInPlugin : Attribute
    {
        public BepInPlugin(string guid, string name, string version)
        {
            GUID = guid;
            Name = name;
            Version = version;
        }

        public string GUID { get; }
        public string Name { get; }
        public string Version { get; }
    }

    [AttributeUsage(AttributeTargets.Class)]
    public sealed class BepInDependency : Attribute
    {
        public BepInDependency(string guid) { DependencyGUID = guid; }
        public string DependencyGUID { get; }
    }

    public static class Paths
    {
        public static string BepInExPath = "BepInEx";
        public static string PluginPath = "BepInEx/plugins";
        public static string ConfigPath = "BepInEx/config";
        public static string CachePath = "BepInEx/cache";
        public static string GameDataPath = "Game_Data";
    }

    public abstract class BaseUnityPlugin : MonoBehaviour
    {
        protected BaseUnityPlugin()
        {
            Logger = Logging.Logger.CreateLogSource(GetType().Name);
            Config = new Configuration.ConfigFile("BepInEx/config/stub.cfg");
        }

        protected Configuration.ConfigFile Config { get; }
        protected Logging.ManualLogSource Logger { get; }
    }
}

namespace BepInEx.Logging
{
    public class ManualLogSource
    {
        private readonly string _name;
        public ManualLogSource(string name) { _name = name; }
        public void LogInfo(object data) => Console.WriteLine("[Info:" + _name + "] " + data);
        public void LogWarning(object data) => Console.WriteLine("[Warn:" + _name + "] " + data);
        public void LogError(object data) => Console.WriteLine("[Error:" + _name + "] " + data);
        public void LogDebug(object data) => Console.WriteLine("[Debug:" + _name + "] " + data);
        public void LogMessage(object data) => Console.WriteLine("[Msg:" + _name + "] " + data);
    }

    public static class Logger
    {
        public static ManualLogSource CreateLogSource(string name) => new ManualLogSource(name);
    }
}

namespace BepInEx.Configuration
{
    public sealed class SettingChangedEventArgs : EventArgs
    {
        public object ChangedSetting { get; set; }
    }

    public class ConfigDescription
    {
        public ConfigDescription(string description) { Description = description; }
        public string Description { get; }
    }

    public class ConfigEntry<T>
    {
        internal ConfigEntry(string section, string key, T value)
        {
            Definition = new ConfigDefinition(section, key);
            Value = value;
        }

        public ConfigDefinition Definition { get; }
        public string Description { get; set; }

        private T _value;
        public T Value
        {
            get => _value;
            set
            {
                _value = value;
                SettingChanged?.Invoke(this, new SettingChangedEventArgs { ChangedSetting = this });
            }
        }

        public event EventHandler<SettingChangedEventArgs> SettingChanged;
    }

    public class ConfigDefinition
    {
        public ConfigDefinition(string section, string key) { Section = section; Key = key; }
        public string Section { get; }
        public string Key { get; }
    }

    public class ConfigFile
    {
        private readonly Dictionary<string, object> _entries = new Dictionary<string, object>();

        public ConfigFile() { }
        public ConfigFile(string path) { ConfigFilePath = path; }

        public string ConfigFilePath { get; }

        public ConfigEntry<T> Bind<T>(string section, string key, T defaultValue, string description)
        {
            var id = section + "|" + key;
            if (_entries.TryGetValue(id, out var existing) && existing is ConfigEntry<T> typed) return typed;
            var entry = new ConfigEntry<T>(section, key, defaultValue) { Description = description };
            _entries[id] = entry;
            return entry;
        }

        public ConfigEntry<T> Bind<T>(string section, string key, T defaultValue, ConfigDescription description)
            => Bind(section, key, defaultValue, description?.Description ?? string.Empty);

        public void Save() { }
        public void Reload() { }
    }
}

// ---------------------------------------------------------------------------
// HarmonyLib 桩：只为离线编译校验存在，正式编译引用 BepInEx 自带的 0Harmony.dll
// ---------------------------------------------------------------------------
namespace HarmonyLib
{
    public class HarmonyMethod
    {
        public HarmonyMethod(System.Reflection.MethodInfo method) { Method = method; }
        public HarmonyMethod(Type type, string name) { Method = type.GetMethod(name); }
        public System.Reflection.MethodInfo Method { get; set; }
    }

    public class Harmony
    {
        public Harmony(string id) { Id = id; }
        public string Id { get; }

        public System.Reflection.MethodInfo Patch(System.Reflection.MethodInfo original,
            HarmonyMethod prefix = null, HarmonyMethod postfix = null, HarmonyMethod transpiler = null, HarmonyMethod finalizer = null)
            => original;

        public void UnpatchSelf() { }
        public void UnpatchAll(string harmonyId = null) { }
    }

    public static class AccessTools
    {
        public static Type TypeByName(string name)
        {
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    var t = asm.GetType(name, false);
                    if (t != null) return t;
                }
                catch { /* 忽略 */ }
            }
            return null;
        }

        public static System.Reflection.MethodInfo Method(Type type, string name, Type[] parameters = null)
        {
            if (type == null) return null;
            const System.Reflection.BindingFlags flags = System.Reflection.BindingFlags.Public
                | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance
                | System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.DeclaredOnly;
            if (parameters == null) return type.GetMethod(name, flags);
            return type.GetMethod(name, flags, null, parameters, null);
        }

        public static System.Reflection.FieldInfo Field(Type type, string name)
        {
            if (type == null) return null;
            const System.Reflection.BindingFlags flags = System.Reflection.BindingFlags.Public
                | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance
                | System.Reflection.BindingFlags.Static;
            return type.GetField(name, flags);
        }
    }
}

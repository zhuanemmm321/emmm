// Standalone replica of LoFiTheme's icon rasteriser.
// Renders each icon at full size (64px) AND at the size it is actually displayed
// inside a button (25px) so small-size legibility can be checked without launching the game.
//
// usage: IconTest.exe <outputDir>
//
// NOTE: keep this file ASCII-only. PowerShell 5.1 re-encodes files as ANSI when using
// Set-Content without -Encoding, which corrupts non-ASCII comments.
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

internal static class Program
{
    private const int Size = 64;
    private const int DisplaySize = 25;   // 40px button x 0.62

    private static int Main(string[] args)
    {
        var outDir = args.Length > 0 ? args[0] : ".";
        Directory.CreateDirectory(outDir);

        foreach (var icon in Icons())
        {
            var buffer = new float[Size * Size];
            icon.draw(buffer, Size);

            Save(outDir, icon.name, buffer, Size);
            Save(outDir, icon.name + "_small", buffer, DisplaySize);
        }

        Console.WriteLine("icons written to " + Path.GetFullPath(outDir));
        return 0;
    }

    private static (string name, Action<float[], int> draw)[] Icons() => new (string, Action<float[], int>)[]
    {
        ("play", (b, s) => Triangle(b, s, V(0.20f, 0.10f), V(0.20f, 0.90f), V(0.88f, 0.50f))),

        ("pause", (b, s) =>
        {
            Box(b, s, 0.32f, 0.50f, 0.095f, 0.36f, 0.075f);
            Box(b, s, 0.68f, 0.50f, 0.095f, 0.36f, 0.075f);
        }),

        ("prev", (b, s) =>
        {
            Box(b, s, 0.13f, 0.50f, 0.06f, 0.32f, 0.05f);
            Triangle(b, s, V(0.94f, 0.10f), V(0.94f, 0.90f), V(0.26f, 0.50f));
        }),

        ("next", (b, s) =>
        {
            Box(b, s, 0.87f, 0.50f, 0.06f, 0.32f, 0.05f);
            Triangle(b, s, V(0.06f, 0.10f), V(0.06f, 0.90f), V(0.74f, 0.50f));
        }),

        ("repeat_all", (b, s) =>
        {
            Ring(b, s, 0.5f, 0.5f, 0.38f, 0.07f);
            Arrow(b, s, V(0.54f, 0.92f), V(0.86f, 0.60f), 0.07f, 0.26f);
        }),

        ("repeat_one", (b, s) =>
        {
            Ring(b, s, 0.5f, 0.5f, 0.39f, 0.065f);
            Arrow(b, s, V(0.56f, 0.93f), V(0.88f, 0.61f), 0.065f, 0.24f);
            Segment(b, s, 0.50f, 0.26f, 0.50f, 0.74f, 0.07f);
            Segment(b, s, 0.50f, 0.74f, 0.33f, 0.62f, 0.055f);
        }),

        ("shuffle", (b, s) =>
        {
            Arrow(b, s, V(0.09f, 0.76f), V(0.91f, 0.24f), 0.085f, 0.24f);
            Arrow(b, s, V(0.09f, 0.24f), V(0.91f, 0.76f), 0.085f, 0.24f);
        }),

        ("volume", (b, s) =>
        {
            Box(b, s, 0.24f, 0.50f, 0.085f, 0.115f, 0.03f);
            Triangle(b, s, V(0.325f, 0.62f), V(0.54f, 0.88f), V(0.54f, 0.12f));
            Arc(b, s, 0.54f, 0.50f, 0.185f, 0.065f, 0f, 62f);
            Arc(b, s, 0.54f, 0.50f, 0.295f, 0.065f, 0f, 58f);
        }),

        ("music", (b, s) =>
        {
            Circle(b, s, 0.30f, 0.22f, 0.17f);
            Segment(b, s, 0.45f, 0.24f, 0.45f, 0.86f, 0.045f);
            Triangle(b, s, V(0.45f, 0.88f), V(0.86f, 0.72f), V(0.45f, 0.54f));
        }),

        ("list", (b, s) =>
        {
            for (var i = 0; i < 3; i++)
            {
                var y = 0.24f + i * 0.26f;
                Box(b, s, 0.60f, y, 0.30f, 0.045f, 0.045f);
                Box(b, s, 0.16f, y, 0.045f, 0.045f, 0.045f);
            }
        }),

        ("refresh", (b, s) =>
        {
            Arc(b, s, 0.5f, 0.5f, 0.31f, 0.075f, 180f, 160f);
            Arrow(b, s, V(0.719f, 0.719f), V(0.791f, 0.606f), 0.075f, 0.23f);
        }),

        ("close", (b, s) =>
        {
            Segment(b, s, 0.20f, 0.20f, 0.80f, 0.80f, 0.06f);
            Segment(b, s, 0.80f, 0.20f, 0.20f, 0.80f, 0.06f);
        }),

        ("login", (b, s) =>
        {
            Circle(b, s, 0.50f, 0.72f, 0.165f);
            Arc(b, s, 0.50f, 0.12f, 0.36f, 0.085f, 90f, 74f);
        }),

        ("lyrics", (b, s) =>
        {
            Box(b, s, 0.50f, 0.72f, 0.34f, 0.06f, 0.06f);
            Box(b, s, 0.40f, 0.50f, 0.24f, 0.06f, 0.06f);
            Box(b, s, 0.46f, 0.28f, 0.30f, 0.06f, 0.06f);
        })
    };

    // ---------------- vector helpers ----------------

    private static Vector2 V(float x, float y) => new Vector2(x, y);

    private struct Vector2
    {
        public float x, y;
        public Vector2(float x, float y) { this.x = x; this.y = y; }
        public static Vector2 operator *(Vector2 v, float f) => new Vector2(v.x * f, v.y * f);
        public static Vector2 operator -(Vector2 a, Vector2 b) => new Vector2(a.x - b.x, a.y - b.y);
        public float magnitude => (float)Math.Sqrt(x * x + y * y);
        public Vector2 normalized
        {
            get { var m = magnitude; return m < 1e-6f ? new Vector2(0, 0) : new Vector2(x / m, y / m); }
        }
    }

    private static float EdgeDistance(float px, float py, Vector2 a, Vector2 b)
    {
        var cross = (b.x - a.x) * (py - a.y) - (b.y - a.y) * (px - a.x);
        var length = (float)Math.Sqrt((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y));
        return cross / Math.Max(0.0001f, length);
    }

    // inside => negative, independent of winding
    private static float SdTriangle(float px, float py, Vector2 a, Vector2 b, Vector2 c)
    {
        var d1 = EdgeDistance(px, py, a, b);
        var d2 = EdgeDistance(px, py, b, c);
        var d3 = EdgeDistance(px, py, c, a);

        var area = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
        if (area >= 0f) return -Math.Min(d1, Math.Min(d2, d3));   // counter-clockwise
        return Math.Max(d1, Math.Max(d2, d3));                     // clockwise
    }

    private static float SdBox(float px, float py, float cx, float cy, float hw, float hh, float r)
    {
        r = Math.Min(r, Math.Min(hw, hh));
        var qx = Math.Abs(px - cx) - hw + r;
        var qy = Math.Abs(py - cy) - hh + r;
        var outside = (float)Math.Sqrt(Math.Max(qx, 0) * Math.Max(qx, 0) + Math.Max(qy, 0) * Math.Max(qy, 0));
        return outside + Math.Min(Math.Max(qx, qy), 0) - r;
    }

    private static float SdCircle(float px, float py, float cx, float cy, float r)
        => (float)Math.Sqrt((px - cx) * (px - cx) + (py - cy) * (py - cy)) - r;

    private static float SdSegment(float px, float py, float ax, float ay, float bx, float by)
    {
        var pax = px - ax; var pay = py - ay;
        var bax = bx - ax; var bay = by - ay;
        var h = Math.Max(0f, Math.Min(1f, (pax * bax + pay * bay) / Math.Max(0.0001f, bax * bax + bay * bay)));
        var dx = pax - bax * h; var dy = pay - bay * h;
        return (float)Math.Sqrt(dx * dx + dy * dy);
    }

    private static void Paint(float[] buffer, int size, int x, int y, float distance, float aa = 1.2f)
    {
        if (x < 0 || y < 0 || x >= size || y >= size) return;
        var coverage = Math.Max(0f, Math.Min(1f, 0.5f - distance / aa));
        if (coverage <= 0.001f) return;
        var index = y * size + x;
        if (coverage > buffer[index]) buffer[index] = coverage;
    }

    private static void Box(float[] b, int size, float cx, float cy, float hw, float hh, float r)
    {
        for (var y = 0; y < size; y++)
        for (var x = 0; x < size; x++)
            Paint(b, size, x, y, SdBox(x + 0.5f, y + 0.5f, cx * size, cy * size, hw * size, hh * size, r * size));
    }

    private static void Triangle(float[] b, int size, Vector2 a, Vector2 c1, Vector2 c2)
    {
        var p1 = new Vector2(a.x * size, a.y * size);
        var p2 = new Vector2(c1.x * size, c1.y * size);
        var p3 = new Vector2(c2.x * size, c2.y * size);
        for (var y = 0; y < size; y++)
        for (var x = 0; x < size; x++)
            Paint(b, size, x, y, SdTriangle(x + 0.5f, y + 0.5f, p1, p2, p3));
    }

    private static void Segment(float[] b, int size, float ax, float ay, float bx, float by, float thickness)
    {
        for (var y = 0; y < size; y++)
        for (var x = 0; x < size; x++)
            Paint(b, size, x, y, SdSegment(x + 0.5f, y + 0.5f, ax * size, ay * size, bx * size, by * size) - thickness * size);
    }

    private static void Ring(float[] b, int size, float cx, float cy, float radius, float thickness)
    {
        for (var y = 0; y < size; y++)
        for (var x = 0; x < size; x++)
            Paint(b, size, x, y, Math.Abs(SdCircle(x + 0.5f, y + 0.5f, cx * size, cy * size, radius * size)) - thickness * size);
    }

    private static void Circle(float[] b, int size, float cx, float cy, float radius)
    {
        for (var y = 0; y < size; y++)
        for (var x = 0; x < size; x++)
            Paint(b, size, x, y, SdCircle(x + 0.5f, y + 0.5f, cx * size, cy * size, radius * size));
    }

    private static void Arc(float[] b, int size, float cx, float cy, float radius, float thickness,
        float centerDeg, float halfSpanDeg)
    {
        for (var y = 0; y < size; y++)
        for (var x = 0; x < size; x++)
        {
            var px = x + 0.5f;
            var py = y + 0.5f;
            var dx = px - cx * size;
            var dy = py - cy * size;
            var distance = (float)Math.Sqrt(dx * dx + dy * dy);
            var ring = Math.Abs(distance - radius * size) - thickness * size;
            if (ring > 1.5f) continue;

            var angle = (float)(Math.Atan2(dy, dx) * 180.0 / Math.PI);
            var delta = Math.Abs(((angle - centerDeg + 540f) % 360f) - 180f);
            if (delta > halfSpanDeg) continue;

            Paint(b, size, x, y, ring);
        }
    }

    private static void Arrow(float[] b, int size, Vector2 from, Vector2 to, float thickness, float headLength)
    {
        Segment(b, size, from.x, from.y, to.x, to.y, thickness);

        var f = new Vector2(from.x * size, from.y * size);
        var t = new Vector2(to.x * size, to.y * size);
        var direction = (t - f).normalized;
        var perpendicular = new Vector2(-direction.y, direction.x);
        var basePoint = t - direction * (headLength * size);

        Triangle(b, size,
            new Vector2(t.x / size, t.y / size),
            new Vector2((basePoint.x + perpendicular.x * headLength * 0.62f * size) / size,
                        (basePoint.y + perpendicular.y * headLength * 0.62f * size) / size),
            new Vector2((basePoint.x - perpendicular.x * headLength * 0.62f * size) / size,
                        (basePoint.y - perpendicular.y * headLength * 0.62f * size) / size));
    }

    // ---------------- output ----------------

    private static void Save(string dir, string name, float[] buffer, int outSize)
    {
        using (var bmp = new Bitmap(outSize, outSize, PixelFormat.Format32bppArgb))
        {
            var scale = Size / (float)outSize;
            for (var y = 0; y < outSize; y++)
            for (var x = 0; x < outSize; x++)
            {
                float alpha;
                if (outSize == Size)
                {
                    alpha = buffer[y * Size + x];
                }
                else
                {
                    // bilinear downscale, mimics how Unity displays the sprite
                    var sx = x * scale;
                    var sy = y * scale;
                    var x0 = (int)sx; var y0 = (int)sy;
                    var x1 = Math.Min(Size - 1, x0 + 1); var y1 = Math.Min(Size - 1, y0 + 1);
                    var fx = sx - x0; var fy = sy - y0;
                    alpha = buffer[y0 * Size + x0] * (1 - fx) * (1 - fy) + buffer[y0 * Size + x1] * fx * (1 - fy)
                          + buffer[y1 * Size + x0] * (1 - fx) * fy + buffer[y1 * Size + x1] * fx * fy;
                }

                var v = (int)Math.Max(0, Math.Min(255, alpha * 255));
                // black icon on white background, so shapes are easy to inspect
                bmp.SetPixel(x, outSize - 1 - y, Color.FromArgb(255 - v, 255 - v, 255 - v));
            }
            bmp.Save(Path.Combine(dir, name + ".png"), ImageFormat.Png);
        }
    }
}

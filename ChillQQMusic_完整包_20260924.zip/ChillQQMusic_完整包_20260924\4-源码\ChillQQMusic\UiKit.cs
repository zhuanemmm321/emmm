using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ChillQQMusic
{
    /// <summary>自己实现的滑条，避免 UGUI Slider 的布局细节在不同版本里表现不一致。</summary>
    internal sealed class LofiSlider : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        internal RectTransform Area;
        internal Image Fill;
        internal RectTransform Handle;
        internal bool Interactable = true;

        internal event Action<float> Changed;
        internal event Action<float> Committed;

        private float _value;
        private bool _dragging;

        internal float Value
        {
            get => _value;
            set => Apply(Mathf.Clamp01(value), false, false);
        }

        internal void SetValueWithoutNotify(float value) => Apply(Mathf.Clamp01(value), false, false);

        private void Apply(float value, bool notify, bool commit)
        {
            _value = Mathf.Clamp01(value);
            // 关键：anchorMax.y 必须是 0.5（与 anchorMin.y 相同）。
            // 之前写成 1f，填充块就从"半个滑条高度 + trackHeight"算起 —— 于是
            // 3px 的填充被撑成 12px 的方块，比凹槽粗 4 倍。
            if (Fill != null) Fill.rectTransform.anchorMax = new Vector2(_value, 0.5f);
            if (Handle != null && Area != null)
                Handle.anchoredPosition = new Vector2((_value - 0.5f) * Area.rect.width, 0f);

            if (notify) Changed?.Invoke(_value);
            if (commit) Committed?.Invoke(_value);
        }

        private void Update()
        {
            // 分辨率变化时重新对齐手柄
            if (Handle != null && Area != null && !_dragging)
            {
                var target = new Vector2((_value - 0.5f) * Area.rect.width, 0f);
                if ((Handle.anchoredPosition - target).sqrMagnitude > 0.25f) Handle.anchoredPosition = target;
            }
        }

        public void OnPointerDown(PointerEventData eventData) => HandlePointer(eventData, false);

        public void OnDrag(PointerEventData eventData) => HandlePointer(eventData, false);

        public void OnPointerUp(PointerEventData eventData)
        {
            _dragging = false;
            if (!Interactable) return;
            HandlePointer(eventData, true);
        }

        private void HandlePointer(PointerEventData eventData, bool commit)
        {
            if (!Interactable || Area == null) return;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(Area, eventData.position,
                    eventData.pressEventCamera, out var local)) return;

            _dragging = !commit;
            var normalized = local.x / Mathf.Max(1f, Area.rect.width) + 0.5f;
            Apply(normalized, true, commit);
        }
    }

    /// <summary>悬浮窗拖拽（限制在屏幕内）。</summary>
    internal sealed class PanelDragHandler : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        internal RectTransform Target;
        internal Canvas Canvas;
        internal Action<Vector2> DragEnded;

        private Vector2 _startPointer;
        private Vector2 _startPosition;

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (Target == null) return;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(Target.parent as RectTransform, eventData.position,
                eventData.pressEventCamera, out _startPointer);
            _startPosition = Target.anchoredPosition;
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (Target == null) return;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(Target.parent as RectTransform, eventData.position,
                    eventData.pressEventCamera, out var current)) return;

            var delta = current - _startPointer;
            Target.anchoredPosition = _startPosition + delta;

            var parent = Target.parent as RectTransform;
            if (parent == null) return;

            // 允许任意 pivot：anchoredPosition 表示 pivot 相对锚点的位置。
            var parentSize = parent.rect.size;
            var selfSize = Target.rect.size;
            var pivot = Target.pivot;
            var pos = Target.anchoredPosition;
            var minX = pivot.x * selfSize.x;
            var maxX = parentSize.x - (1f - pivot.x) * selfSize.x;
            var minY = pivot.y * selfSize.y;
            var maxY = parentSize.y - (1f - pivot.y) * selfSize.y;
            pos.x = maxX >= minX ? Mathf.Clamp(pos.x, minX, maxX) : (minX + maxX) * 0.5f;
            pos.y = maxY >= minY ? Mathf.Clamp(pos.y, minY, maxY) : (minY + maxY) * 0.5f;
            Target.anchoredPosition = pos;
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (Target != null) DragEnded?.Invoke(Target.anchoredPosition);
        }
    }

    /// <summary>UGUI 控件工厂。所有控件都在代码里创建，不依赖 AssetBundle。</summary>
    internal static class UiKit
    {
        internal static GameObject Node(Transform parent, string name, params Type[] components)
        {
            var go = new GameObject(name, components);
            go.transform.SetParent(parent, false);
            if (go.GetComponent<RectTransform>() == null) go.AddComponent<RectTransform>();
            return go;
        }

        internal static RectTransform Rect(GameObject go) => go.GetComponent<RectTransform>();

        internal static Image Panel(Transform parent, string name, Sprite sprite, Color color, bool raycast = false)
        {
            var go = Node(parent, name, typeof(RectTransform), typeof(Image));
            var image = go.GetComponent<Image>();
            image.sprite = sprite;
            image.color = color;
            image.raycastTarget = raycast;
            if (sprite != null && sprite.border != Vector4.zero) image.type = UnityEngine.UI.Image.Type.Sliced;
            return image;
        }

        internal static Text Label(Transform parent, string name, string content, int size, Color color,
            TextAnchor anchor = TextAnchor.MiddleLeft, FontStyle style = FontStyle.Normal)
        {
            var go = Node(parent, name, typeof(RectTransform), typeof(Text));
            var text = go.GetComponent<Text>();
            text.font = LoFiTheme.UiFont;
            text.fontSize = size;
            text.fontStyle = style;
            text.color = color;
            text.alignment = anchor;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.raycastTarget = false;
            text.text = content;
            return text;
        }

        internal static Button IconButton(Transform parent, string name, Vector2 size, Sprite background,
            LofiIcon icon, Color iconColor, Action onClick, string tooltip = null, float iconScale = 0.62f)
        {
            var go = Node(parent, name, typeof(RectTransform), typeof(Image), typeof(Button));
            var rect = Rect(go);
            rect.sizeDelta = size;

            var image = go.GetComponent<Image>();
            image.sprite = background;
            image.color = Color.white;
            image.raycastTarget = true;

            var button = go.GetComponent<Button>();
            button.targetGraphic = image;
            button.transition = Selectable.Transition.ColorTint;
            var colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 0.96f, 0.88f, 1f);
            colors.pressedColor = new Color(0.85f, 0.78f, 0.65f, 1f);
            colors.selectedColor = colors.highlightedColor;
            colors.fadeDuration = 0.12f;
            button.colors = colors;
            if (onClick != null) button.onClick.AddListener(() => onClick());

            var iconGo = Node(go.transform, "Icon", typeof(RectTransform), typeof(Image));
            var iconImage = iconGo.GetComponent<Image>();
            iconImage.sprite = LoFiTheme.Icon(icon);
            iconImage.color = iconColor;
            iconImage.raycastTarget = false;
            var iconRect = Rect(iconGo);
            iconRect.anchorMin = new Vector2(0.5f, 0.5f);
            iconRect.anchorMax = new Vector2(0.5f, 0.5f);
            iconRect.sizeDelta = size * iconScale;   // 略放大：小图标在按钮里更容易辨认
            iconRect.anchoredPosition = Vector2.zero;

            if (!string.IsNullOrEmpty(tooltip))
            {
                var tooltipText = Label(go.transform, "Tooltip", tooltip, 12, LoFiTheme.InkSoft, TextAnchor.MiddleCenter);
                var tooltipRect = tooltipText.rectTransform;
                tooltipRect.anchorMin = new Vector2(0.5f, 1f);
                tooltipRect.anchorMax = new Vector2(0.5f, 1f);
                tooltipRect.sizeDelta = new Vector2(160f, 22f);
                tooltipRect.anchoredPosition = new Vector2(0f, 16f);
                tooltipText.gameObject.SetActive(false);
                var trigger = go.AddComponent<EventTrigger>();
                var enter = new EventTrigger.Entry { eventID = EventTriggerType.PointerEnter };
                enter.callback.AddListener(_ => tooltipText.gameObject.SetActive(true));
                var exit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
                exit.callback.AddListener(_ => tooltipText.gameObject.SetActive(false));
                trigger.triggers.Add(enter);
                trigger.triggers.Add(exit);
            }

            return button;
        }

        internal static void SetIcon(Button button, LofiIcon icon)
        {
            if (button == null) return;
            var iconTransform = button.transform.Find("Icon");
            if (iconTransform == null) return;
            var image = iconTransform.GetComponent<Image>();
            if (image != null) image.sprite = LoFiTheme.Icon(icon);
        }

        internal static Button TextButton(Transform parent, string name, string content, int fontSize,
            Vector2 size, Color background, Color foreground, Action onClick)
        {
            var go = Node(parent, name, typeof(RectTransform), typeof(Image), typeof(Button));
            var rect = Rect(go);
            rect.sizeDelta = size;

            var image = go.GetComponent<Image>();
            image.sprite = LoFiTheme.RoundedRect(48, 48, 14, background, background);
            image.type = UnityEngine.UI.Image.Type.Sliced;
            image.color = Color.white;

            var button = go.GetComponent<Button>();
            button.targetGraphic = image;
            var colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 0.98f, 0.94f, 1f);
            colors.pressedColor = new Color(0.9f, 0.85f, 0.76f, 1f);
            colors.fadeDuration = 0.12f;
            button.colors = colors;
            if (onClick != null) button.onClick.AddListener(() => onClick());

            var text = Label(go.transform, "Text", content, fontSize, foreground, TextAnchor.MiddleCenter);
            var textRect = text.rectTransform;
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.offsetMin = new Vector2(8f, 0f);
            textRect.offsetMax = new Vector2(-8f, 0f);

            return button;
        }

        internal static LofiSlider Slider(Transform parent, string name, Vector2 size, float trackHeight,
            float handleSize, Color trackColor, Color fillColor, Color handleColor,
            Sprite fillSprite = null, Sprite handleSprite = null, Sprite trackSprite = null)
        {
            var go = Node(parent, name, typeof(RectTransform), typeof(LofiSlider));
            var rect = Rect(go);
            rect.sizeDelta = size;

            var slider = go.GetComponent<LofiSlider>();

            var track = Panel(go.transform, "Track",
                trackSprite ?? LoFiTheme.RoundedRect(32, 32, 16, trackColor, trackColor), Color.white);
            var trackRect = track.rectTransform;
            trackRect.anchorMin = new Vector2(0f, 0.5f);
            trackRect.anchorMax = new Vector2(1f, 0.5f);
            trackRect.sizeDelta = new Vector2(0f, trackHeight);
            trackRect.anchoredPosition = Vector2.zero;

            var area = Node(go.transform, "Area", typeof(RectTransform));
            var areaRect = Rect(area);
            areaRect.anchorMin = new Vector2(0f, 0.5f);
            areaRect.anchorMax = new Vector2(1f, 0.5f);
            areaRect.sizeDelta = new Vector2(-handleSize, size.y);
            areaRect.anchoredPosition = Vector2.zero;

            var fill = Panel(area.transform, "Fill",
                fillSprite ?? LoFiTheme.RoundedRect(32, 32, 16, fillColor, fillColor), Color.white);
            var fillRect = fill.rectTransform;
            fillRect.anchorMin = new Vector2(0f, 0.5f);
            fillRect.anchorMax = new Vector2(1f, 0.5f);
            fillRect.sizeDelta = new Vector2(0f, trackHeight);
            fillRect.anchoredPosition = Vector2.zero;

            var handle = Panel(go.transform, "Handle",
                handleSprite ?? LoFiTheme.Circle(64, handleColor, LoFiTheme.PaperDeep, 2), Color.white, true);
            var handleRect = handle.rectTransform;
            handleRect.anchorMin = new Vector2(0.5f, 0.5f);
            handleRect.anchorMax = new Vector2(0.5f, 0.5f);
            handleRect.sizeDelta = new Vector2(handleSize, handleSize);
            handleRect.anchoredPosition = Vector2.zero;

            slider.Area = areaRect;
            slider.Fill = fill;
            slider.Handle = handleRect;
            slider.Value = 0f;
            return slider;
        }

        internal static InputField Input(Transform parent, string name, string placeholder, int fontSize, Vector2 size)
        {
            var go = Node(parent, name, typeof(RectTransform), typeof(Image), typeof(InputField));
            Rect(go).sizeDelta = size;

            var image = go.GetComponent<Image>();
            image.sprite = LoFiTheme.RoundedRect(48, 48, 12, LoFiTheme.PaperDeep, LoFiTheme.PaperDeep);
            image.type = UnityEngine.UI.Image.Type.Sliced;
            image.color = Color.white;

            var text = Label(go.transform, "Text", string.Empty, fontSize, LoFiTheme.Ink, TextAnchor.MiddleLeft);
            var textRect = text.rectTransform;
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.offsetMin = new Vector2(10f, 4f);
            textRect.offsetMax = new Vector2(-10f, -4f);
            text.supportRichText = false;

            var placeholderText = Label(go.transform, "Placeholder", placeholder, fontSize, LoFiTheme.InkSoft, TextAnchor.MiddleLeft);
            var placeholderRect = placeholderText.rectTransform;
            placeholderRect.anchorMin = Vector2.zero;
            placeholderRect.anchorMax = Vector2.one;
            placeholderRect.offsetMin = new Vector2(10f, 4f);
            placeholderRect.offsetMax = new Vector2(-10f, -4f);
            placeholderText.fontStyle = FontStyle.Italic;

            var input = go.GetComponent<InputField>();
            input.textComponent = text;
            input.placeholder = placeholderText;
            input.targetGraphic = image;
            input.lineType = InputField.LineType.SingleLine;
            return input;
        }

        internal static void Stretch(RectTransform rect, float left = 0f, float top = 0f, float right = 0f, float bottom = 0f)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(left, bottom);
            rect.offsetMax = new Vector2(-right, -top);
        }
    }
}

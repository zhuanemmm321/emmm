# Chill QQ Music —— 《放松时光：与你共享 Lo-Fi 故事》游戏内 QQ 音乐播放器

BepInEx 5.x (Mono) 插件。在游戏里叠加一个 Lo-Fi 风格的悬浮播放器，通过非官方 QQ 音乐接口
读取歌单 / 播放地址 / 歌词，用 Unity 自己的 `AudioSource` 播放，**不依赖 QQ 音乐客户端窗口**。

> 仅供个人学习与自用。不包含任何绕过付费、破解 DRM 或下载受版权保护内容的功能；
> 高音质（320K / FLAC）是否可用完全取决于你自己的 QQ 音乐账号权限。

---

## 1. 可行性评估、风险与依赖

### 已确认的宿主环境

| 项目 | 实测值 | 说明 |
| --- | --- | --- |
| 引擎 / 运行时 | **Unity 2022.3.62f2 + Mono** | `Chill With You_Data\Managed\Assembly-CSharp.dll` 与 `MonoBleedingEdge` 均存在，**不是 IL2CPP** |
| BepInEx | **尚未安装**，建议 **5.4.23.x (x64, Mono)** | IL2CPP 版 BepInEx 6 不适用 |
| 关键程序集 | `UnityEngine.UI.dll`、`UnityEngine.AudioModule.dll`、`UnityEngine.UnityWebRequest*`、`Newtonsoft.Json.dll`、`System.Net.Http.dll`、`System.Security.dll` | 均已随游戏提供，插件直接复用，不额外分发 |
| 输入系统 | 仅旧版 Input（`Unity.InputSystem.dll` 不存在） | 因此用 `Input.GetKeyDown` 与 `StandaloneInputModule` 是安全的 |

### 技术可行性结论

* **可行**。除「系统媒体控制中心(SMTC)」一项外，其余需求都在进程内实现完了：
  * 非官方 QQ 音乐接口本质是普通 HTTPS 请求 → `HttpClient` 在 Mono 下工作正常；
  * 播放走 `UnityWebRequestMultimedia.GetAudioClip` + `DownloadHandlerAudioClip.streamAudio`，
    **能真正做到边下边播**（MP3/OGG/WAV），并且不引入任何原生解码器；
  * UI 用 UGUI 代码动态创建，纹理由程序化生成（圆角/SDF 抗锯齿），**不依赖 AssetBundle**。

### 风险清单（按严重度排序）

1. **接口不稳定（高）**：QQ 音乐 Web 接口是非官方的，随时可能改字段或加风控。
   对策：所有解析都做防御式取值；音质自动降级（320K → 128K → M4A）；失败重试 + 超时；
   且 `IQQMusicService` 可整体替换成自建服务。
2. **登录票据获取（中高）**：扫码登录最后一步需要换取 `qm_keyst`，不同地区/风控策略下可能拿不到。
   对策：保留「手动粘贴 Cookie」通道（同样 DPAPI 加密存储），保证功能不会因腾讯改流程而完全失效。
3. **会员/版权限制（中）**：部分歌曲即使登录也返回空 `purl`。插件会明确提示「需要会员或受版权限制」，
   不会尝试绕过。
4. **时间同步（中）**：vkey 约 20 分钟过期，缓存的播放地址按 15 分钟失效处理，并在结束前 15 秒预取下一首。
5. **系统媒体键冲突（低）**：注册成功后其他程序在游戏运行期间收不到媒体键，可在配置里关闭。
6. **FLAC（低）**：Unity 的 `UnityWebRequest` 不解码 FLAC，插件会自动改用 320K，并在 UI 提示。

### 依赖

* 运行期：BepInEx 5.4.23.x（自带 `0Harmony.dll`，本插件**没有使用任何 Harmony 补丁**）
* 编译期：.NET Framework 4.7.2 / 4.8 目标包、Visual Studio 2022 或 `csc`、游戏自身的 `Managed` 目录
* 网络：能访问 `*.qq.com`（`u.y.qq.com` / `c.y.qq.com` / `ssl.ptlogin2.qq.com` / `y.qq.com`）

---

## 2. 项目结构与文件职责

```
ChillQQMusic/
├── ChillQQMusic.csproj      # 正式工程（引用真实 BepInEx.dll，编译后自动复制到 plugins）
├── Plugin.cs                # BepInEx 入口：装配各模块、主循环、快捷键、媒体键、生命周期清理
├── ConfigManager.cs         # 所有 BepInEx 配置项（歌单/音质/音量/UI/快捷键/网络/缓存）
├── QQMusicService.cs        # IQQMusicService 接口 + 直连官方 Web 实现 + 自定义 REST 实现
├── QQMusicModels.cs         # SongInfo / PlaylistInfo / SongUrl / Lyrics / 枚举 / 异常
├── QQHttp.cs                # 统一 HttpClient：CookieContainer、UA、超时、指数退避重试
├── LoginManager.cs          # QQ 扫码登录（ptqrshow → hash33 → ptqrlogin 轮询 → 换取 Cookie）
├── SecureCookieStore.cs     # 凭证加密落盘（DPAPI，失败退化为 AES 混淆，绝不写明文配置）
├── AudioPlayer.cs           # 单 AudioSource 播放核心：边下边播、淡入淡出、Seek、错误分类
├── AudioCache.cs            # 已完整播放过的音频文件缓存 + LRU 清理（后台线程写盘）
├── PlaylistManager.cs       # 歌单/队列逻辑：切歌、播放模式、预取、音质降级、歌词调度
├── LyricsParser.cs          # LRC 解析（一行多时间戳、翻译对齐、当前行定位）
├── UIManager.cs             # 悬浮窗：黑胶封面、进度、音量、模式、歌词、登录/歌单面板、淡出
├── UiKit.cs                 # UGUI 控件工厂 + 自研 LofiSlider + 窗口拖拽
├── LoFiTheme.cs             # 程序化 Lo-Fi 贴图：圆角纸面、噪点、黑胶、矢量图标、配色
├── MainThreadDispatcher.cs  # 后台线程 → 主线程的任务队列（UGUI 线程安全的关键）
├── Patches.cs               # Harmony 补丁：注入游戏内音乐按钮 + 播放时压低游戏 BGM
└── NativeMediaBridge.cs     # 键盘媒体键全局注册（P/Invoke）+ SMTC 不可行性说明

tools/StubCheck/             # 仅用于离线编译校验（真实 Unity 程序集 + BepInEx 桩）
tools/TypeDump/              # 开发用：反射 dump 游戏类型/方法，用来挑 Harmony 挂载点
build.ps1                    # 不依赖 MSBuild SDK 的备用构建脚本（直接调 csc）
```

---

## 3. 编译

### 方式 A：Visual Studio / MSBuild（推荐）

1. 先用 BepInEx 5 启动一次游戏，生成 `BepInEx\core\BepInEx.dll`。
2. 打开 `ChillQQMusic\ChillQQMusic.csproj`，确认顶部 `GameDir` 指向游戏目录（默认已经是你机器上的路径）。
3. 生成 Release。编译产物会自动复制到 `BepInEx\plugins\ChillQQMusic\`。

命令行（把路径换成你的）：

```powershell
msbuild ChillQQMusic\ChillQQMusic.csproj /p:Configuration=Release `
  /p:GameDir="D:\SteamLibrary\steamapps\common\Chill with You Lo-Fi Story"
```

### 方式 B：build.ps1（不需要 MSBuild SDK）

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

### 方式 C：离线语法校验（没装 BepInEx 也能跑）

```powershell
msbuild tools\StubCheck\StubCheck.csproj /p:Configuration=Release
```

本工程已用 **游戏自带的 Unity 2022.3.62f2 程序集 + 最小 BepInEx 桩** 完整编译通过
（0 error / 0 warning，覆盖 `AudioType.ACC`、`streamAudio`、`DownloadHandlerAudioClip` 等真实 API）。

---

## 4. 配置项说明（`BepInEx\config\com.codex.chillqqmusic.cfg`）

| 段 | 键 | 默认 | 说明 |
| --- | --- | --- | --- |
| 01-通用 | 歌单ID | **9697794311** | 纯数字歌单 ID（默认 = 歌单「chang」，492 首） |
| 01-通用 | 歌单链接 | *(空)* | 分享链接或分享短码，插件自动解析成数字 ID；与歌单ID 同时填写时以链接为准 |
| 01-通用 | 用户UID | **GQ7L16LGB** | 用户主页 UID；仅当「歌单ID」为空时生效，会加载该用户公开歌单合集（解析需要登录态） |
| 01-通用 | API模式 | DirectQqWeb | `DirectQqWeb` 直连；`CustomRest` 走自建服务 |
| 01-通用 | 自定义API地址 | `http://127.0.0.1:8080` | 仅 CustomRest 生效 |
| 01-通用 | 自定义API令牌 | *(空)* | 以 `Authorization: Bearer` 发送 |
| 01-通用 | 音质 | **MP3_320（320K）** | `M4A_128` / `MP3_128` / `MP3_320` / `FLAC`，失败按 320K → 128K → M4A 自动降级 |
| 01-通用 | 设备GUID | 自动生成 | VKey 请求用的 10 位设备号 |
| 02-快捷键 | 显示隐藏UI | **F8** | 任意 `KeyCode` 名称 |
| 02-快捷键 | 播放暂停 / 上一首 / 下一首 | F9 / F7 / F10 | 留空 = 禁用 |
| 02-快捷键 | 系统媒体键 | true | 注册键盘媒体键 |
| 03-播放 | 音量 | 0.65 | 0~1 |
| 03-播放 | 播放模式 | Sequential | Sequential / RepeatOne / Shuffle |
| 03-播放 | 启动后自动播放 | false | |
| 03-播放 | 忽略游戏暂停 | true | `AudioSource.ignoreListenerPause` |
| 03-播放 | 启用磁盘缓存 | true | 完整播放过的歌曲落盘，下次秒开 |
| 03-播放 | 缓存上限MB | 1024 | LRU 自动清理 |
| 03-播放 | 边下边播 | true | MP3/OGG/WAV 生效 |
| 03-播放 | 预取下一首提前秒数 | 15 | 提前解析下一首 vkey |
| 04-界面 | X坐标 / Y坐标 | 60 / 140 | 相对屏幕左下角（1920×1080 参考分辨率） |
| 04-界面 | 缩放 | 1.0 | 0.6 ~ 2.0 |
| 04-界面 | 显示时透明度 | 0.94 | |
| 04-界面 | 闲置时透明度 | 0.12 | 鼠标离开后淡出的目标值，0=全隐藏 |
| 04-界面 | 淡出延迟秒数 | 4 | |
| 04-界面 | 显示歌词 | true | |
| 05-网络 | 超时秒数 / 重试次数 | 15 / 2 | 指数退避 |
| 05-网络 | 详细日志 | false | 排查接口问题时打开 |
| 06-Harmony补丁 | 启用Harmony补丁 | true | 总开关，关闭后插件完全不碰游戏代码 |
| 06-Harmony补丁 | 注入游戏UI按钮 | true | 在游戏自己的退出按钮旁克隆一个音乐按钮 |
| 06-Harmony补丁 | 播放时压低游戏BGM | true | 播放时压低 Music/AmbientBGM，暂停/停止立即恢复 |
| 06-Harmony补丁 | 压低分贝 | 8 | 3~24 dB |

UI 位置在拖动结束时会自动写回配置文件。

---

## 4.5 Harmony 补丁说明（`Patches.cs`）

两个补丁都只做「新增」或「借游戏自己的代码生效」，任何一步失败都只打日志，
悬浮窗 / 快捷键 / 媒体键照常工作。目标类通过 `AccessTools.TypeByName` 按名字解析，
游戏更新后即使改名，也只是补丁失效，不会崩游戏。

| 补丁 | 挂载点（实测于本机 2022.3.62f2） | 行为 |
| --- | --- | --- |
| 游戏内入口按钮 | `Bulbul.ExitUI.Setup()` postfix | 读私有字段 `_exitIconButton`，`Instantiate` 克隆同一个按钮（保留原生底图 / 动效 / 布局），清空其 onClick、隐藏原图标、换成音符图标，点击即显示 / 隐藏播放器。**不修改原按钮的任何状态。** |
| 播放时压低 BGM | `Bulbul.AudioMixerGroupContainer.GetDecibel(AudioMixerType)` postfix | 播放时让 `Music` / `AmbientBGM` 的返回值减去 N dB，再调用游戏自己的 `ManualUpdateAllVolume()` 重新应用。**插件从不直接操作游戏的 AudioMixer。** |

挂载点来自 `tools/TypeDump` 对 `Assembly-CSharp.dll` 的反射 dump，实测关键成员：

```
Bulbul.ExitUI                    : MonoBehaviour    -> Setup(), _exitIconButton, _lockUI
Bulbul.AudioMixerGroupContainer  : object           -> GetDecibel(AudioMixerType), ManualUpdateAllVolume()
Bulbul.AllVolumeMaster           : ScriptableObject -> GetVolume(), MusicVolume, AmbientBgmVolume ...
```

若注入的按钮位置不理想（例如父节点没有 LayoutGroup），把「注入游戏UI按钮」关掉即可，F8 依然可用。

---

## 5. 安装与使用

1. **安装 BepInEx 5.4.23.x (x64)**：解压到游戏根目录
   （`Chill With You.exe` 同级），先启动一次游戏让它生成 `BepInEx\core`。
2. 把编译好的 `ChillQQMusic.dll` 放到
   `BepInEx\plugins\ChillQQMusic\ChillQQMusic.dll`。
   或直接双击 **BepInEx 自带的 `doorstop_config.ini` 无需改动**，默认配置即可加载插件。
3. 启动游戏，听到进入游戏后：
   * 按 **F8** 显示/隐藏播放器；
   * 点右上角 **「账号」图标** 打开登录面板 → **获取二维码** → 手机 QQ 扫码；
   * 扫码失败时，从浏览器（已登录 y.qq.com）复制 Cookie 粘进输入框 → **导入 Cookie**，
     凭证会用 DPAPI 加密保存在 `BepInEx\config\ChillQQMusic\account.dat`。
4. 打开 `BepInEx\config\com.codex.chillqqmusic.cfg`，把 **歌单ID** 或 **歌单链接** 填上，
   回到游戏点 **刷新** 图标即可加载；也可以登录后点 **列表** 图标直接挑自己的歌单。
5. 拖动窗口请拖 **顶部标题栏**；鼠标移开 4 秒后自动淡出，靠近自动恢复。

### 自定义 REST API 约定（`API模式=CustomRest`）

| 方法 | 路径 | 返回 |
| --- | --- | --- |
| GET | `/ping` | 任意 200 |
| GET | `/playlist?id={id}` | `{"name":"...","songs":[{"mid","title","artist","album","cover","interval"}]}` |
| GET | `/songurl?id={mid}&quality={MP3_320}` | `{"url":"...","container":"mp3","quality":"320K","bitrate":320,"expiresInMinutes":15}` |
| GET | `/lyric?id={mid}` | `{"lyric":"[00:01.00]...","translation":"..."}` |
| GET | `/user/playlists?uin={uin}` | `[{"id","name","count"}]` |

---

## 6. 系统级媒体控制（SMTC）说明

* **进程内不可行**：`Windows.Media.Playback` / `SystemMediaTransportControls` 是 WinRT API，
  需要 `Windows.winmd` 与 `System.Runtime.WindowsRuntime` 投影，而 Unity 2022 自带的 Mono 运行时不提供，
  强行引用会在运行时 `TypeLoadException`。
* **已提供的替代**：`NativeMediaBridge.cs` 用 `RegisterHotKey` 注册键盘上的媒体键
  （播放/暂停、上一首、下一首、停止），这是纯 Win32 P/Invoke，Mono 下稳定可用。
* **若一定要系统媒体悬浮窗**：需要外挂一个独立进程（.NET 8 + `net8.0-windows10.0.19041.0` 的 WinRT 投影）
  通过本地命名管道接收曲目信息并调用 SMTC。本工程只把它列为扩展点，不在插件进程内实现。

---

## 7. 已知限制与扩展点

**已知限制**

1. 只有「自己账号有权访问」的歌单/音质才能播放，受版权与会员限制的歌曲会明确报错而非绕过。
2. m4a(AAC) 的边下边播取决于 Unity 的解码器实现，部分文件需要下载完成才开始播放（UI 会显示进度）。
3. Seek 在流式播放时只能跳到已缓冲区间（代码会自动夹紧到缓冲区末尾前 3 秒）。
4. 扫码登录依赖腾讯登录页结构，若官方改版可能失效 → 用手动 Cookie 兜底。
5. 歌词面板是简易 3 行样式，没有做逐字（QRC）与滚动动画。
6. 同一时间只维持一个 AudioSource，因此不支持交叉淡入淡出（切歌是 180ms 淡出 + 250ms 淡入）。

**后续可扩展**

* 把 `IQQMusicService` 接到自建聚合服务，彻底摆脱官方接口波动；
* 用 QRC 歌词做逐字高亮；
* 歌单搜索、收藏、添加到「我喜欢」（接口都在 `musicu.fcg` 同一体系内）；
* 音频可视化（用 `AudioSource.GetSpectrumData` 驱动黑胶外圈的律动光环）；
* 外挂 SMTC 辅助进程，让 Windows 音量面板显示曲目信息；
* 用 Harmony 补丁在游戏 UI 上加一个原生风格的入口按钮（当前刻意零补丁）。

---

## 8. 需要你补充/确认的信息

> **开发/测试约定**：调试期间如果需要重启游戏，先告知用户，由用户手动关闭游戏后再继续，
> 不要由工具/脚本直接结束游戏进程。`install-bepinex.ps1`、`build.ps1` 都只写文件，不会动进程。

| 占位符 | 当前取值 | 你需要做什么 |
| --- | --- | --- |
| `{{GAME_VERSION}}` | **2022.3.62f2**（已从 `globalgamemanagers` 读出） | 游戏更新后重新确认 |
| `{{BEPINEX_VERSION}}` | 建议 **5.4.23.3 x64 (Mono)** | 装好后如版本不同告知我，我调整引用路径 |
| `{{QQ_PLAYLIST_ID_OR_URL}}` | **9697794311** | 已在线校验：歌单「chang」，492 首，作者「转啊转」；已写入默认值 |
| 用户 UID | **GQ7L16LGB** | 已在线校验：`y.qq.com/n/ryqq/profile?uid=GQ7L16LGB` 有效；已写入默认值，解析成数字 uin 需登录态 |
| `{{QQ_MUSIC_API_BASE_OR_PROJECT}}` | 默认直连官方 Web 接口（无需第三方服务） | 若要换成自建服务，告我 base URL 与字段约定 |
| `{{HOTKEY_TOGGLE_UI}}` | **F8** | 若与游戏按键冲突就改；默认音质 = **320K** |

另外如果你想让我把 UI 调得更贴近游戏原生风格，告诉我游戏里你最喜欢的那个界面截图或大致色号即可。

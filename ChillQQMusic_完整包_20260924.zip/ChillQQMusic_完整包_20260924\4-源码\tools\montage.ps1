# Tile every PNG in a folder into one contact sheet on a dark background.
param(
    [Parameter(Mandatory=$true)][string]$Dir,
    [Parameter(Mandatory=$true)][string]$Out,
    [string]$Filter = "*.png",
    [int]$Scale = 6,
    [int]$Columns = 7
)

Add-Type -AssemblyName System.Drawing

$files = Get-ChildItem -Path $Dir -Filter $Filter | Sort-Object Name
if ($files.Count -eq 0) { throw "no files in $Dir matching $Filter" }

$first = [System.Drawing.Image]::FromFile($files[0].FullName)
$cw = $first.Width * $Scale
$ch = $first.Height * $Scale
$first.Dispose()

$rows = [Math]::Ceiling($files.Count / [double]$Columns)
$sheet = New-Object System.Drawing.Bitmap(($cw * $Columns), ($ch * $rows))
$g = [System.Drawing.Graphics]::FromImage($sheet)
$g.Clear([System.Drawing.Color]::FromArgb(255, 40, 40, 64))

$i = 0
foreach ($f in $files) {
    $img = [System.Drawing.Image]::FromFile($f.FullName)
    $col = $i % $Columns
    $row = [Math]::Floor($i / $Columns)
    $g.DrawImage($img, ($col * $cw), ($row * $ch), $cw, $ch)
    $img.Dispose()
    $i++
}

$g.Dispose()
$sheet.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$sheet.Dispose()
Write-Output "saved $Out ($($cw * $Columns)x$($ch * $rows)) from $($files.Count) files"

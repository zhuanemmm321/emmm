using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace ChillQQMusic
{
    /// <summary>
    /// Harmony 补丁（全部可选、全部 try/catch 兜底）：
    ///
    /// 1) Bulbul.ExitUI.Setup() 后置补丁
    ///    → 克隆游戏自己的退出按钮（保留原生底图/动效/布局），在旁边加一个音乐按钮。
    ///      只做「新增子物体」，不修改原按钮的任何状态，删掉插件即恢复原样。
    ///
    /// 2) Bulbul.AudioMixerGroupContainer.GetDecibel(AudioMixerType) 后置补丁
    ///    → 播放我们的音乐时，把 Music / AmbientBGM 的 dB 压低若干；暂停/停止立刻恢复。
    ///      压低值是"返回给游戏自己的代码"的，游戏照常用自己的 UpdateVolume 应用到 AudioMixer，
    ///      我们从不直接操作游戏的 AudioMixer。
    ///
    /// 之所以用 AccessTools.TypeByName 而不是直接引用 Assembly-CSharp：
    /// 游戏更新后类名/字段名即使变化，也只是补丁失效并打日志，插件本体照常工作。
    /// </summary>
    internal static class Patches
    {
        private const string EntryButtonName = "ChillQQMusicEntryButton";

        private static Harmony _harmony;
        private static bool _initialized;

        private static object _mixerContainer;                 // Bulbul.AudioMixerGroupContainer 实例
        private static MethodInfo _manualUpdateAllVolume;      // ManualUpdateAllVolume()
        private static bool _ducking;                          // 当前是否压低游戏 BGM
        private static float _duckDecibels = 8f;

        internal static bool EntryButtonInjected { get; private set; }
        internal static bool DuckingPatched { get; private set; }
        internal static bool DuckingActive => _ducking;

        internal static void Apply(ConfigManager settings)
        {
            if (_initialized) return;
            _initialized = true;

            if (!settings.EnableHarmonyPatches.Value)
            {
                Plugin.Log?.LogInfo("Harmony 补丁已关闭（配置项 06-Harmony补丁/启用Harmony补丁）。");
                return;
            }

            _duckDecibels = Mathf.Clamp(settings.DuckDecibels.Value, 0f, 30f);

            try
            {
                _harmony = new Harmony(Plugin.PluginGuid);

                var patched = 0;
                if (settings.InjectGameUiButton.Value && PatchExitUi()) patched++;
                if (settings.DuckGameBgm.Value && PatchVolumeDucking()) patched++;

                Plugin.Log?.LogInfo("Harmony 补丁应用完成，共 " + patched + " 处"
                    + (patched == 0 ? "（未匹配到目标类，可能是游戏版本更新，插件其余功能不受影响）" : "。"));
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("应用 Harmony 补丁失败（插件继续运行）: " + e);
            }
        }

        internal static void Unapply()
        {
            try { _harmony?.UnpatchSelf(); }
            catch (Exception e) { Plugin.Log?.LogDebug("卸载 Harmony 补丁失败: " + e.Message); }
            _harmony = null;
            _mixerContainer = null;
            _ducking = false;
        }

        // ------------------------------------------------------------------ 1) 游戏 UI 入口按钮

        private static bool PatchExitUi()
        {
            var type = AccessTools.TypeByName("Bulbul.ExitUI");
            if (type == null)
            {
                Plugin.Log?.LogWarning("未找到 Bulbul.ExitUI，跳过 UI 按钮注入。");
                return false;
            }

            // Setup() 只在打开对应界面时才被调用；同时挂 Awake/Start，
            // 任何一个人先跑都会注入（注入逻辑本身是幂等的）。
            var patchedAny = false;
            var postfix = new HarmonyMethod(AccessTools.Method(typeof(Patches), nameof(ExitUiSetupPostfix)));

            foreach (var name in new[] { "Setup", "Awake", "Start" })
            {
                var method = AccessTools.Method(type, name);
                if (method == null) continue;
                try
                {
                    _harmony.Patch(method, postfix: postfix);
                    Plugin.Log?.LogInfo("已挂钩 Bulbul.ExitUI." + name + "()");
                    patchedAny = true;
                }
                catch (Exception e)
                {
                    Plugin.Log?.LogWarning("挂钩 Bulbul.ExitUI." + name + "() 失败: " + e.Message);
                }
            }

            if (!patchedAny) Plugin.Log?.LogWarning("ExitUI 上没找到 Setup/Awake/Start，跳过 UI 按钮注入。");
            return patchedAny;
        }

        private static void ExitUiSetupPostfix(object __instance)
        {
            try
            {
                InjectEntryButton(__instance);
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("注入音乐入口按钮失败: " + e.Message);
            }
        }

        private static void InjectEntryButton(object exitUi)
        {
            if (exitUi == null) return;

            var button = ResolveTemplateButton(exitUi);
            if (button == null)
            {
                Plugin.Log?.LogDebug("ExitUI 里没有可用于克隆的按钮，跳过注入。");
                return;
            }

            var parent = button.transform.parent;
            if (parent == null) return;
            if (parent.Find(EntryButtonName) != null)
            {
                EntryButtonInjected = true;
                return;   // 幂等：已经注入过
            }

            var clone = UnityEngine.Object.Instantiate(button.gameObject, parent);
            clone.name = EntryButtonName;
            clone.SetActive(true);

            // 视觉区分：用户反馈过"点不到退出按钮"——克隆体和原版太像了，
            // 把根节点底色换成暖黄，和原版按钮明显不同。
            var rootBackground = clone.GetComponent<Image>();
            if (rootBackground != null) rootBackground.color = new Color(1f, 0.92f, 0.76f, 1f);
            clone.SetActive(true);

            // 1. 清掉克隆体的点击回调，换成我们自己的
            var cloneButton = clone.GetComponent<Button>();
            if (cloneButton != null)
            {
                cloneButton.onClick.RemoveAllListeners();
                cloneButton.onClick.AddListener(() =>
                {
                    if (Plugin.UI != null) Plugin.UI.ToggleVisible();
                });
            }

            // 2. 隐藏原按钮的图标子物体（保留按钮底板 / 布局 / 动效组件）
            var iconGraphics = clone.GetComponentsInChildren<Graphic>(true)
                .Where(g => g.gameObject != clone)
                .ToArray();

            foreach (var graphic in iconGraphics) graphic.enabled = false;

            // 极端情况：图标就画在按钮根节点的 Image 上（没有子物体）。
            // 这时直接复用根节点图形当图标，避免出现"退出图标 + 音符"叠在一起。
            var reuseRootGraphic = iconGraphics.Length == 0;
            if (reuseRootGraphic)
            {
                var rootImage = clone.GetComponent<Image>();
                if (rootImage != null)
                {
                    rootImage.sprite = LoFiTheme.Icon(LofiIcon.Music);
                    rootImage.color = LoFiTheme.Ink;
                    Plugin.Log?.LogDebug("入口按钮没有图标子物体，已直接替换根节点贴图。");
                }
            }

            // 3. 放上我们自己的音符图标
            if (!reuseRootGraphic)
            {
                var iconGo = new GameObject("Icon", typeof(RectTransform), typeof(Image));
                iconGo.transform.SetParent(clone.transform, false);
                var iconRect = iconGo.GetComponent<RectTransform>();
                iconRect.anchorMin = new Vector2(0.5f, 0.5f);
                iconRect.anchorMax = new Vector2(0.5f, 0.5f);
                iconRect.pivot = new Vector2(0.5f, 0.5f);
                iconRect.anchoredPosition = Vector2.zero;
                iconRect.sizeDelta = new Vector2(26f, 26f);

                var iconImage = iconGo.GetComponent<Image>();
                iconImage.sprite = LoFiTheme.Icon(LofiIcon.Music);
                iconImage.color = LoFiTheme.Ink;
                iconImage.raycastTarget = false;
            }

            EntryButtonInjected = true;
            Plugin.Log?.LogInfo("已在游戏 UI 注入音乐入口按钮（父节点: " + parent.name + "）。");
        }

        /// <summary>优先用 ExitUI._exitIconButton 当模板，找不到就退化为搜索子按钮。</summary>
        private static Button ResolveTemplateButton(object exitUi)
        {
            var type = exitUi.GetType();
            var field = AccessTools.Field(type, "_exitIconButton");
            var button = field?.GetValue(exitUi) as Button;
            if (button != null) return button;

            var component = exitUi as Component;
            if (component != null)
            {
                var buttons = component.GetComponentsInChildren<Button>(true);
                if (buttons != null && buttons.Length > 0) return buttons[0];
            }
            return null;
        }

        // ------------------------------------------------------------------ 2) 播放时压低游戏 BGM

        private static bool PatchVolumeDucking()
        {
            var type = AccessTools.TypeByName("Bulbul.AudioMixerGroupContainer");
            if (type == null)
            {
                Plugin.Log?.LogWarning("未找到 Bulbul.AudioMixerGroupContainer，跳过 BGM 压低。");
                return false;
            }

            var getDecibel = AccessTools.Method(type, "GetDecibel");
            _manualUpdateAllVolume = AccessTools.Method(type, "ManualUpdateAllVolume");

            if (getDecibel == null || _manualUpdateAllVolume == null)
            {
                Plugin.Log?.LogWarning("未找到 GetDecibel / ManualUpdateAllVolume，跳过 BGM 压低。");
                return false;
            }

            var postfix = AccessTools.Method(typeof(Patches), nameof(GetDecibelPostfix));
            _harmony.Patch(getDecibel, postfix: new HarmonyMethod(postfix));
            return true;
        }

        private static void GetDecibelPostfix(object __instance, object[] __args, ref float __result)
        {
            try
            {
                if (__instance != null && _mixerContainer == null)
                    _mixerContainer = __instance;             // 顺手抓住容器实例，供之后刷新用

                if (!_ducking || _duckDecibels <= 0f) return;
                if (__args == null || __args.Length == 0) return;

                var kind = __args[0]?.ToString() ?? string.Empty;
                if (kind.Equals("Music", StringComparison.OrdinalIgnoreCase)
                    || kind.Equals("AmbientBGM", StringComparison.OrdinalIgnoreCase)
                    || kind.Equals("AmbientBgm", StringComparison.OrdinalIgnoreCase))
                {
                    __result -= _duckDecibels;
                }
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("压低音量补丁异常: " + e.Message);
            }
        }

        /// <summary>播放/暂停/停止时调用；active=true 表示压低游戏 BGM。</summary>
        internal static void SetDucking(bool active)
        {
            if (_ducking == active) return;
            _ducking = active;
            DuckingPatched = true;
            RefreshVolumes();
        }

        /// <summary>让游戏用自己的代码重新计算一遍音量（补丁会在里面生效）。</summary>
        private static void RefreshVolumes()
        {
            var container = _mixerContainer;
            var method = _manualUpdateAllVolume;
            if (container == null || method == null) return;

            try { method.Invoke(container, null); }
            catch (Exception e) { Plugin.Log?.LogDebug("刷新音量失败: " + e.Message); }
        }

        /// <summary>配置里改了分贝数时立即生效。</summary>
        internal static void UpdateDuckDecibels(float value)
        {
            _duckDecibels = Mathf.Clamp(value, 0f, 30f);
            if (_ducking) RefreshVolumes();
        }
    }
}

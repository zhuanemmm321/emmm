using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ChillQQMusic
{
    /// <summary>
    /// QQ 音乐数据源抽象。想换 API（自建聚合服务、其他非官方实现）只需要再写一个实现类。
    /// 所有方法都在后台线程调用，实现内部不要触碰任何 Unity API。
    /// </summary>
    public interface IQQMusicService : IDisposable
    {
        string DisplayName { get; }

        /// <summary>注入 Cookie 头（登录后调用）。</summary>
        void ApplyCookies(string cookieHeader);

        /// <summary>导出当前 Cookie 头，用于加密持久化。</summary>
        string ExportCookieHeader();

        Task<PlaylistInfo> GetPlaylistAsync(string playlistIdOrUrl, CancellationToken ct);

        Task<SongUrl> GetSongUrlAsync(SongInfo song, AudioQuality quality, CancellationToken ct);

        Task<Lyrics> GetLyricsAsync(SongInfo song, CancellationToken ct);

        Task<IReadOnlyList<PlaylistSummary>> GetUserPlaylistsAsync(string uin, CancellationToken ct);

        /// <summary>连通性自检，UI 刷新按钮会用到。</summary>
        Task<bool> PingAsync(CancellationToken ct);
    }

    internal static class QualityMap
    {
        internal static string FileName(AudioQuality quality, string mid)
        {
            switch (quality)
            {
                case AudioQuality.FLAC: return "F000" + mid + ".flac";
                case AudioQuality.MP3_320: return "M800" + mid + ".mp3";
                case AudioQuality.MP3_128: return "M500" + mid + ".mp3";
                default: return "C400" + mid + ".m4a";
            }
        }

        internal static string Container(AudioQuality quality)
        {
            switch (quality)
            {
                case AudioQuality.FLAC: return "flac";
                case AudioQuality.M4A_128: return "m4a";
                default: return "mp3";
            }
        }

        internal static string Label(AudioQuality quality)
        {
            switch (quality)
            {
                case AudioQuality.FLAC: return "FLAC";
                case AudioQuality.MP3_320: return "320K";
                case AudioQuality.MP3_128: return "128K";
                default: return "M4A";
            }
        }

        internal static int Bitrate(AudioQuality quality)
        {
            switch (quality)
            {
                case AudioQuality.FLAC: return 1000;
                case AudioQuality.MP3_320: return 320;
                case AudioQuality.MP3_128: return 128;
                default: return 96;
            }
        }

        /// <summary>降级顺序：请求音质 → 更低的可用音质。</summary>
        internal static IEnumerable<AudioQuality> FallbackChain(AudioQuality requested)
        {
            yield return requested;
            if (requested == AudioQuality.FLAC) yield return AudioQuality.MP3_320;
            if (requested != AudioQuality.MP3_128 && requested != AudioQuality.M4A_128) yield return AudioQuality.MP3_128;
            if (requested != AudioQuality.M4A_128) yield return AudioQuality.M4A_128;
        }
    }

    internal static class QQMusicServiceFactory
    {
        internal static IQQMusicService Create(ConfigManager settings)
        {
            if (settings.ApiMode.Value == ApiMode.CustomRest)
            {
                Plugin.Log?.LogInfo("使用自定义 REST API: " + settings.ApiBaseUrl.Value);
                return new CustomRestMusicService(settings);
            }
            return new DirectQqWebMusicService(settings);
        }
    }

    // =====================================================================================
    //  实现一：直连 QQ 音乐 Web 接口
    // =====================================================================================
    public sealed class DirectQqWebMusicService : IQQMusicService
    {
        private const string Musicu = "https://u.y.qq.com/cgi-bin/musicu.fcg";
        private const string DissUrl = "https://c.y.qq.com/qzone/fcg-bin/fcg_ucc_getcdinfo_byids_cp.fcg";
        private const string LyricUrl = "https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg";
        private const string UserDissUrl = "https://c.y.qq.com/rsc/fcgi-bin/fcg_user_created_diss";

        private static readonly Regex ShareCodeRegex =
            new Regex(@"(?:__=|uid=|code=)([A-Za-z0-9_\-]{5,24})", RegexOptions.Compiled);
        private static readonly Regex BareCodeRegex =
            new Regex(@"^[A-Za-z0-9_\-]{6,24}$", RegexOptions.Compiled);
        private static readonly Regex IdInTextRegex =
            new Regex(@"(?:disstid|id|playlist|taoge)[=/]([0-9]{5,})", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        private static readonly Regex LongDigitsRegex = new Regex(@"\b[0-9]{6,}\b", RegexOptions.Compiled);

        private readonly ConfigManager _settings;

        public DirectQqWebMusicService(ConfigManager settings)
        {
            _settings = settings;
        }

        public string DisplayName => "QQ音乐官方Web接口";

        public void ApplyCookies(string cookieHeader) => QQHttp.ApplyCookieHeader(cookieHeader);

        public string ExportCookieHeader() => QQHttp.BuildCookieHeader();

        public void Dispose() { }

        /// <summary>
        /// QQ 的 uin cookie 形如 o0123456789，而接口请求体里必须是纯数字 uin。
        /// 之前没做这层剥离，会导致登录后 vkey 请求仍然被判为匿名。
        /// </summary>
        private string Uin
        {
            get
            {
                var raw = CookieValue("uin") ?? "0";
                raw = raw.Trim().TrimStart('o', 'O');
                return raw.All(char.IsDigit) && raw.Length > 0 ? raw : "0";
            }
        }

        private static string CookieValue(string name)
        {
            try
            {
                foreach (var uri in new[] { "https://y.qq.com/", "https://u.y.qq.com/" })
                {
                    var c = QQHttp.Cookies.GetCookies(new Uri(uri))[name];
                    if (c != null && !string.IsNullOrEmpty(c.Value)) return c.Value;
                }
            }
            catch { /* 忽略 */ }
            return null;
        }

        public async Task<bool> PingAsync(CancellationToken ct)
        {
            var text = await QQHttp.GetStringAsync(Musicu + "?format=json&data=%7B%7D", ct).ConfigureAwait(false);
            return !string.IsNullOrEmpty(text);
        }

        // ------------------------- 歌单 -------------------------

        public async Task<PlaylistInfo> GetPlaylistAsync(string playlistIdOrUrl, CancellationToken ct)
        {
            var id = PlaylistManager.ExtractPlaylistId(playlistIdOrUrl);
            if (string.IsNullOrEmpty(id))
            {
                // 输入可能是分享短码（如 GQ7L16LGB）而不是数字 ID：尝试跟随分享页跳转解析。
                id = await TryResolveShareCodeAsync(playlistIdOrUrl, ct).ConfigureAwait(false);
            }
            if (string.IsNullOrEmpty(id))
            {
                throw new QQMusicException("无法从「" + Shorten(playlistIdOrUrl) + "」解析出歌单 ID。"
                    + "请粘贴完整的歌单分享链接，或直接填纯数字歌单 ID（例如 9697794311）。");
            }

            try
            {
                var info = await GetPlaylistByMusicuAsync(id, ct).ConfigureAwait(false);
                if (info.Songs.Count > 0) return info;
                Plugin.Log?.LogWarning("musicu 歌单接口返回 0 首，尝试旧接口。");
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("musicu 歌单接口失败，尝试旧接口: " + e.Message);
            }

            return await GetPlaylistByLegacyAsync(id, ct).ConfigureAwait(false);
        }

        /// <summary>把分享短码解析成数字歌单 ID：跟随分享页跳转，再从最终 URL / HTML 里抓数字 ID。</summary>
        private async Task<string> TryResolveShareCodeAsync(string input, CancellationToken ct)
        {
            var code = ExtractShareCode(input);
            if (string.IsNullOrEmpty(code)) return null;

            var candidates = new[]
            {
                "https://i.y.qq.com/n2/m/share/details/taoge.html?uid=" + Uri.EscapeDataString(code),
                "https://c6.y.qq.com/base/fcgi-bin/u?__=" + Uri.EscapeDataString(code),
                "https://y.qq.com/n/ryqq/profile?uid=" + Uri.EscapeDataString(code)
            };

            foreach (var url in candidates)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    using (var response = await QQHttp.SendAsync(
                               () => new HttpRequestMessage(HttpMethod.Get, url), ct).ConfigureAwait(false))
                    {
                        var finalUrl = response.RequestMessage?.RequestUri?.ToString() ?? url;
                        var hit = FirstIdIn(finalUrl);
                        if (string.IsNullOrEmpty(hit))
                        {
                            var body = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                            hit = FirstIdIn(body);
                        }

                        if (!string.IsNullOrEmpty(hit))
                        {
                            Plugin.Log?.LogInfo("分享短码 " + code + " 解析为歌单 ID " + hit + "（来源 " + finalUrl + "）");
                            return hit;
                        }
                    }
                }
                catch (Exception e)
                {
                    Plugin.Log?.LogDebug("短码解析失败(" + url + "): " + e.Message);
                }
            }

            Plugin.Log?.LogWarning("分享短码 " + code + " 未能解析出数字歌单 ID。");
            return null;
        }

        private static string ExtractShareCode(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return null;
            var match = ShareCodeRegex.Match(input);
            if (match.Success) return match.Groups[1].Value;
            var trimmed = input.Trim();
            return BareCodeRegex.IsMatch(trimmed) ? trimmed : null;
        }

        private static string FirstIdIn(string text)
        {
            if (string.IsNullOrEmpty(text)) return null;
            var match = IdInTextRegex.Match(text);
            if (match.Success) return match.Groups[1].Value;
            var loose = LongDigitsRegex.Match(text);
            return loose.Success ? loose.Value : null;
        }

        private static string Shorten(string text) =>
            string.IsNullOrEmpty(text) ? "" : (text.Length > 60 ? text.Substring(0, 60) + "…" : text);

        private async Task<PlaylistInfo> GetPlaylistByMusicuAsync(string id, CancellationToken ct)
        {
            var payload = new JObject
            {
                ["comm"] = new JObject
                {
                    ["ct"] = 24, ["cv"] = 0, ["format"] = "json",
                    ["uin"] = Uin, ["platform"] = "yqq.json", ["needNewCode"] = 0
                },
                ["req_0"] = new JObject
                {
                    ["module"] = "music.srfDissInfo.aiDissInfo",
                    ["method"] = "uniform_get_Dissinfo",
                    ["param"] = new JObject
                    {
                        ["disstid"] = long.TryParse(id, out var did) ? did : 0,
                        ["enc_host_uin"] = "",
                        ["tag"] = 1,
                        ["userinfo"] = 1,
                        ["song_begin"] = 0,
                        ["song_num"] = 1000,
                        ["order"] = 1
                    }
                }
            };

            var json = await QQHttp.PostJsonAsync(Musicu, payload.ToString(Formatting.None), ct).ConfigureAwait(false);
            var root = JObject.Parse(json);
            var data = root["req_0"]?["data"];

            var code = (int?)data?["code"] ?? (int?)root["req_0"]?["code"] ?? 0;
            if (data == null || code != 0)
            {
                var message = (string)data?["msg"] ?? (string)data?["message"] ?? (string)root["req_0"]?["msg"];
                throw new QQMusicException("歌单接口返回 code=" + code
                    + (string.IsNullOrEmpty(message) ? "（无错误信息）" : "：" + message));
            }

            var playlist = new PlaylistInfo
            {
                Id = id,
                Name = (string)(data["dirinfo"]?["title"] ?? data["dirinfo"]?["dissname"]) ?? ("歌单 " + id)
            };

            var songList = data["songlist"] as JArray;
            if (songList != null)
            {
                foreach (var token in songList)
                {
                    var song = ParseMusicuSong(token as JObject);
                    if (song != null) playlist.Songs.Add(song);
                }
            }

            return playlist;
        }

        private static SongInfo ParseMusicuSong(JObject item)
        {
            if (item == null) return null;
            var mid = (string)item["mid"];
            if (string.IsNullOrEmpty(mid)) return null;

            var albumMid = (string)(item["album"]?["mid"] ?? item["albummid"]);
            var artists = new List<string>();
            if (item["singer"] is JArray singers)
            {
                foreach (var s in singers)
                {
                    var name = (string)s["name"];
                    if (!string.IsNullOrEmpty(name)) artists.Add(name);
                }
            }
            if (artists.Count == 0 && item["singer"] is JArray singerLegacy)
            {
                foreach (var s in singerLegacy)
                {
                    var name = (string)s["name"];
                    if (!string.IsNullOrEmpty(name)) artists.Add(name);
                }
            }

            return new SongInfo
            {
                Mid = mid,
                SongId = (int?)item["id"] ?? 0,
                Title = (string)item["name"] ?? (string)item["title"] ?? mid,
                Artist = string.Join(" / ", artists),
                Album = (string)(item["album"]?["name"] ?? item["albumname"]) ?? string.Empty,
                CoverUrl = string.IsNullOrEmpty(albumMid)
                    ? string.Empty
                    : "https://y.qq.com/music/photo_new/T002R300x300M000" + albumMid + ".jpg",
                DurationSeconds = (int?)item["interval"] ?? 0,
                FileSizeBytes = (int?)item["size128"] ?? 0
            };
        }

        private async Task<PlaylistInfo> GetPlaylistByLegacyAsync(string id, CancellationToken ct)
        {
            var url = DissUrl
                + "?type=1&json=1&utf8=1&onlysong=0&new_format=1&disstid=" + Uri.EscapeDataString(id)
                + "&g_tk=5381&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8"
                + "&notice=0&platform=yqq.json&needNewCode=0";

            var json = await QQHttp.GetStringAsync(url, ct).ConfigureAwait(false);
            var root = JObject.Parse(json);
            var cd = (root["cdlist"] as JArray)?.FirstOrDefault() as JObject;
            if (cd == null)
            {
                var subcode = (int?)root["subcode"] ?? 0;
                var message = (string)root["msg"] ?? (string)root["message"] ?? string.Empty;
                if (subcode == 4000 || message.IndexOf("privacy", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    throw new QQMusicException(
                        "旧接口返回 check privacy error：这个歌单需要登录态才能读取。"
                        + "请在插件里扫码登录（或导入 Cookie）后点刷新。");
                }
                throw new QQMusicException("歌单不存在或没有访问权限（若为私人歌单请先扫码登录）。");
            }

            var playlist = new PlaylistInfo
            {
                Id = id,
                Name = (string)cd["dissname"] ?? ("歌单 " + id)
            };

            if (cd["songlist"] is JArray songs)
            {
                foreach (var token in songs)
                {
                    var song = ParseLegacySong(token as JObject);
                    if (song != null) playlist.Songs.Add(song);
                }
            }

            if (playlist.Songs.Count == 0) throw new QQMusicException("歌单解析成功，但里面没有可播放的歌曲。");
            return playlist;
        }

        private static SongInfo ParseLegacySong(JObject item)
        {
            if (item == null) return null;
            var mid = (string)item["mid"];
            if (string.IsNullOrEmpty(mid)) return null;

            var artists = new List<string>();
            if (item["singer"] is JArray singers)
            {
                foreach (var s in singers)
                {
                    var name = (string)s["name"];
                    if (!string.IsNullOrEmpty(name)) artists.Add(name);
                }
            }

            var albumMid = (string)(item["album"]?["mid"] ?? item["albummid"]);
            return new SongInfo
            {
                Mid = mid,
                SongId = (int?)item["id"] ?? (int?)item["songid"] ?? 0,
                Title = (string)item["name"] ?? (string)item["songname"] ?? mid,
                Artist = string.Join(" / ", artists),
                Album = (string)(item["album"]?["name"] ?? item["albumname"]) ?? string.Empty,
                CoverUrl = string.IsNullOrEmpty(albumMid)
                    ? string.Empty
                    : "https://y.qq.com/music/photo_new/T002R300x300M000" + albumMid + ".jpg",
                DurationSeconds = (int?)item["interval"] ?? 0
            };
        }

        // ------------------------- 播放地址 -------------------------

        public async Task<SongUrl> GetSongUrlAsync(SongInfo song, AudioQuality quality, CancellationToken ct)
        {
            if (song == null || string.IsNullOrEmpty(song.Mid)) throw new QQMusicException("歌曲信息不完整（缺少 songmid）。");

            QQMusicException lastError = null;
            foreach (var candidate in QualityMap.FallbackChain(quality).Distinct())
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    var result = await RequestVKeyAsync(song, candidate, ct).ConfigureAwait(false);
                    if (result != null) return result;
                }
                catch (QQMusicException e)
                {
                    // 登录态问题：三种音质都不可能有地址，直接抛出可操作提示。
                    if (e.LoginRequired) throw;
                    lastError = e;
                    Plugin.Log?.LogDebug("音质 " + candidate + " 不可用: " + e.Message);
                }
            }

            throw lastError ?? new QQMusicException("该歌曲暂时没有可用播放地址（可能需要会员、或受版权限制）。");
        }

        private async Task<SongUrl> RequestVKeyAsync(SongInfo song, AudioQuality quality, CancellationToken ct)
        {
            var container = QualityMap.Container(quality);
            var fileName = QualityMap.FileName(quality, song.Mid);
            var guid = _settings.DeviceGuid.Value;
            var uin = Uin;

            var payload = new JObject
            {
                ["comm"] = new JObject
                {
                    ["ct"] = 24, ["cv"] = 0, ["format"] = "json",
                    ["uin"] = uin, ["platform"] = "yqq.json", ["needNewCode"] = 0
                },
                ["req_0"] = new JObject
                {
                    ["module"] = "vkey.GetVkeyServer",
                    ["method"] = "CgiGetVkey",
                    ["param"] = new JObject
                    {
                        ["guid"] = guid,
                        ["songmid"] = new JArray(song.Mid),
                        ["songtype"] = new JArray(0),
                        ["uin"] = uin,
                        ["loginflag"] = 1,
                        ["platform"] = "20"
                    }
                },
                ["req_1"] = new JObject
                {
                    ["module"] = "music.vkey.GetVkey",
                    ["method"] = "UrlGetVkey",
                    ["param"] = new JObject
                    {
                        ["filename"] = new JArray(fileName),
                        ["guid"] = guid,
                        ["songmid"] = new JArray(song.Mid),
                        ["songtype"] = new JArray(0),
                        ["uin"] = uin,
                        ["loginflag"] = 1,
                        ["platform"] = "20"
                    }
                }
            };

            var json = await QQHttp.PostJsonAsync(Musicu, payload.ToString(Formatting.None), ct).ConfigureAwait(false);
            var root = JObject.Parse(json);

            // 优先用 req_1（我们显式指定的 filename，例如 M500xxx.mp3 / M800xxx.mp3）返回的 purl——
            // 那才是真正的 MP3 文件；req_0 按 songmid 返回的往往是 m4a（本作 Unity 解不了 AAC）。
            var purl = ExtractPurl(root["req_1"]);
            var sip = ExtractSip(root["req_1"]);
            var usedModule = "req_1(指定filename)";
            var fallbackPurl = ExtractPurl(root["req_0"]);
            var fallbackSip = ExtractSip(root["req_0"]);
            if (string.IsNullOrEmpty(purl))
            {
                purl = fallbackPurl;
                sip = sip ?? fallbackSip;
                fallbackPurl = null;
                usedModule = "req_0(按songmid)";
            }

            if (!string.IsNullOrEmpty(purl))
            {
                var returnedFileName = ExtractFilename(root["req_1"]);
                if (string.IsNullOrEmpty(returnedFileName)) returnedFileName = ExtractFilename(root["req_0"]);
                Plugin.Log?.LogInfo("取得播放地址: 来源=" + usedModule + " 返回文件名=" + (returnedFileName ?? "(未知)")
                    + " 请求文件名=" + fileName
                    + " 请求音质=" + QualityMap.Label(quality));
            }

            if (string.IsNullOrEmpty(purl))
            {
                var data = root["req_0"]?["data"];
                var retcode = (int?)data?["retcode"] ?? 0;
                var dataMessage = (string)data?["msg"] ?? string.Empty;
                var info = data?["midurlinfo"] as JArray;
                var resultCode = info != null && info.Count > 0 ? ((int?)info[0]?["result"] ?? 0) : 0;
                var tips = info != null && info.Count > 0 ? ((string)info[0]?["tips"] ?? string.Empty) : string.Empty;
                var code = resultCode != 0 ? resultCode : retcode;

                var loggedIn = QQHttp.HasLoginCookie();
                var loginHint = !loggedIn || IsLoginCode(code) || dataMessage.Contains("invalidq");

                if (loginHint)
                {
                    throw new QQMusicException(
                        "QQ 音乐没有返回播放地址（诊断码 " + code + "）。"
                        + (loggedIn
                            ? "当前登录态对该歌曲无效，可能需要会员或该歌曲受版权限制。"
                            : "当前未登录——请点悬浮窗右上角「账号」扫码登录后再点播放。"))
                    {
                        LoginRequired = !loggedIn
                    };
                }

                throw new QQMusicException(
                    QualityMap.Label(quality) + " 无可用地址（诊断码 " + code + "）"
                    + (string.IsNullOrEmpty(tips) ? string.Empty : "：" + tips));
            }

            var url = purl.StartsWith("http", StringComparison.OrdinalIgnoreCase)
                ? purl
                : (sip ?? "https://dl.stream.qqmusic.qq.com/") + purl;

            // Unity 2020+ 默认禁止 http:// 明文连接（InvalidOperationException: Insecure connection not allowed），
            // 而 QQ 返回的 sip 常是 http://aqqmusic.tc.qq.com/...。
            // 腾讯这些 CDN 都支持 https，且 vkey 与协议无关，这里统一升级为 https。
            url = ForceHttps(url);

            // 备用地址：我们指定的 MP3 有时在 CDN 上不存在（404），
            // 而接口按 songmid 给的地址（通常是 m4a）是有效的，交给上层依次尝试。
            var fallbackUrl = string.Empty;
            if (!string.IsNullOrEmpty(fallbackPurl))
            {
                fallbackUrl = fallbackPurl.StartsWith("http", StringComparison.OrdinalIgnoreCase)
                    ? fallbackPurl
                    : (fallbackSip ?? "https://dl.stream.qqmusic.qq.com/") + fallbackPurl;
                fallbackUrl = ForceHttps(fallbackUrl);
                if (fallbackUrl == url) fallbackUrl = string.Empty;
            }

            return new SongUrl
            {
                Url = url,
                FallbackUrl = fallbackUrl,
                Container = container,
                QualityLabel = QualityMap.Label(quality),
                BitrateKbps = QualityMap.Bitrate(quality),
                RequestedQuality = quality,
                ExpireAt = DateTime.Now.AddMinutes(15)   // vkey 有效期约 20 分钟，保守取 15 分钟
            };
        }

        /// <summary>把 http:// 升级为 https://（Unity 不允许明文连接）。</summary>
        internal static string ForceHttps(string url)
        {
            if (string.IsNullOrEmpty(url)) return url;
            if (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase))
                return "https://" + url.Substring("http://".Length);
            return url;
        }

        private static string ExtractPurl(JToken module)
        {
            var info = module?["data"]?["midurlinfo"] as JArray;
            if (info == null || info.Count == 0) return null;
            var purl = (string)info[0]?["purl"];
            return string.IsNullOrWhiteSpace(purl) ? null : purl.Trim();
        }

        /// <summary>QQ 音乐表示"登录态无效 / 无权限"的常见返回码。</summary>
        private static bool IsLoginCode(int code) =>
            code == 1000 || code == 104003 || code == 104009 || code == 104010
            || code == 104011 || code == 104012 || code == 104013;

        private static string ExtractSip(JToken module)
        {
            var sip = module?["data"]?["sip"] as JArray;
            if (sip == null || sip.Count == 0) return null;
            foreach (var s in sip)
            {
                var value = (string)s;
                if (!string.IsNullOrEmpty(value)) return value.TrimEnd('/') + "/";
            }
            return null;
        }

        /// <summary>取出接口返回的文件名（形如 M500xxxx.mp3 / C400xxxx.m4a），用于确认音质与容器。</summary>
        private static string ExtractFilename(JToken module)
        {
            var info = module?["data"]?["midurlinfo"] as JArray;
            if (info == null || info.Count == 0) return null;
            var name = (string)info[0]?["filename"];
            return string.IsNullOrWhiteSpace(name) ? null : name.Trim();
        }

        // ------------------------- 歌词 -------------------------

        public async Task<Lyrics> GetLyricsAsync(SongInfo song, CancellationToken ct)
        {
            if (song == null || string.IsNullOrEmpty(song.Mid)) return new Lyrics();

            var url = LyricUrl + "?songmid=" + Uri.EscapeDataString(song.Mid)
                + "&g_tk=5381&format=json&nobase64=1&inCharset=utf8&outCharset=utf-8"
                + "&notice=0&platform=yqq.json&needNewCode=0&loginUin=0&hostUin=0";

            var text = await QQHttp.GetStringAsync(url, ct, "https://y.qq.com/portal/player.html").ConfigureAwait(false);
            text = StripJsonPadding(text);
            if (string.IsNullOrEmpty(text)) return new Lyrics();

            var root = JObject.Parse(text);
            var lyric = (string)root["lyric"] ?? string.Empty;
            var trans = (string)root["trans"] ?? string.Empty;

            // 某些情况下接口仍返回 base64
            if (root["retcode"] != null && (int?)root["retcode"] == 0 && !lyric.Contains("[") && LooksLikeBase64(lyric))
            {
                try
                {
                    lyric = Encoding.UTF8.GetString(Convert.FromBase64String(lyric));
                    if (LooksLikeBase64(trans)) trans = Encoding.UTF8.GetString(Convert.FromBase64String(trans));
                }
                catch { /* 保持原样 */ }
            }

            return LyricsParser.Parse(lyric, trans);
        }

        private static string StripJsonPadding(string text)
        {
            if (string.IsNullOrEmpty(text)) return text;
            var trimmed = text.Trim();
            var start = trimmed.IndexOf('{');
            var end = trimmed.LastIndexOf('}');
            if (start < 0 || end <= start) return null;
            return trimmed.Substring(start, end - start + 1);
        }

        private static bool LooksLikeBase64(string text)
        {
            if (string.IsNullOrEmpty(text) || text.Length < 16) return false;
            foreach (var c in text)
            {
                if (!(char.IsLetterOrDigit(c) || c == '+' || c == '/' || c == '=' || c == '\r' || c == '\n')) return false;
            }
            return true;
        }

        // ------------------------- 用户歌单 -------------------------

        public async Task<IReadOnlyList<PlaylistSummary>> GetUserPlaylistsAsync(string uin, CancellationToken ct)
        {
            uin = string.IsNullOrEmpty(uin) ? Uin : uin;

            // 传入的是主页 UID（如 GQ7L16LGB）而不是数字 uin 时，先尝试解析。
            if (!string.IsNullOrEmpty(uin) && !uin.All(char.IsDigit))
            {
                var resolvedUin = await TryResolveUidAsync(uin, ct).ConfigureAwait(false);
                if (string.IsNullOrEmpty(resolvedUin))
                {
                    throw new QQMusicException("用户UID「" + uin + "」需要登录后才能解析成数字 uin"
                        + "（匿名请求返回 500003）。请先扫码登录，或改用纯数字歌单 ID。");
                }
                Plugin.Log?.LogInfo("用户UID " + uin + " 解析为 uin " + resolvedUin);
                uin = resolvedUin;
            }

            if (string.IsNullOrEmpty(uin) || uin == "0")
                throw new QQMusicException("未登录，无法读取个人歌单。请先扫码登录。");

            var url = UserDissUrl + "?hostuin=" + Uri.EscapeDataString(uin)
                + "&sin=0&size=200&format=json&inCharset=utf8&outCharset=utf-8"
                + "&notice=0&platform=yqq.json&needNewCode=0";

            var json = await QQHttp.GetStringAsync(url, ct).ConfigureAwait(false);
            var root = JObject.Parse(json);
            var list = new List<PlaylistSummary>();

            var dissList = root["data"]?["disslist"] as JArray;
            if (dissList != null)
            {
                foreach (var item in dissList)
                {
                    var id = (string)item["dissid"] ?? (string)item["tid"];
                    if (string.IsNullOrEmpty(id)) continue;
                    list.Add(new PlaylistSummary
                    {
                        Id = id,
                        Name = (string)item["dissname"] ?? (string)item["title"] ?? id,
                        SongCount = (int?)item["songnum"] ?? (int?)item["song_cnt"] ?? 0
                    });
                }
            }

            return list;
        }

        /// <summary>尝试用主页接口把 UID 换成数字 uin（需要登录态）。</summary>
        private async Task<string> TryResolveUidAsync(string uid, CancellationToken ct)
        {
            var methods = new[] { "GetHomepageHeader", "GetHomepageBasicInfo" };
            foreach (var method in methods)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    var payload = new JObject
                    {
                        ["comm"] = new JObject
                        {
                            ["ct"] = 24, ["cv"] = 0, ["format"] = "json",
                            ["uin"] = Uin, ["platform"] = "yqq.json", ["needNewCode"] = 0
                        },
                        ["req_0"] = new JObject
                        {
                            ["module"] = "music.UnifiedHomepage.unifiedHomepageSrv",
                            ["method"] = method,
                            ["param"] = new JObject { ["uid"] = uid, ["uin"] = Uin, ["enc_user_id"] = "", ["is_from_qq_music"] = 1 }
                        }
                    };

                    var json = await QQHttp.PostJsonAsync(Musicu, payload.ToString(Formatting.None), ct).ConfigureAwait(false);
                    var root = JObject.Parse(json);
                    var code = (int?)root["req_0"]?["code"] ?? 0;
                    if (code != 0)
                    {
                        Plugin.Log?.LogDebug("主页接口 " + method + " 返回 code=" + code);
                        continue;
                    }

                    var found = FindNumericUin(root["req_0"]?["data"]);
                    if (!string.IsNullOrEmpty(found)) return found;
                }
                catch (Exception e)
                {
                    Plugin.Log?.LogDebug("解析 UID 失败(" + method + "): " + e.Message);
                }
            }
            return null;
        }

        private static string FindNumericUin(JToken token)
        {
            if (token == null) return null;
            if (token is JObject obj)
            {
                foreach (var property in obj.Properties())
                {
                    var name = property.Name.ToLowerInvariant();
                    if (name == "uin" || name == "hostuin" || name == "host_uin" || name == "useruin")
                    {
                        var value = property.Value?.ToString();
                        if (!string.IsNullOrEmpty(value) && value.All(char.IsDigit) && value.Length >= 5) return value;
                    }

                    var nested = FindNumericUin(property.Value);
                    if (!string.IsNullOrEmpty(nested)) return nested;
                }
            }
            else if (token is JArray array)
            {
                foreach (var item in array)
                {
                    var nested = FindNumericUin(item);
                    if (!string.IsNullOrEmpty(nested)) return nested;
                }
            }
            return null;
        }
    }

    // =====================================================================================
    //  实现二：自定义 REST API（约定见 README）
    // =====================================================================================
    public sealed class CustomRestMusicService : IQQMusicService
    {
        private readonly ConfigManager _settings;

        public CustomRestMusicService(ConfigManager settings) => _settings = settings;

        public string DisplayName => "自定义REST接口";

        public void ApplyCookies(string cookieHeader) => QQHttp.ApplyCookieHeader(cookieHeader);

        public string ExportCookieHeader() => QQHttp.BuildCookieHeader();

        public void Dispose() { }

        private string Base => (_settings.ApiBaseUrl.Value ?? string.Empty).TrimEnd('/');

        private HttpRequestMessage Request(string path)
        {
            var req = new HttpRequestMessage(HttpMethod.Get, Base + path);
            var token = _settings.ApiToken.Value;
            if (!string.IsNullOrEmpty(token))
                req.Headers.TryAddWithoutValidation("Authorization", "Bearer " + token);
            return req;
        }

        private async Task<JToken> GetJsonAsync(string path, CancellationToken ct)
        {
            using (var response = await QQHttp.SendAsync(() => Request(path), ct).ConfigureAwait(false))
            {
                var body = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                if (!response.IsSuccessStatusCode)
                    throw new QQMusicException("API 返回 HTTP " + (int)response.StatusCode + "：" + Trim(body));
                return JToken.Parse(body);
            }
        }

        private static string Trim(string s) =>
            string.IsNullOrEmpty(s) ? "" : (s.Length > 160 ? s.Substring(0, 160) + "..." : s);

        public async Task<bool> PingAsync(CancellationToken ct)
        {
            try
            {
                await GetJsonAsync("/ping", ct).ConfigureAwait(false);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<PlaylistInfo> GetPlaylistAsync(string playlistIdOrUrl, CancellationToken ct)
        {
            var id = PlaylistManager.ExtractPlaylistId(playlistIdOrUrl);
            if (string.IsNullOrEmpty(id)) throw new QQMusicException("歌单 ID 无效。");

            var token = await GetJsonAsync("/playlist?id=" + Uri.EscapeDataString(id), ct).ConfigureAwait(false);
            var playlist = new PlaylistInfo
            {
                Id = id,
                Name = (string)token["name"] ?? ("歌单 " + id)
            };

            var songs = (token["songs"] ?? token["data"]) as JArray;
            if (songs != null)
            {
                foreach (var item in songs)
                {
                    var mid = (string)item["mid"] ?? (string)item["id"];
                    if (string.IsNullOrEmpty(mid)) continue;
                    playlist.Songs.Add(new SongInfo
                    {
                        Mid = mid,
                        Title = (string)item["title"] ?? (string)item["name"] ?? mid,
                        Artist = (string)item["artist"] ?? (string)item["singer"] ?? string.Empty,
                        Album = (string)item["album"] ?? string.Empty,
                        CoverUrl = (string)item["cover"] ?? string.Empty,
                        DurationSeconds = (int?)item["interval"] ?? (int?)item["duration"] ?? 0
                    });
                }
            }

            if (playlist.Songs.Count == 0) throw new QQMusicException("API 没有返回任何歌曲。");
            return playlist;
        }

        public async Task<SongUrl> GetSongUrlAsync(SongInfo song, AudioQuality quality, CancellationToken ct)
        {
            var token = await GetJsonAsync("/songurl?id=" + Uri.EscapeDataString(song.Mid)
                                            + "&quality=" + quality, ct).ConfigureAwait(false);

            var url = (string)token["url"];
            if (string.IsNullOrEmpty(url)) throw new QQMusicException((string)token["message"] ?? "API 未返回播放地址。");

            var container = (string)token["container"] ?? QualityMap.Container(quality);
            return new SongUrl
            {
                Url = url,
                Container = container,
                QualityLabel = (string)token["quality"] ?? QualityMap.Label(quality),
                BitrateKbps = (int?)token["bitrate"] ?? QualityMap.Bitrate(quality),
                RequestedQuality = quality,
                ExpireAt = DateTime.Now.AddMinutes((int?)token["expiresInMinutes"] ?? 15)
            };
        }

        public async Task<Lyrics> GetLyricsAsync(SongInfo song, CancellationToken ct)
        {
            try
            {
                var token = await GetJsonAsync("/lyric?id=" + Uri.EscapeDataString(song.Mid), ct).ConfigureAwait(false);
                return LyricsParser.Parse((string)token["lyric"] ?? string.Empty, (string)token["translation"] ?? string.Empty);
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("获取歌词失败: " + e.Message);
                return new Lyrics();
            }
        }

        public async Task<IReadOnlyList<PlaylistSummary>> GetUserPlaylistsAsync(string uin, CancellationToken ct)
        {
            var token = await GetJsonAsync("/user/playlists?uin=" + Uri.EscapeDataString(uin ?? ""), ct).ConfigureAwait(false);
            var list = new List<PlaylistSummary>();
            var arr = (token["list"] ?? token) as JArray;
            if (arr != null)
            {
                foreach (var item in arr)
                {
                    var id = (string)item["id"];
                    if (string.IsNullOrEmpty(id)) continue;
                    list.Add(new PlaylistSummary
                    {
                        Id = id,
                        Name = (string)item["name"] ?? id,
                        SongCount = (int?)item["count"] ?? 0
                    });
                }
            }
            return list;
        }
    }
}

<#
  One-shot BepInEx 5.4.23.3 (x64, Mono) installer for "Chill with You: Lo-Fi Story".

  Usage:
    # dry run: only report current state, change nothing
    powershell -ExecutionPolicy Bypass -File .\install-bepinex.ps1 -Check

    # install (keeps an existing doorstop_config.ini unless -Force)
    powershell -ExecutionPolicy Bypass -File .\install-bepinex.ps1

    # install from another zip / another game folder
    powershell -ExecutionPolicy Bypass -File .\install-bepinex.ps1 -ZipPath D:\Downloads\BepInEx_win_x64_5.4.23.3.zip

  Uninstall: delete these four items from the game folder (they are all that BepInEx adds):
    winhttp.dll   doorstop_config.ini   .doorstop_version   BepInEx\
  Note: BepInEx\ also holds every other mod's config, logs and cache.

  Keep this file ASCII-only: Windows PowerShell 5.1 reads BOM-less .ps1 as ANSI.
#>
param(
    [string]$GameDir = 'D:\SteamLibrary\steamapps\common\Chill with You Lo-Fi Story',
    [string]$ZipPath = (Join-Path $PSScriptRoot 'tools\bepinex\BepInEx_win_x64_5.4.23.3.zip'),
    [string]$ExpectedSha256 = '41A089E5B1B1F0713B331346BAF6677B1184C69EABEBF51101097954E854C749',
    [switch]$Force,
    [switch]$Check
)

$ErrorActionPreference = 'Stop'

function Write-Step($text) { Write-Host "  $text" }
function Write-Ok($text)   { Write-Host "  [OK]   $text" -ForegroundColor Green }
function Write-Warn2($text){ Write-Host "  [WARN] $text" -ForegroundColor Yellow }
function Write-Bad($text)  { Write-Host "  [FAIL] $text" -ForegroundColor Red }

$gameExe = Join-Path $GameDir 'Chill With You.exe'
$expected = @(
    'winhttp.dll',
    'doorstop_config.ini',
    '.doorstop_version',
    'BepInEx\core\BepInEx.dll',
    'BepInEx\core\0Harmony.dll',
    'BepInEx\core\BepInEx.Preloader.dll',
    'BepInEx\plugins',
    'BepInEx\config'
)

Write-Host ''
Write-Host '=== BepInEx 5.4.23.3 (x64 Mono) installer ===' -ForegroundColor Cyan
Write-Host "game   : $GameDir"
Write-Host "zip    : $ZipPath"
Write-Host "mode   : $(if ($Check) { 'CHECK ONLY (no changes)' } else { 'INSTALL' })"
Write-Host ''

# ---------------------------------------------------------------- 1. sanity checks
Write-Host '[1/4] Environment' -ForegroundColor Cyan
if (-not (Test-Path $gameExe)) { Write-Bad "game not found: $gameExe"; exit 1 }
Write-Ok "found game exe"

$managed = Join-Path $GameDir 'Chill With You_Data\Managed\Assembly-CSharp.dll'
if (Test-Path $managed) { Write-Ok 'Mono runtime confirmed (Assembly-CSharp.dll exists) -> x64 Mono build is correct' }
else { Write-Warn2 'Assembly-CSharp.dll not found; this game may be IL2CPP (you would need BepInEx 6 instead)' }

if (Test-Path (Join-Path $GameDir 'GameAssembly.dll')) { Write-Warn2 'GameAssembly.dll found -> IL2CPP game, BepInEx 5 will NOT work' }

# ---------------------------------------------------------------- 2. current state
Write-Host ''
Write-Host '[2/4] Current state' -ForegroundColor Cyan
$present = 0
foreach ($rel in $expected) {
    $full = Join-Path $GameDir $rel
    if (Test-Path $full) { $present++; Write-Ok $rel } else { Write-Step "(missing) $rel" }
}
if ($present -eq $expected.Count) { Write-Ok 'BepInEx already looks installed.' }
elseif ($present -gt 0) { Write-Warn2 "partial install detected ($present/$($expected.Count) items)" }
else { Write-Step 'clean folder: BepInEx is not installed yet' }

if ($Check) {
    Write-Host ''
    Write-Host 'Check finished. Re-run without -Check to install.' -ForegroundColor Cyan
    exit 0
}

# ---------------------------------------------------------------- 3. extract
Write-Host ''
Write-Host '[3/4] Extracting' -ForegroundColor Cyan
if (-not (Test-Path $ZipPath)) { Write-Bad "zip not found: $ZipPath"; exit 2 }

$hash = (Get-FileHash $ZipPath -Algorithm SHA256).Hash
Write-Step "sha256 = $hash"
if ($ExpectedSha256 -and ($hash -ne $ExpectedSha256)) {
    Write-Warn2 'hash differs from the verified copy. If you downloaded it yourself on purpose, pass -ExpectedSha256 "" to skip.'
}
else { Write-Ok 'sha256 matches the verified package' }

Add-Type -AssemblyName System.IO.Compression.FileSystem

$tempRoot = [IO.Path]::GetTempPath().TrimEnd('\')
$tempDir = Join-Path $tempRoot ('bepinex_install_' + [Guid]::NewGuid().ToString('N'))
[IO.Compression.ZipFile]::ExtractToDirectory($ZipPath, $tempDir)
Write-Ok "extracted to temp: $tempDir"

$copied = 0
$skipped = 0
$rootLen = $tempDir.Length + 1
foreach ($file in Get-ChildItem $tempDir -Recurse -File) {
    $rel = $file.FullName.Substring($rootLen)
    $dest = Join-Path $GameDir $rel

    # keep the user's existing doorstop settings unless -Force
    if (-not $Force -and $rel -ieq 'doorstop_config.ini' -and (Test-Path $dest)) {
        Write-Step "kept existing $rel (use -Force to overwrite)"
        $skipped++
        continue
    }

    $destDir = Split-Path -Parent $dest
    if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Force -Path $destDir | Out-Null }
    Copy-Item $file.FullName $dest -Force
    $copied++
}

foreach ($dir in @('BepInEx\plugins', 'BepInEx\config', 'BepInEx\cache')) {
    $full = Join-Path $GameDir $dir
    if (-not (Test-Path $full)) { New-Item -ItemType Directory -Force -Path $full | Out-Null }
}

foreach ($name in @('/doorstop_config.ini', '/.doorstop_version')) {
    $src = Join-Path $tempDir $name.TrimStart('/')
    if (Test-Path $src) { Copy-Item $src (Join-Path $GameDir $name.TrimStart('/')) -Force }
}

# clean up temp (only the folder we created)
if ($tempDir.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase) -and (Test-Path $tempDir)) {
    Remove-Item -LiteralPath $tempDir -Recurse -Force
}
Write-Ok "copied $copied files, skipped $skipped"

# ---------------------------------------------------------------- 4. verify
Write-Host ''
Write-Host '[4/4] Verify' -ForegroundColor Cyan
$missing = @()
foreach ($rel in $expected) {
    $full = Join-Path $GameDir $rel
    if (Test-Path $full) {
        if (Test-Path $full -PathType Leaf) {
            $len = (Get-Item $full).Length
            Write-Ok ("{0,-34} {1,9} bytes" -f $rel, $len)
        } else { Write-Ok ("{0,-34} <dir>" -f $rel) }
    }
    else { $missing += $rel; Write-Bad "$rel missing" }
}

Write-Host ''
if ($missing.Count -eq 0) {
    Write-Host 'BepInEx installed successfully.' -ForegroundColor Green
    Write-Host ''
    Write-Host 'Next steps:'
    Write-Host '  1) build + deploy this plugin:  powershell -ExecutionPolicy Bypass -File .\build.ps1'
    Write-Host '  2) start the game once (Steam is fine, no launch options needed)'
    Write-Host '  3) check the loader log:  BepInEx\LogOutput.log'
    Write-Host '     look for "Chainloader started" and your plugin lines.'
    Write-Host '  4) in game: press F8 (or the music button in the game UI).'
    Write-Host ''
    Write-Host 'If Windows Defender / 360 flags winhttp.dll as a false positive, whitelist the game folder.'
} else {
    Write-Bad ("install incomplete, missing: " + ($missing -join ', '))
    exit 3
}

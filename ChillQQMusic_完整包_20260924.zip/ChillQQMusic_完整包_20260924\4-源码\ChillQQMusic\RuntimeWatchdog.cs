using System;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ChillQQMusic
{
    /// <summary>
    /// 运行期看门狗。
    ///
    /// 背景：正常情况下插件的 MonoBehaviour.Update 会被 Unity 调用。
    /// 但某些游戏的启动流程（自定义 PlayerLoop、场景清理、注入式反混淆等）会让我们
    /// 挂在 BepInEx_Manager 上的组件失效——症状就是"插件日志只到初始化，之后什么都没有"。
    ///
    /// 这里注册两个与 GameObject 生命周期无关的引擎回调：
    ///   * Application.onBeforeRender —— 每帧都会触发，用来做兜底心跳；
    ///   * SceneManager.sceneLoaded   —— 场景切换时检查并重建 UI。
    /// 一旦发现 MonoBehaviour.Update 超过 2 秒没跑，就自动切到兜底循环，
    /// 让热键、进度刷新、UI 淡出继续工作。
    /// </summary>
    internal static class RuntimeWatchdog
    {
        private static bool _installed;
        private static bool _reportedFallback;
        private static int _lastFrame = -1;
        private static float _lastMonoUpdateTime = -1f;
        private static float _nextStatusLog;
        private static float _busySince = -1f;

        internal static bool UsingFallback { get; private set; }
        internal static int FallbackTicks { get; private set; }

        /// <summary>已收到的场景加载回调次数；用于避开"第一个场景加载前"的销毁窗口。</summary>
        internal static int ScenesLoaded { get; private set; }

        internal static void Install()
        {
            if (_installed) return;
            _installed = true;

            try
            {
                Application.onBeforeRender += OnBeforeRender;
                SceneManager.sceneLoaded += OnSceneLoaded;
                Plugin.Log?.LogInfo("看门狗已安装（onBeforeRender + sceneLoaded），用于兜底与场景切换自检。");
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("看门狗安装失败: " + e.Message);
            }
        }

        internal static void Uninstall()
        {
            Plugin.Trace("看门狗：卸载静态回调。");
            try
            {
                Application.onBeforeRender -= OnBeforeRender;
                SceneManager.sceneLoaded -= OnSceneLoaded;
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("看门狗卸载失败: " + e.Message);
            }
            _installed = false;
        }

        /// <summary>由 Plugin.Update 调用，标记 MonoBehaviour 生命周期健在。</summary>
        internal static void NotifyMonoUpdate() => _lastMonoUpdateTime = Time.realtimeSinceStartup;

        private static void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            try
            {
                ScenesLoaded++;
                Plugin.Log?.LogInfo("场景已加载：" + scene.name + "（" + mode + "）第 " + ScenesLoaded + " 次");
                Plugin.EnsureRuntime("场景切换");
                if (Plugin.UI != null) Plugin.UI.TryAttachSideButtonToGameUi();
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("场景切换处理异常: " + e.Message);
            }
        }

        private static void OnBeforeRender()
        {
            try
            {
                Tick();
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("兜底循环异常: " + e.Message);
            }
        }

        private static void Tick()
        {
            var frame = Time.frameCount;
            if (frame == _lastFrame) return;      // onBeforeRender 每帧可能被多个相机调用多次
            _lastFrame = frame;

            var monoAlive = _lastMonoUpdateTime >= 0f
                            && Time.realtimeSinceStartup - _lastMonoUpdateTime < 2f;
            if (monoAlive) return;                // 正常情况：什么都不做，避免与 Update 重复执行

            if (!_reportedFallback)
            {
                _reportedFallback = true;
                UsingFallback = true;
                Plugin.Log?.LogWarning("插件 Update 超过 2 秒没有被调用，已启用 onBeforeRender 兜底循环。"
                    + "（《Chill with You》启动时用 LoadSceneMode.Single 加载 Boot 场景，"
                    + "这次加载把 BepInEx 的插件对象一起销毁了）");
            }

            FallbackTicks++;
            Plugin.FallbackTick();
            LogStuckStatus();
        }

        /// <summary>
        /// 卡住时每 15 秒打一次状态，避免出现"日志里什么都没有、用户也不知道在等什么"的情况。
        /// </summary>
        private static void LogStuckStatus()
        {
            if (Time.unscaledTime < _nextStatusLog) return;

            var playlist = Plugin.Playlist;
            var audio = Plugin.Audio;

            var busy = playlist != null && playlist.IsBusy;
            var buffering = audio != null && audio.State == PlayerState.Buffering;

            if (!busy && !buffering)
            {
                _busySince = -1f;
                _nextStatusLog = Time.unscaledTime + 15f;
                return;
            }

            if (_busySince < 0f) _busySince = Time.unscaledTime;
            _nextStatusLog = Time.unscaledTime + 15f;

            var waited = Time.unscaledTime - _busySince;
            Plugin.Log?.LogWarning("状态自检：" + (busy ? "正在获取播放地址" : "音频缓冲中")
                + "，已持续 " + waited.ToString("0") + " 秒"
                + (audio != null ? "（播放状态=" + audio.State + "）" : ""));
        }
    }
}

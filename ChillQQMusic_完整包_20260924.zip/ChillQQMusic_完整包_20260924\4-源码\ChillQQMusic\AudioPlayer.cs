using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

namespace ChillQQMusic
{
    public enum PlayerState
    {
        Idle,
        Buffering,
        Playing,
        Paused,
        Error
    }

    /// <summary>
    /// 音频播放核心。只使用一个 AudioSource：
    /// 切歌时先淡出 → 释放旧 Clip → 建立新的 UnityWebRequest → 支持边下边播 → 淡入。
    /// 所有 Unity API 都在主线程（协程）中执行。
    /// </summary>
    public sealed class AudioPlayer : MonoBehaviour
    {
        private const float FadeOutSeconds = 0.18f;
        private const float FadeInSeconds = 0.25f;

        private ConfigManager _settings;
        private AudioCache _cache;
        private AudioSource _source;

        private Coroutine _routine;
        private UnityWebRequest _request;
        private SongInfo _song;
        private float _volume = 0.65f;
        private float _fade;
        private bool _finishedRaised;
        private float _nextStatusLog;

        public event Action<PlayerState, string> StateChanged;
        public event Action<SongInfo> TrackStarted;
        public event Action<float> BufferProgress;
        public event Action<string> Failed;
        public event Action Finished;

        public PlayerState State { get; private set; } = PlayerState.Idle;
        public SongInfo CurrentSong => _song;
        public string CurrentQualityLabel { get; private set; } = string.Empty;
        public bool IsPlaying => State == PlayerState.Playing;
        public bool IsPaused => State == PlayerState.Paused;
        public bool IsBusy => State == PlayerState.Buffering;

        /// <summary>
        /// 播放总时长。流式播放时 clip.length 只反映"已缓冲的部分"（可能只有几秒），
        /// 所以此时优先用歌单里的元数据时长，避免进度条乱跳。
        /// </summary>
        public float Length
        {
            get
            {
                var clipLength = _source != null && _source.clip != null ? _source.clip.length : 0f;
                var stillDownloading = _request != null && !_request.isDone;
                if (stillDownloading && _song != null && _song.DurationSeconds > 0)
                    return Mathf.Max(clipLength, _song.DurationSeconds);
                return clipLength;
            }
        }

        /// <summary>音频数据是否仍在下载（流式播放期间为 true）。</summary>
        private bool IsStillDownloading => _request != null && !_request.isDone;

        public float Position
        {
            get => _source != null && _source.clip != null ? _source.time : 0f;
            set => Seek(value);
        }

        public float Volume
        {
            get => _volume;
            set
            {
                _volume = Mathf.Clamp01(value);
                if (_source != null) _source.volume = _volume * _fade;
            }
        }

        internal void Initialize(ConfigManager settings, AudioCache cache)
        {
            _settings = settings;
            _cache = cache;

            _source = gameObject.AddComponent<AudioSource>();
            _source.playOnAwake = false;
            _source.loop = false;
            _source.spatialBlend = 0f;          // 纯 2D，不受游戏内位置影响
            _source.dopplerLevel = 0f;
            _source.volume = 0f;
            _source.ignoreListenerPause = settings.IgnoreListenerPause.Value;

            _volume = Mathf.Clamp01(settings.Volume.Value);
        }

        // ------------------------------------------------------------------ 控制

        public void PlayResolved(SongInfo song, SongUrl url)
        {
            if (song == null || url == null || string.IsNullOrEmpty(url.Url)) return;
            StopInternal(detachSong: true);
            _song = song;
            CurrentQualityLabel = url.QualityLabel;
            _finishedRaised = false;
            _routine = StartCoroutine(LoadRoutine(song, url));
        }

        public void Pause()
        {
            if (_source == null || _source.clip == null) return;
            if (State != PlayerState.Playing) return;
            _source.Pause();
            SetState(PlayerState.Paused, "已暂停");
        }

        public void Resume()
        {
            if (_source == null || _source.clip == null) return;
            if (State != PlayerState.Paused) return;
            _source.UnPause();
            SetState(PlayerState.Playing, "播放中");
        }

        public void TogglePause()
        {
            if (State == PlayerState.Playing) Pause();
            else if (State == PlayerState.Paused) Resume();
        }

        public void StopPlayback()
        {
            StopInternal(detachSong: true);
            SetState(PlayerState.Idle, string.Empty);
        }

        public bool Seek(float seconds)
        {
            if (_source == null || _source.clip == null) return false;
            var length = _source.clip.length;
            if (length <= 0.1f) return false;

            var target = Mathf.Clamp(seconds, 0f, Mathf.Max(0f, length - 0.3f));

            // 边下边播时只允许跳到已经缓冲到的位置，避免出现长静音或卡死。
            if (_request != null && !_request.downloadHandler.isDone)
            {
                var buffered = Mathf.Clamp01(_request.downloadProgress) * length;
                if (target > buffered - 1f) target = Mathf.Max(0f, buffered - 3f);
            }

            try
            {
                _source.time = target;
                _finishedRaised = false;
                return true;
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("Seek 失败: " + e.Message);
                return false;
            }
        }

        // ------------------------------------------------------------------ 加载 / 播放

        /// <summary>
        /// 外层包装：Unity 协程内部抛出的异常默认只写 Unity 控制台，
        /// BepInEx 日志里完全看不到。这里手动驱动内层迭代器，
        /// 把异常捕获下来写进插件日志（否则表现就是"状态永远停在 Buffering"）。
        /// </summary>
        private IEnumerator LoadRoutine(SongInfo song, SongUrl url)
        {
            var inner = LoadRoutineInner(song, url);
            while (true)
            {
                object current;
                try
                {
                    if (!inner.MoveNext()) break;
                    current = inner.Current;
                }
                catch (Exception e)
                {
                    Plugin.Log?.LogError("缓冲协程异常: " + e);
                    Fail("缓冲异常: " + e.Message);
                    yield break;
                }

                yield return current;
            }
        }

        private IEnumerator LoadRoutineInner(SongInfo song, SongUrl url)
        {
            SetState(PlayerState.Buffering, "正在缓冲 " + song.Title);

            // 1. 淡出当前声音，避免切歌爆音。
            if (_fade > 0.001f) yield return FadeRoutine(_fade, 0f, FadeOutSeconds);
            DisposeRequest();
            DestroyCurrentClip();

            // ============ 阶段一：先确保本地有一份完整的原始音频文件 ============
            // 不能把网络地址直接交给 Unity 解码：实测腾讯 CDN 对 "M500xxx.mp3" 的请求
            // 返回的其实是 M4A/MP4 容器（文件头 "ftypmp42"/"M4A"），
            // 容器判断错了 → 解码器拿到的 clip 时长恒为 0、不发声。
            // 因此：先下载原始字节 → 读文件头判断真实容器 → 用对应解码器本地加载。
            string localPath = null;
            if (_cache != null) _cache.TryGetFile(song, url.RequestedQuality, url.Container, out localPath);

            string convertedPath = null;
            if (!string.IsNullOrEmpty(localPath))
            {
                // 已经转码过的 WAV 直接复用（省掉下载 + 转码）
                var wavCandidate = localPath + ".wav";
                if (File.Exists(wavCandidate))
                {
                    Plugin.Log?.LogInfo("使用已转码缓存: " + Path.GetFileName(wavCandidate));
                    localPath = wavCandidate;
                    convertedPath = wavCandidate;
                }
                else
                {
                    // 缓存校验：早期版本把"实际是 m4a"的数据按 .mp3 存进了缓存，
                    // 缓存键相同会导致正确地址也被这份坏文件顶掉（表现为一直解码失败）。
                    // 这里用文件头核对容器，不一致就丢弃重下。
                    var cachedContainer = DetectContainer(localPath, null);
                    if (!string.IsNullOrEmpty(cachedContainer) && cachedContainer != url.Container)
                    {
                        Plugin.Log?.LogWarning("缓存容器不符（缓存=" + cachedContainer + "，需要=" + url.Container
                            + "），丢弃并重新下载: " + Path.GetFileName(localPath));
                        try { File.Delete(localPath); } catch (Exception e) { Plugin.Log?.LogDebug("删除旧缓存失败: " + e.Message); }
                        localPath = null;
                    }
                }
            }

            var fromCache = !string.IsNullOrEmpty(localPath);

            if (!fromCache)
            {
                // 候选地址：优先我们指定的 MP3（req_1），它 404 时回退到接口按 songmid 给的地址（req_0，通常是 m4a）
                var candidates = new List<string>();
                if (!string.IsNullOrEmpty(url.Url)) candidates.Add(url.Url);
                if (!string.IsNullOrEmpty(url.FallbackUrl) && url.FallbackUrl != url.Url) candidates.Add(url.FallbackUrl);

                for (var index = 0; index < candidates.Count && string.IsNullOrEmpty(localPath); index++)
                {
                    var downloadUrl = candidates[index];
                    if (downloadUrl.StartsWith("http://", StringComparison.OrdinalIgnoreCase))
                        downloadUrl = "https://" + downloadUrl.Substring("http://".Length);   // Unity 禁止明文连接

                    string downloadHost;
                    try { downloadHost = new Uri(downloadUrl).Host; } catch { downloadHost = "(未知)"; }
                    Plugin.Log?.LogInfo("开始下载(" + (index + 1) + "/" + candidates.Count + "): 主机=" + downloadHost
                        + " 请求格式=" + url.Container);

                    UnityWebRequest raw;
                    try
                    {
                        raw = UnityWebRequest.Get(downloadUrl);
                    }
                    catch (Exception e)
                    {
                        Plugin.Log?.LogWarning("创建下载请求失败: " + e.Message);
                        continue;
                    }

                    raw.timeout = Math.Max(20, _settings.TimeoutSeconds.Value * 3);
                    try { raw.SetRequestHeader("Referer", "https://y.qq.com/"); }
                    catch (Exception e) { Plugin.Log?.LogWarning("设置 Referer 失败: " + e.Message); }
                    try { raw.SetRequestHeader("User-Agent", QQHttp.UserAgent); }
                    catch (Exception e) { Plugin.Log?.LogWarning("设置 User-Agent 失败: " + e.Message); }

                    var downloadOp = raw.SendWebRequest();
                    var lastProgress = 0f;
                    var lastProgressTime = Time.realtimeSinceStartup;
                    const float stallSeconds = 25f;
                    var stalled = false;

                    while (!downloadOp.isDone)
                    {
                        var progress = raw.downloadProgress;
                        BufferProgress?.Invoke(progress);

                        if (progress > lastProgress + 0.0005f)
                        {
                            lastProgress = progress;
                            lastProgressTime = Time.realtimeSinceStartup;
                        }
                        else if (Time.realtimeSinceStartup - lastProgressTime > stallSeconds)
                        {
                            Plugin.Log?.LogWarning("下载停滞 " + stallSeconds + " 秒（进度 "
                                + (progress * 100f).ToString("0") + "%），换下一个地址");
                            stalled = true;
                            try { raw.Abort(); } catch { /* 忽略 */ }
                            break;
                        }

                        yield return null;
                    }

                    if (stalled)
                    {
                        try { raw.Dispose(); } catch { /* 忽略 */ }
                        continue;
                    }

                    if (raw.result != UnityWebRequest.Result.Success)
                    {
                        var message = DescribeError(raw) + "（HTTP " + raw.responseCode + "）";
                        try { raw.Dispose(); } catch { /* 忽略 */ }
                        Plugin.Log?.LogWarning("地址不可用: " + message);
                        continue;
                    }

                    var bytes = raw.downloadHandler != null ? raw.downloadHandler.data : null;
                    try { raw.Dispose(); } catch { /* 忽略 */ }

                    if (bytes == null || bytes.Length < 4096)
                    {
                        Plugin.Log?.LogWarning("下载数据过小（" + (bytes != null ? bytes.Length : 0) + " 字节），换下一个地址");
                        continue;
                    }

                    var targetPath = _cache != null
                        ? _cache.GetPath(song, url.RequestedQuality, url.Container)
                        : Path.Combine(Path.GetTempPath(), "ChillQQMusic", (song.Mid ?? "track") + ".bin");

                    try
                    {
                        var dir = Path.GetDirectoryName(targetPath);
                        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
                        File.WriteAllBytes(targetPath, bytes);
                    }
                    catch (Exception e)
                    {
                        Plugin.Log?.LogWarning("写入本地文件失败: " + e.Message);
                        continue;
                    }

                    localPath = targetPath;
                    Plugin.Log?.LogInfo("下载完成: " + bytes.Length + " 字节 → " + Path.GetFileName(targetPath));
                }

                if (string.IsNullOrEmpty(localPath))
                {
                    Fail("所有候选地址都无法下载（共 " + candidates.Count + " 个）");
                    yield break;
                }
            }
            else
            {
                Plugin.Log?.LogInfo("使用本地缓存: " + Path.GetFileName(localPath));
            }

            // ============ 阶段一.五：AAC/m4a 交给 Windows Media Foundation 转成 WAV ============
            // Unity（Windows）的 UnityWebRequest 解不了 AAC（AudioType.ACC 只在移动端生效），
            // 所以先用自带的 MfDecode.dll（调用系统解码器）转码，再让 Unity 读 WAV。
            var container = DetectContainer(localPath, url.Container);
            if (container == "m4a" || container == "aac" || container == "mp4")
            {
                if (convertedPath == null || !File.Exists(convertedPath))
                {
                    convertedPath = localPath + ".wav";
                    Plugin.Log?.LogInfo("容器是 " + container + "（Unity 不支持 AAC 解码），"
                        + "调用 Windows Media Foundation 转码为 WAV…");

                    // 转码是阻塞的原生调用，放到线程池执行，主线程只等结果，避免卡住游戏
                    var convertTask = Task.Run(() => NativeMfDecode.DecodeToWav(localPath, convertedPath));
                    var deadline = Time.realtimeSinceStartup + 180f;
                    while (!convertTask.IsCompleted && Time.realtimeSinceStartup < deadline) yield return null;

                    if (!convertTask.IsCompleted)
                    {
                        Fail("m4a 转码超时（180 秒）");
                        yield break;
                    }

                    int convertResult;
                    try { convertResult = convertTask.Result; }
                    catch (Exception e) { Fail("m4a 转码异常：" + e.Message); yield break; }

                    if (convertResult <= 0)
                    {
                        Fail("m4a 转码失败（MfDecode 返回 " + convertResult + "）");
                        yield break;
                    }

                    long wavSize = 0;
                    try { wavSize = new FileInfo(convertedPath).Length; } catch { /* 忽略 */ }
                    Plugin.Log?.LogInfo("转码完成: " + (wavSize / 1024) + " KB → " + Path.GetFileName(convertedPath));
                }

                localPath = convertedPath;
                container = "wav";
            }

            // ============ 阶段二：按真实容器解码 ============
            if (container == "flac")
            {
                Fail("FLAC 无法用 UnityWebRequest 解码，改用其它音质重试");
                yield break;
            }

            var audioType = ResolveAudioType(container);
            Plugin.Log?.LogInfo("开始解码: 容器=" + container + " AudioType=" + audioType
                + " 文件=" + Path.GetFileName(localPath));

            UnityWebRequest request;
            try
            {
                request = UnityWebRequestMultimedia.GetAudioClip(new Uri(localPath).AbsoluteUri, audioType);
            }
            catch (Exception e)
            {
                Fail("创建解码请求失败：" + e.Message);
                yield break;
            }

            request.timeout = Math.Max(20, _settings.TimeoutSeconds.Value * 3);
            _request = request;      // 播放期间必须保持存活，StopInternal 里统一释放

            var decodeOperation = request.SendWebRequest();
            while (!decodeOperation.isDone) yield return null;

            if (request.result != UnityWebRequest.Result.Success)
            {
                Fail("解码请求失败：" + DescribeError(request));
                yield break;
            }

            var handler = request.downloadHandler as DownloadHandlerAudioClip;
            var clip = handler != null ? SafeAudioClip(handler) : null;
            if (clip == null || clip.length <= 0.01f || clip.channels == 0)
            {
                // 时长/声道为 0 说明解码器解不动这个容器（例如本作 Unity 不支持 AAC/m4a），
                // 必须当作失败抛给上层，让它降级到能给出真正 MP3 的音质。
                Fail("音频解码失败（容器 " + container + "，时长 "
                    + (clip != null ? clip.length.ToString("0.0") : "-") + "s，声道 "
                    + (clip != null ? clip.channels.ToString() : "-") + "）");
                yield break;
            }

            Plugin.Log?.LogInfo("解码成功: 时长=" + clip.length.ToString("0.0") + "s 声道=" + clip.channels
                + " 采样率=" + clip.frequency + " 来自缓存=" + fromCache);

            BeginPlayback(clip, song, url, true);
        }

        /// <summary>
        /// 读文件头判断真实容器。腾讯 CDN 会"挂羊头卖狗肉"：
        /// 请求 M500xxx.mp3 时实际返回 M4A（文件头 "ftypmp42"/"M4A"）。
        /// </summary>
        private static string DetectContainer(string path, string fallback)
        {
            try
            {
                if (string.IsNullOrEmpty(path) || !File.Exists(path)) return fallback;

                var head = new byte[16];
                using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    var read = stream.Read(head, 0, head.Length);
                    if (read < 12) return fallback;
                }

                var ascii = Encoding.ASCII.GetString(head, 0, 12);
                if (ascii.StartsWith("ID3")) return "mp3";
                if (head[0] == 0xFF && (head[1] & 0xE0) == 0xE0) return "mp3";   // 裸 MP3 帧同步
                if (ascii.Substring(4, 4) == "ftyp") return "m4a";               // MP4/M4A
                if (ascii.StartsWith("fLaC")) return "flac";
                if (ascii.StartsWith("OggS")) return "ogg";
                if (ascii.StartsWith("RIFF")) return "wav";
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("容器检测失败: " + e.Message);
            }
            return fallback;
        }

        private void BeginPlayback(AudioClip clip, SongInfo song, SongUrl url, bool fromCache)
        {
            _source.clip = clip;
            _source.time = 0f;
            _source.volume = 0f;
            _source.Play();
            _fade = 0f;
            SetState(PlayerState.Playing, (fromCache ? "播放中（本地缓存） " : "播放中 ") + url.QualityLabel);
            TrackStarted?.Invoke(song);
            StartCoroutine(FadeRoutine(0f, 1f, FadeInSeconds));
        }

        private static AudioClip SafeAudioClip(DownloadHandlerAudioClip handler)
        {
            try { return handler.audioClip; }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("读取 AudioClip 失败: " + e.Message);
                return null;
            }
        }

        private static string DescribeError(UnityWebRequest request)
        {
            var detail = request.error ?? "未知错误";
            switch (request.result)
            {
                case UnityWebRequest.Result.ConnectionError:
                    return "网络连接失败：" + detail;
                case UnityWebRequest.Result.ProtocolError:
                    return "播放地址无效或已过期（HTTP " + request.responseCode + "）";
                case UnityWebRequest.Result.DataProcessingError:
                    return "音频数据损坏：" + detail;
                default:
                    return "播放失败：" + detail;
            }
        }

        private void Fail(string message)
        {
            SetState(PlayerState.Error, message);
            Failed?.Invoke(message);
        }

        // ------------------------------------------------------------------ 生命周期 / 清理

        private void Update()
        {
            if (_source == null || _source.clip == null || _finishedRaised) return;
            if (State != PlayerState.Playing) return;

            // 关键：流式播放期间 clip.length 只代表"已缓冲长度"，
            // 直接拿它判断结束会导致每首歌几秒钟就被掐断（听不到声音、进度条乱跳）。
            // 因此下载未完成时一律不做"播放结束"判定。
            if (IsStillDownloading) return;

            // 每 10 秒打一次播放状态，方便确认"时间在走、音量不为 0"
            if (Time.unscaledTime >= _nextStatusLog)
            {
                _nextStatusLog = Time.unscaledTime + 10f;
                Plugin.Log?.LogInfo("播放状态: 位置=" + Position.ToString("0.0") + "s / 时长="
                    + Length.ToString("0.0") + "s  音量=" + (_source != null ? _source.volume.ToString("0.00") : "-")
                    + "  下载进度=" + (_request != null ? _request.downloadProgress.ToString("0.00") : "已完成")
                    + "  缓存=" + (_cache != null ? "on" : "off"));
            }

            // 播放结束判定：AudioSource 停止，且时间已经走过去了。
            if (!_source.isPlaying && _source.time > 0.05f)
            {
                _finishedRaised = true;
                Finished?.Invoke();
                return;
            }

            var length = _source.clip.length;
            if (length > 1f && _source.time >= length - 0.08f)
            {
                _finishedRaised = true;
                Finished?.Invoke();
            }
        }

        private void StopInternal(bool detachSong)
        {
            if (_routine != null)
            {
                try { StopCoroutine(_routine); } catch { /* 忽略 */ }
                _routine = null;
            }

            try { if (_source != null) _source.Stop(); } catch { /* 忽略 */ }

            DisposeRequest();
            DestroyCurrentClip();
            _fade = 0f;
            if (_source != null) _source.volume = 0f;

            if (detachSong)
            {
                _song = null;
                CurrentQualityLabel = string.Empty;
                _finishedRaised = false;
            }
        }

        private void DisposeRequest()
        {
            if (_request == null) return;
            try { _request.Dispose(); }
            catch (Exception e) { Plugin.Log?.LogDebug("释放请求失败: " + e.Message); }
            _request = null;
        }

        private void DestroyCurrentClip()
        {
            if (_source == null) return;
            var clip = _source.clip;
            _source.clip = null;
            if (clip != null)
            {
                try { Destroy(clip); }
                catch (Exception e) { Plugin.Log?.LogDebug("销毁 Clip 失败: " + e.Message); }
            }
        }

        private IEnumerator FadeRoutine(float from, float to, float duration)
        {
            var elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.unscaledDeltaTime;
                _fade = Mathf.Lerp(from, to, Mathf.Clamp01(elapsed / duration));
                if (_source != null) _source.volume = _volume * _fade;
                yield return null;
            }
            _fade = to;
            if (_source != null) _source.volume = _volume * _fade;
        }

        private void SetState(PlayerState state, string message)
        {
            State = state;
            StateChanged?.Invoke(state, message);
        }

        private void OnDestroy()
        {
            Plugin.Trace("AudioPlayer 被销毁。");
            StopInternal(detachSong: true);
        }

        /// <summary>
        /// 退出前主动释放。
        ///
        /// 关键点：播放期间 <c>_request</c>（UnityWebRequestMultimedia.GetAudioClip）必须保持存活，
        /// 而它同时持有原生解码器与 AudioClip。如果在 Unity 拆音频/网络子系统的时候才释放，
        /// 主线程会卡住（表现＝关游戏时窗口"无响应"）。所以要在退出流程最前面就放掉。
        /// </summary>
        internal void PrepareForShutdown()
        {
            var hadRequest = _request != null;
            var clip = _source != null ? _source.clip : null;
            Plugin.Log?.LogInfo("  └ 音频：停止播放（在途请求=" + (hadRequest ? "有" : "无")
                + "，时长=" + (clip != null ? clip.length.ToString("0.0") + "s" : "无") + "）");
            Plugin.Trace("音频：停止播放（在途请求=" + (hadRequest ? "有" : "无") + "）");
            StopInternal(detachSong: true);
            Plugin.Trace("音频：已释放请求与 AudioClip。");
        }

        // ------------------------------------------------------------------ 格式映射

        internal static AudioType ResolveAudioType(string container)
        {
            switch ((container ?? string.Empty).Trim().ToLowerInvariant())
            {
                case "mp3": return AudioType.MPEG;
                case "ogg": return AudioType.OGGVORBIS;
                case "wav": return AudioType.WAV;
                case "m4a":
                case "aac":
                case "mp4": return AudioType.ACC;      // Unity 的枚举拼写就是 ACC
                default: return AudioType.MPEG;
            }
        }

        private static bool SupportsStreaming(AudioType type)
        {
            return type == AudioType.MPEG || type == AudioType.OGGVORBIS || type == AudioType.WAV;
        }
    }
}

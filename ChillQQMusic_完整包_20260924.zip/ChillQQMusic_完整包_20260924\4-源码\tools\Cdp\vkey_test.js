(function () {
  var uin = "1831290549";
  var mid = "000Ms8EM0k35Ms";
  var payload = {
    comm: { ct: 24, cv: 0, format: "json", uin: uin, platform: "yqq.json" },
    req_0: {
      module: "vkey.GetVkeyServer",
      method: "CgiGetVkey",
      param: {
        guid: "1234567890",
        songmid: [mid],
        filename: ["M500" + mid + ".mp3"],
        songtype: [0],
        uin: uin,
        loginflag: 1,
        platform: "20"
      }
    }
  };
  try {
    var x = new XMLHttpRequest();
    x.open("POST", "https://u.y.qq.com/cgi-bin/musicu.fcg", false);
    x.setRequestHeader("Content-Type", "application/json");
    x.send(JSON.stringify(payload));
    var text = x.responseText || "";
    var m = text.match(/"purl"\s*:\s*"([^"]*)"/);
    var r = text.match(/"retcode"\s*:\s*(-?\d+)/);
    return "HTTP " + x.status + " retcode=" + (r ? r[1] : "?") + " purlLen=" + (m && m[1] ? m[1].length : 0) + " | " + text.slice(0, 160);
  } catch (e) {
    return "ERR " + e;
  }
})()

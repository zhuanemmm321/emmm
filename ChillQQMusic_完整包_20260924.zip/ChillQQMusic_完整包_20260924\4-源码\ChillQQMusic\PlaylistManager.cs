using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace ChillQQMusic
{
    /// <summary>
    /// 歌单 + 播放队列的大脑：解析播放地址、缓存、切歌、播放模式、歌词加载、失败降级。
    /// 自身不是 MonoBehaviour，需要主循环的地方由 Plugin.Update 调用 Tick()。
    /// </summary>
    public sealed class PlaylistManager : IDisposable
    {
        private static readonly Regex IdRegex = new Regex(@"(?:id=|/playlist/|disstid=|^)(\d{5,})", RegexOptions.Compiled);
        private static readonly Regex AnyDigits = new Regex(@"\d+", RegexOptions.Compiled);

        private readonly ConfigManager _settings;
        private readonly IQQMusicService _service;
        private AudioPlayer _audio;
        private readonly Random _random = new Random();
        private readonly Dictionary<string, SongUrl> _urlCache = new Dictionary<string, SongUrl>();
        private readonly HashSet<string> _lowQualityFallbackDone = new HashSet<string>();

        private CancellationTokenSource _playCts;
        private bool _flacWarningShown;
        private bool _prefetchDone;
        private bool _disposed;

        public event Action<PlaylistInfo> PlaylistUpdated;
        public event Action<SongInfo> SongChanged;
        public event Action<Lyrics> LyricsUpdated;
        public event Action<string, bool> Notice;
        public event Action<bool> BusyChanged;

        public PlaylistInfo Playlist { get; private set; }
        public int CurrentIndex { get; private set; } = -1;
        public Lyrics CurrentLyrics { get; private set; }
        public bool IsBusy { get; private set; }
        public string LastError { get; private set; }

        public SongInfo CurrentSong
        {
            get
            {
                var list = Playlist?.Songs;
                if (list == null || CurrentIndex < 0 || CurrentIndex >= list.Count) return null;
                return list[CurrentIndex];
            }
        }

        public PlayMode Mode
        {
            get => _settings.DefaultPlayMode.Value;
            set
            {
                _settings.DefaultPlayMode.Value = value;
                _settings.Save();
                Notify("播放模式：" + ModeLabel(value), false);
            }
        }

        public PlaylistManager(ConfigManager settings, IQQMusicService service)
        {
            _settings = settings;
            _service = service;
        }

        /// <summary>
        /// 后绑定播放器。本游戏会在启动阶段销毁 BepInEx 的插件对象，
        /// 运行期组件（AudioSource + UI）必须延后到首个场景加载之后再创建，然后回挂到这里。
        /// </summary>
        public void AttachAudio(AudioPlayer audio)
        {
            if (ReferenceEquals(_audio, audio)) return;

            if (_audio != null)
            {
                _audio.Finished -= OnTrackFinished;
                _audio.Failed -= OnAudioFailed;
            }

            _audio = audio;

            if (_audio != null)
            {
                _audio.Finished += OnTrackFinished;
                _audio.Failed += OnAudioFailed;
            }
        }

        public void Dispose()
        {
            _disposed = true;
            try { _playCts?.Cancel(); } catch { /* 忽略 */ }
            _playCts?.Dispose();
            _playCts = null;
            if (_audio != null)
            {
                _audio.Finished -= OnTrackFinished;
                _audio.Failed -= OnAudioFailed;
            }
        }

        /// <summary>退出清理：取消在途的取址/预取任务并停止 Tick。</summary>
        internal void PrepareForShutdown()
        {
            Plugin.Log?.LogInfo("  └ 歌单：取消在途任务（忙=" + IsBusy + "）");
            Plugin.Trace("歌单：取消在途任务（忙=" + IsBusy + "）");
            Dispose();
            Plugin.Trace("歌单：已取消。");
        }

        // ------------------------------------------------------------------ 歌单

        public async Task RefreshAsync(bool autoPlayIfIdle = true)
        {
            var idOrUrl = _settings.ResolvePlaylistId();
            if (string.IsNullOrWhiteSpace(idOrUrl))
            {
                var uid = _settings.UserUid.Value;
                if (!string.IsNullOrWhiteSpace(uid))
                {
                    await RefreshByUserUidAsync(uid, autoPlayIfIdle).ConfigureAwait(false);
                    return;
                }

                // 注意这里用 isError:false —— 「还没绑定歌单」是正常的初始状态（引导），
                // 不是故障。用红字报错会在登录成功那一刻吓人一跳。
                LastError = "还没有绑定歌单：点面板右上角的「歌单」按钮，填歌单 ID（或分享链接）后点「绑定」。";
                Notify(LastError, false);
                return;
            }

            SetBusy(true);
            try
            {
                using (var cts = new CancellationTokenSource(TimeSpan.FromSeconds(Math.Max(10, _settings.TimeoutSeconds.Value * 3))))
                {
                    var playlist = await _service.GetPlaylistAsync(idOrUrl, cts.Token).ConfigureAwait(false);
                    _urlCache.Clear();
                    _lowQualityFallbackDone.Clear();

                    // 注意：引用赋值必须在后台线程就地完成，
                    // 因为下面紧接着的 PlayIndexAsync 会立刻读取 Playlist；
                    // 只有触发 Unity 事件（UI）才需要切回主线程。
                    Playlist = playlist;
                    if (CurrentIndex >= playlist.Songs.Count) CurrentIndex = -1;
                    MainThreadDispatcher.Post(() => PlaylistUpdated?.Invoke(playlist));

                    Notify("歌单已加载：" + playlist.Name + "（" + playlist.Songs.Count + " 首）", false);

                    if (autoPlayIfIdle && (CurrentIndex < 0 || _audio == null || !_audio.IsPlaying) && playlist.Songs.Count > 0)
                        await PlayIndexAsync(0).ConfigureAwait(false);
                }
            }
            catch (OperationCanceledException)
            {
                LastError = "加载歌单超时，请检查网络或代理设置。";
                Notify(LastError, true);
            }
            catch (Exception e)
            {
                LastError = e.Message;
                Notify("加载歌单失败：" + e.Message, true);
                Plugin.Log?.LogWarning("加载歌单失败: " + e);
            }
            finally
            {
                SetBusy(false);
            }
        }

        /// <summary>没有填歌单 ID 时，用「用户UID」把该用户的公开歌单合并成一个播放队列。</summary>
        private async Task RefreshByUserUidAsync(string uid, bool autoPlayIfIdle)
        {
            const int maxPlaylists = 5;      // 防止一次拉太多把接口打爆
            const int maxSongs = 1500;

            SetBusy(true);
            try
            {
                using (var cts = new CancellationTokenSource(TimeSpan.FromSeconds(Math.Max(20, _settings.TimeoutSeconds.Value * 5))))
                {
                    var summaries = await _service.GetUserPlaylistsAsync(uid, cts.Token).ConfigureAwait(false);
                    if (summaries.Count == 0)
                        throw new QQMusicException("这个用户没有可公开读取的歌单（私密歌单需要登录后才能看到）。");

                    var merged = new PlaylistInfo { Id = uid, Name = "用户 " + uid + " 的歌单合集" };
                    var loaded = 0;

                    foreach (var summary in summaries)
                    {
                        if (loaded >= maxPlaylists || merged.Songs.Count >= maxSongs) break;
                        try
                        {
                            var playlist = await _service.GetPlaylistAsync(summary.Id, cts.Token).ConfigureAwait(false);
                            merged.Songs.AddRange(playlist.Songs);
                            loaded++;
                            Plugin.Log?.LogInfo("已合并歌单 " + summary.Name + "（" + playlist.Songs.Count + " 首）");
                        }
                        catch (Exception e)
                        {
                            Notify("跳过歌单「" + summary.Name + "」：" + e.Message, true);
                        }
                    }

                    if (merged.Songs.Count == 0)
                        throw new QQMusicException("没有读取到任何歌曲，请确认歌单是否公开，或改用纯数字歌单 ID。");

                    _urlCache.Clear();
                    _lowQualityFallbackDone.Clear();
                    Playlist = merged;
                    CurrentIndex = -1;
                    MainThreadDispatcher.Post(() => PlaylistUpdated?.Invoke(merged));
                    Notify("已加载 " + loaded + " 个歌单，共 " + merged.Songs.Count + " 首", false);

                    if (autoPlayIfIdle) await PlayIndexAsync(0).ConfigureAwait(false);
                }
            }
            catch (OperationCanceledException)
            {
                LastError = "按用户UID加载歌单超时。";
                Notify(LastError, true);
            }
            catch (Exception e)
            {
                LastError = e.Message;
                Notify("加载失败：" + e.Message, true);
                Plugin.Log?.LogWarning("按用户UID加载歌单失败: " + e);
            }
            finally
            {
                SetBusy(false);
            }
        }

        // ------------------------------------------------------------------ 播放控制

        public async Task PlayIndexAsync(int index)
        {
            var list = Playlist?.Songs;
            if (list == null || list.Count == 0)
            {
                Notify("歌单为空，先点刷新试试。", true);
                return;
            }
            if (index < 0 || index >= list.Count) return;

            CurrentIndex = index;
            var song = list[index];
            _prefetchDone = false;

            MainThreadDispatcher.Post(() =>
            {
                SongChanged?.Invoke(song);
                LyricsUpdated?.Invoke(null);
            });

            await ResolveAndPlayAsync(song, allowRetry: true).ConfigureAwait(false);
        }

        /// <summary>
        /// 「歌单还没加载就要播/切歌」的兜底。
        ///
        /// 触发场景：启动时登录已失效（Cookie 过期）→ 恢复登录失败 → 「登录后自动刷新歌单」
        /// 那一步没跑 → Playlist 为 null → 按播放键静默无反应。
        /// 现在改成先加载歌单，加载完成后 RefreshAsync(autoPlayIfIdle:true)
        /// 会自动从第 0 首开始播（配置了「启动后自动播放」时同理）。
        /// </summary>
        private bool EnsurePlaylistLoaded(bool autoPlay)
        {
            if (Playlist != null && Playlist.Songs.Count > 0) return false;
            if (IsBusy) return true;                 // 正在加载中，别重复触发

            Plugin.Log?.LogInfo("歌单尚未加载，先自动加载一次（加载完自动播放=" + autoPlay + "）。");
            _ = RefreshAsync(autoPlay);
            return true;
        }

        public Task NextAsync()
        {
            if (EnsurePlaylistLoaded(true)) return Task.CompletedTask;
            var next = GetNextIndex();
            return next < 0 ? Task.CompletedTask : PlayIndexAsync(next);
        }

        public Task PrevAsync()
        {
            if (EnsurePlaylistLoaded(true)) return Task.CompletedTask;
            var list = Playlist?.Songs;
            if (list == null || list.Count == 0) return Task.CompletedTask;

            var index = CurrentIndex <= 0 ? list.Count - 1 : CurrentIndex - 1;
            if (Mode == PlayMode.Shuffle) index = _random.Next(list.Count);
            return PlayIndexAsync(index);
        }

        public void TogglePlayPause()
        {
            if (_audio == null) return;

            if (CurrentIndex < 0)
            {
                // 歌单还没加载（例如启动时登录失效）→ 先加载，加载完会自动开播
                if (EnsurePlaylistLoaded(true)) return;
                if (Playlist != null && Playlist.Songs.Count > 0) _ = PlayIndexAsync(0);
                return;
            }

            if (_audio.IsPlaying || _audio.IsPaused) _audio.TogglePause();
            else _ = PlayIndexAsync(CurrentIndex);
        }

        public void SetVolume(float value01)
        {
            var v = Math.Max(0f, Math.Min(1f, value01));
            _settings.Volume.Value = v;
            if (_audio != null) _audio.Volume = v;
            _settings.Save();
        }

        public void Seek01(float value01)
        {
            if (_audio == null) return;
            var length = _audio.Length;
            if (length <= 0.1f) return;
            _audio.Seek(value01 * length);
        }

        // ------------------------------------------------------------------ 内部流程

        private async Task ResolveAndPlayAsync(SongInfo song, bool allowRetry)
        {
            CancelCurrentPlay();
            var cts = new CancellationTokenSource();
            _playCts = cts;

            SetBusy(true);
            try
            {
                if (_settings.Quality.Value == AudioQuality.FLAC && !_flacWarningShown)
                {
                    _flacWarningShown = true;
                    Notify("Unity 无法直接解码 FLAC，已自动改用 320K/128K。", false);
                }

                var url = await ResolveUrlAsync(song, cts.Token).ConfigureAwait(false);
                if (cts.IsCancellationRequested) return;

                MainThreadDispatcher.Post(() =>
                {
                    if (_disposed) return;
                    _audio.PlayResolved(song, url);
                });

                _ = LoadLyricsAsync(song, cts.Token);
            }
            catch (OperationCanceledException)
            {
                // 被下一次切歌取消，属于正常流程
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("播放「" + song.Title + "」失败: " + e.Message);

                if (allowRetry && !_lowQualityFallbackDone.Contains(song.Mid))
                {
                    _lowQualityFallbackDone.Add(song.Mid);
                    Notify("获取播放地址失败，已降级重试：" + e.Message, true);
                    await ResolveAndPlayAsync(song, allowRetry: false).ConfigureAwait(false);
                }
                else
                {
                    LastError = e.Message;
                    Notify("播放失败：" + e.Message, true);
                }
            }
            finally
            {
                if (ReferenceEquals(_playCts, cts)) SetBusy(false);
            }
        }

        private async Task<SongUrl> ResolveUrlAsync(SongInfo song, CancellationToken ct)
        {
            if (_urlCache.TryGetValue(song.Mid, out var cached) && !cached.IsExpired) return cached;

            var quality = _settings.Quality.Value;
            if (quality == AudioQuality.FLAC) quality = AudioQuality.MP3_320;   // Unity 解不了 flac
            if (_lowQualityFallbackDone.Contains(song.Mid)) quality = AudioQuality.MP3_128;

            var url = await _service.GetSongUrlAsync(song, quality, ct).ConfigureAwait(false);
            _urlCache[song.Mid] = url;
            return url;
        }

        private async Task LoadLyricsAsync(SongInfo song, CancellationToken ct)
        {
            try
            {
                var lyrics = await _service.GetLyricsAsync(song, ct).ConfigureAwait(false);
                MainThreadDispatcher.Post(() =>
                {
                    if (_disposed) return;
                    if (CurrentSong == null || CurrentSong.Mid != song.Mid) return;
                    CurrentLyrics = lyrics;
                    LyricsUpdated?.Invoke(lyrics);
                });
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("歌词加载失败: " + e.Message);
            }
        }

        /// <summary>主循环调用：负责预取下一首地址。</summary>
        public void Tick()
        {
            if (_disposed || _prefetchDone || Playlist == null || CurrentIndex < 0) return;
            if (_audio == null || !_audio.IsPlaying) return;

            var length = _audio.Length;
            if (length <= 1f) return;

            if (length - _audio.Position <= Math.Max(3, _settings.PrefetchSeconds.Value))
            {
                _prefetchDone = true;
                _ = PrefetchNextAsync();
            }
        }

        public async Task PrefetchNextAsync()
        {
            try
            {
                var next = GetNextIndex();
                var list = Playlist?.Songs;
                if (list == null || next < 0 || next >= list.Count) return;
                var song = list[next];
                if (_urlCache.TryGetValue(song.Mid, out var cached) && !cached.IsExpired) return;

                using (var cts = new CancellationTokenSource(TimeSpan.FromSeconds(Math.Max(8, _settings.TimeoutSeconds.Value))))
                {
                    var quality = _settings.Quality.Value == AudioQuality.FLAC ? AudioQuality.MP3_320 : _settings.Quality.Value;
                    var url = await _service.GetSongUrlAsync(song, quality, cts.Token).ConfigureAwait(false);
                    _urlCache[song.Mid] = url;
                    Plugin.Log?.LogDebug("已预取下一首地址: " + song.Title);
                }
            }
            catch (Exception e)
            {
                Plugin.Log?.LogDebug("预取失败（不影响播放）: " + e.Message);
            }
        }

        private int GetNextIndex()
        {
            var list = Playlist?.Songs;
            if (list == null || list.Count == 0) return -1;

            switch (Mode)
            {
                case PlayMode.RepeatOne:
                    return CurrentIndex;

                case PlayMode.Shuffle:
                    if (list.Count == 1) return 0;
                    var next = _random.Next(list.Count);
                    if (next == CurrentIndex) next = (next + 1) % list.Count;
                    return next;

                default:
                    if (CurrentIndex < 0) return 0;
                    if (CurrentIndex >= list.Count - 1)
                    {
                        Notify("已经是最后一首了。", false);
                        return -1;
                    }
                    return CurrentIndex + 1;
            }
        }

        private void OnTrackFinished()
        {
            if (_disposed || Playlist == null || Playlist.Songs.Count == 0) return;
            if (Mode == PlayMode.RepeatOne) _ = PlayIndexAsync(CurrentIndex);
            else _ = NextAsync();
        }

        private void OnAudioFailed(string message)
        {
            var song = CurrentSong;
            if (song == null || _lowQualityFallbackDone.Contains(song.Mid)) return;
            _lowQualityFallbackDone.Add(song.Mid);
            Notify("播放失败，改用低音质重试：" + message, true);
            _ = ResolveAndPlayAsync(song, allowRetry: false);
        }

        private void CancelCurrentPlay()
        {
            var old = _playCts;
            _playCts = null;
            if (old == null) return;

            try { old.Cancel(); } catch (Exception e) { Plugin.Log?.LogDebug("取消播放异常: " + e.Message); }

            // 延后释放：如果立刻 Dispose，在途的 HttpClient / Task.Delay 回调内部可能
            // 触到 ObjectDisposedException。
            System.Threading.Tasks.Task.Delay(TimeSpan.FromSeconds(5))
                .ContinueWith(_ => { try { old.Dispose(); } catch { /* 忽略 */ } });
        }

        private void SetBusy(bool busy)
        {
            IsBusy = busy;
            MainThreadDispatcher.Post(() => BusyChanged?.Invoke(busy));
        }

        private void Notify(string message, bool isError)
        {
            if (isError) LastError = message;
            Plugin.Log?.LogInfo((isError ? "[错误] " : string.Empty) + message);
            MainThreadDispatcher.Post(() => Notice?.Invoke(message, isError));
        }

        public static string ModeLabel(PlayMode mode)
        {
            switch (mode)
            {
                case PlayMode.RepeatOne: return "单曲循环";
                case PlayMode.Shuffle: return "随机播放";
                default: return "顺序播放";
            }
        }

        /// <summary>从歌单链接里提取数字 ID；纯数字直接返回。</summary>
        public static string ExtractPlaylistId(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return string.Empty;
            input = input.Trim();
            if (input.All(char.IsDigit)) return input;

            var match = IdRegex.Match(input);
            if (match.Success) return match.Groups[1].Value;

            var longest = string.Empty;
            foreach (Match m in AnyDigits.Matches(input))
                if (m.Value.Length > longest.Length) longest = m.Value;
            return longest;
        }
    }
}

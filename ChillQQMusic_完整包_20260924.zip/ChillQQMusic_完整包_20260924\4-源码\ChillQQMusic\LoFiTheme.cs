using System;
using System.Collections.Generic;
using UnityEngine;

namespace ChillQQMusic
{
    internal enum LofiIcon
    {
        Play, Pause, Prev, Next, RepeatAll, RepeatOne, Shuffle,
        Volume, Lyrics, Close, Login, Refresh, List, Trash, Music
    }

    /// <summary>
    /// 程序化生成的 Lo-Fi 风格贴图：暖黄 / 米白 / 低饱和棕、圆角、轻微噪点。
    /// 全部用代码画，不依赖任何 AssetBundle。
    /// </summary>
    internal static class LoFiTheme
    {
        // ---- 配色：对齐游戏 UI（深色玻璃面板 + 青→品红渐变 + 白色文字）----
        // 色值来自对游戏截图 #101020 / #282840 / #00C0D8 / #D800A0 / #F0F0F5 的实际取样。
        internal static readonly Color Paper      = new Color32(0x10, 0x10, 0x20, 0xD2);   // 面板玻璃底
        internal static readonly Color PaperSoft  = new Color32(0x28, 0x28, 0x40, 0xD0);   // 控件/列表条
        internal static readonly Color PaperDeep  = new Color32(0x38, 0x38, 0x58, 0xF0);   // 描边/内层
        internal static readonly Color Ink        = new Color32(0xF0, 0xF0, 0xF5, 0xFF);   // 主文字（近白）
        internal static readonly Color InkSoft    = new Color32(0xF0, 0xF0, 0xF5, 0xA6);   // 次级文字
        // 游戏原生图标实测是"淡紫白"（#9292B5 左右），不是纯白：
        // 次级图标用这个色，才不会比游戏自己的图标亮一档、显突兀。
        internal static readonly Color IconLav    = new Color32(0xC6, 0xC6, 0xE2, 0xFF);
        internal static readonly Color Accent     = new Color32(0x00, 0xC0, 0xD8, 0xFF);   // 渐变·青
        internal static readonly Color AccentDeep = new Color32(0xD8, 0x00, 0xA0, 0xFF);   // 渐变·品红
        internal static readonly Color Track      = new Color32(0xFF, 0xFF, 0xFF, 0x26);   // 滑轨（更暗，细但不抢眼）
        internal static readonly Color TrackEdge  = new Color32(0xFF, 0xFF, 0xFF, 0x3A);   // 滑轨凹槽描边
        internal static readonly Color RingSoft   = new Color32(0xFF, 0xFF, 0xFF, 0x4D);   // 普通按钮描边
        internal static readonly Color RingLav    = new Color32(0x92, 0x92, 0xB5, 0xE6);   // 按钮描边（对齐游戏原生按钮）
        internal static readonly Color VinylDark  = new Color32(0x1A, 0x1A, 0x22, 0xFF);
        internal static readonly Color Shadow     = new Color32(0x00, 0x00, 0x00, 0x66);

        private static readonly Dictionary<string, Sprite> Cache = new Dictionary<string, Sprite>();
        private static Font _font;

        internal static Font UiFont
        {
            get
            {
                if (_font == null) _font = LoadFont();
                return _font;
            }
        }

        private static Font LoadFont()
        {
            var candidates = new[]
            {
                "Microsoft YaHei UI", "Microsoft YaHei", "Source Han Sans SC", "思源黑体",
                "Noto Sans CJK SC", "SimHei", "PingFang SC", "Arial Unicode MS", "Segoe UI"
            };
            try
            {
                var font = Font.CreateDynamicFontFromOSFont(candidates, 20);
                if (font != null) return font;
            }
            catch (Exception e)
            {
                Plugin.Log?.LogWarning("创建中文字体失败: " + e.Message);
            }

            try { return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } catch { /* 老版本 */ }
            try { return Resources.GetBuiltinResource<Font>("Arial.ttf"); } catch { /* 更低版本 */ }
            return null;
        }

        // ------------------------------------------------------------------ 贴图缓存

        private static Sprite Get(string key, Func<Sprite> factory)
        {
            if (Cache.TryGetValue(key, out var sprite) && sprite != null) return sprite;
            sprite = factory();
            Cache[key] = sprite;
            return sprite;
        }

        internal static void ClearCache() => Cache.Clear();

        private static Sprite ToSprite(Texture2D texture, Vector4 border)
            => ToSprite(texture, border, SpriteMeshType.FullRect);

        private static Sprite ToSprite(Texture2D texture, Vector4 border, SpriteMeshType meshType)
        {
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.filterMode = FilterMode.Bilinear;
            texture.Apply(false, false);
            return Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height),
                new Vector2(0.5f, 0.5f), 100f, 0, meshType, border);
        }

        // ------------------------------------------------------------------ 图形基元

        private static Texture2D NewTexture(int width, int height) =>
            new Texture2D(width, height, TextureFormat.RGBA32, false);

        private static float SdBox(float px, float py, float cx, float cy, float halfWidth, float halfHeight, float radius)
        {
            radius = Mathf.Min(radius, Mathf.Min(halfWidth, halfHeight));
            var qx = Mathf.Abs(px - cx) - halfWidth + radius;
            var qy = Mathf.Abs(py - cy) - halfHeight + radius;
            var outside = Mathf.Sqrt(Mathf.Max(qx, 0f) * Mathf.Max(qx, 0f) + Mathf.Max(qy, 0f) * Mathf.Max(qy, 0f));
            return outside + Mathf.Min(Mathf.Max(qx, qy), 0f) - radius;
        }

        private static float SdCircle(float px, float py, float cx, float cy, float radius) =>
            Mathf.Sqrt((px - cx) * (px - cx) + (py - cy) * (py - cy)) - radius;

        private static float SdSegment(float px, float py, float ax, float ay, float bx, float by)
        {
            var pax = px - ax;
            var pay = py - ay;
            var bax = bx - ax;
            var bay = by - ay;
            var h = Mathf.Clamp01((pax * bax + pay * bay) / Mathf.Max(0.0001f, bax * bax + bay * bay));
            var dx = pax - bax * h;
            var dy = pay - bay * h;
            return Mathf.Sqrt(dx * dx + dy * dy);
        }

        private static float SdTriangle(float px, float py, Vector2 a, Vector2 b, Vector2 c)
        {
            var d1 = EdgeDistance(px, py, a, b);
            var d2 = EdgeDistance(px, py, b, c);
            var d3 = EdgeDistance(px, py, c, a);

            // 顶点顺序（顺/逆时针）会改变符号约定，这里统一成"内部为负"：
            //   顺时针(area<0)：内部 → 三条边距离全为负 → 取最大值为负 ✓
            //   逆时针(area>0)：内部 → 三条边距离全为正 → 取最小值再取反才为负 ✓
            // （之前逆时针写成了 -最大值，导致外部点被判成内部 → 整个图标被涂满）
            var area = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
            if (area >= 0f)
            {
                var min = Mathf.Min(d1, Mathf.Min(d2, d3));
                return -min;
            }
            return Mathf.Max(d1, Mathf.Max(d2, d3));
        }

        private static float EdgeDistance(float px, float py, Vector2 a, Vector2 b)
        {
            var sign = (b.x - a.x) * (py - a.y) - (b.y - a.y) * (px - a.x);
            var length = Mathf.Sqrt((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y));
            return sign / Mathf.Max(0.0001f, length);
        }

        private static void Paint(Color32[] buffer, int size, int x, int y, float distance, Color color, float antialias = 1.1f)
        {
            if (x < 0 || y < 0 || x >= size || y >= size) return;
            var coverage = Mathf.Clamp01(0.5f - distance / antialias);
            if (coverage <= 0.001f) return;

            float srcAlpha = Mathf.Clamp01(coverage * color.a);
            if (srcAlpha <= 0.001f) return;

            var index = y * size + x;
            var dst = buffer[index];
            float dstAlpha = dst.a / 255f;
            float outAlpha = srcAlpha + dstAlpha * (1f - srcAlpha);
            if (outAlpha <= 0.0001f)
            {
                buffer[index] = new Color32(0, 0, 0, 0);
                return;
            }

            float r = (color.r * srcAlpha + dst.r / 255f * dstAlpha * (1f - srcAlpha)) / outAlpha;
            float g = (color.g * srcAlpha + dst.g / 255f * dstAlpha * (1f - srcAlpha)) / outAlpha;
            float b = (color.b * srcAlpha + dst.b / 255f * dstAlpha * (1f - srcAlpha)) / outAlpha;
            buffer[index] = new Color32(
                (byte)Mathf.Clamp(r * 255f, 0, 255),
                (byte)Mathf.Clamp(g * 255f, 0, 255),
                (byte)Mathf.Clamp(b * 255f, 0, 255),
                (byte)Mathf.Clamp(outAlpha * 255f, 0, 255));
        }

        // ------------------------------------------------------------------ 对外图形

        /// <summary>圆角矩形（九宫格拉伸用）。</summary>
        internal static Sprite RoundedRect(int width, int height, int radius, Color fill,
            Color border, int borderWidth = 0, float noise = 0f, float shadowBlur = 0f, int borderOverride = -1)
        {
            var key = $"rr_{width}_{height}_{radius}_{fill}_{border}_{borderWidth}_{noise}_{shadowBlur}_{borderOverride}";
            return Get(key, () =>
            {
                var texture = NewTexture(width, height);
                var buffer = new Color32[width * height];
                var centerX = width * 0.5f;
                var centerY = height * 0.5f;
                var seed = new System.Random(20240922);

                for (var y = 0; y < height; y++)
                {
                    for (var x = 0; x < width; x++)
                    {
                        var distance = SdBox(x + 0.5f, y + 0.5f, centerX, centerY, centerX, centerY, radius);
                        var color = fill;
                        if (borderWidth > 0 && distance > -borderWidth) color = border;

                        if (shadowBlur > 0f && distance > 0f)
                        {
                            var blur = Mathf.Clamp01(1f - distance / shadowBlur);
                            color = new Color(Shadow.r, Shadow.g, Shadow.b, Shadow.a * blur * blur);
                        }

                        if (noise > 0f)
                        {
                            var n = (float)(seed.NextDouble() - 0.5) * noise;
                            color = new Color(
                                Mathf.Clamp01(color.r + n),
                                Mathf.Clamp01(color.g + n),
                                Mathf.Clamp01(color.b + n),
                                color.a);
                        }

                        var aa = shadowBlur > 0f ? shadowBlur * 0.5f : 1.1f;
                        Paint(buffer, width, x, y, distance, color, aa);
                    }
                }

                texture.SetPixels32(buffer);
                // borderOverride = 0 表示用 Simple（可任意拉伸到很细，用于滑轨/填充条）
                var slice = borderOverride >= 0 ? borderOverride : Mathf.Max(4, radius);
                return ToSprite(texture, new Vector4(slice, slice, slice, slice));
            });
        }

        /// <summary>圆形（按钮、遮罩、封面上用）。</summary>
        internal static Sprite Circle(int size, Color fill, Color? border = null, int borderWidth = 0)
        {
            var borderColor = border ?? new Color(0, 0, 0, 0);
            var key = $"c_{size}_{fill}_{borderColor}_{borderWidth}";
            return Get(key, () =>
            {
                var texture = NewTexture(size, size);
                var buffer = new Color32[size * size];
                var c = size * 0.5f;
                var radius = c - 1f;

                for (var y = 0; y < size; y++)
                for (var x = 0; x < size; x++)
                {
                    var distance = SdCircle(x + 0.5f, y + 0.5f, c, c, radius);
                    var color = fill;
                    if (borderWidth > 0 && distance > -borderWidth) color = borderColor;
                    Paint(buffer, size, x, y, distance, color, 1.2f);
                }

                texture.SetPixels32(buffer);
                // 用 FullRect：Tight 网格是"多边形近似"，圆看起来是十几条直边。
                // 封面改成在贴图里直接做圆形 alpha 裁切，不再依赖 Mask。
                return ToSprite(texture, Vector4.zero);
            });
        }

        /// <summary>黑胶唱片：外圈唱片 + 纹路 + 米白标签 + 中心孔。</summary>
        internal static Sprite Vinyl(int size = 256)
        {
            return Get("vinyl_" + size, () =>
            {
                var texture = NewTexture(size, size);
                var buffer = new Color32[size * size];
                var c = size * 0.5f;
                var discRadius = c - 2f;
                var labelRadius = size * 0.21f;

                for (var y = 0; y < size; y++)
                {
                    for (var x = 0; x < size; x++)
                    {
                        var px = x + 0.5f;
                        var py = y + 0.5f;
                        var d = SdCircle(px, py, c, c, discRadius);

                        // 唱片本体（带一点顶部高光的渐变）
                        var t = Mathf.Clamp01((py - (c - discRadius)) / (discRadius * 2f));
                        var body = Color.Lerp(VinylDark, new Color(0.12f, 0.10f, 0.09f, 1f), t);
                        Paint(buffer, size, x, y, d, body, 1.4f);

                        // 纹路
                        for (var r = labelRadius + 8f; r < discRadius - 4f; r += 5.5f)
                        {
                            var groove = Mathf.Abs(SdCircle(px, py, c, c, r)) - 0.7f;
                            if (groove < 0.6f) Paint(buffer, size, x, y, groove, new Color(1f, 1f, 1f, 0.045f), 1.0f);
                        }

                        // 唱片标签：与强调色同族的青白
                        var label = SdCircle(px, py, c, c, labelRadius);
                        Paint(buffer, size, x, y, label, new Color(0.80f, 0.94f, 1f, 1f), 1.3f);
                        var inner = SdCircle(px, py, c, c, labelRadius - 3f);
                        Paint(buffer, size, x, y, inner, new Color(0.62f, 0.86f, 0.98f, 1f), 1.0f);

                        // 中心孔
                        Paint(buffer, size, x, y, SdCircle(px, py, c, c, size * 0.035f), new Color(0.10f, 0.10f, 0.14f, 1f), 1.2f);
                    }
                }

                texture.SetPixels32(buffer);
                return ToSprite(texture, Vector4.zero);
            });
        }

        /// <summary>轻微噪点叠加，给面板一点"纸"的颗粒感。</summary>
        internal static Sprite Noise(int size = 96, float strength = 0.055f)
        {
            return Get("noise_" + size + "_" + strength, () =>
            {
                var texture = NewTexture(size, size);
                var buffer = new Color32[size * size];
                var random = new System.Random(1337);
                for (var i = 0; i < buffer.Length; i++)
                {
                    var a = (float)random.NextDouble() * strength;
                    var v = (byte)(random.NextDouble() > 0.5 ? 255 : 0);
                    buffer[i] = new Color32(v, v, v, (byte)Mathf.Clamp(a * 255f, 0, 255));
                }
                texture.SetPixels32(buffer);
                var sprite = ToSprite(texture, Vector4.zero);
                sprite.texture.wrapMode = TextureWrapMode.Repeat;   // Tiled Image 需要 Repeat
                return sprite;
            });
        }

        /// <summary>圆角矩形 + 青→品红对角渐变描边（游戏面板的主要视觉语言）。</summary>
        internal static Sprite GradientRoundedRect(int width, int height, int radius, Color fill,
            Color borderStart, Color borderEnd, int borderWidth, float shadowBlur = 0f)
        {
            var key = $"grr_{width}_{height}_{radius}_{fill}_{borderStart}_{borderEnd}_{borderWidth}_{shadowBlur}";
            return Get(key, () =>
            {
                var texture = NewTexture(width, height);
                var buffer = new Color32[width * height];
                var centerX = width * 0.5f;
                var centerY = height * 0.5f;
                var total = (float)(width + height);

                for (var y = 0; y < height; y++)
                {
                    for (var x = 0; x < width; x++)
                    {
                        var distance = SdBox(x + 0.5f, y + 0.5f, centerX, centerY, centerX, centerY, radius);

                        var color = fill;
                        if (borderWidth > 0 && distance > -borderWidth)
                            color = Color.Lerp(borderStart, borderEnd, (x + y) / total);

                        if (shadowBlur > 0f && distance > 0f)
                        {
                            var blur = Mathf.Clamp01(1f - distance / shadowBlur);
                            color = new Color(Shadow.r, Shadow.g, Shadow.b, Shadow.a * blur * blur);
                        }

                        Paint(buffer, width, x, y, distance, color, shadowBlur > 0f ? shadowBlur * 0.5f : 1.1f);
                    }
                }

                texture.SetPixels32(buffer);
                var slice = Mathf.Max(4, radius);
                return ToSprite(texture, new Vector4(slice, slice, slice, slice));
            });
        }

        /// <summary>圆形 + 青→品红渐变描边（按钮/选中态）。</summary>
        internal static Sprite GradientRing(int size, Color fill, Color borderStart, Color borderEnd, int ringWidth)
        {
            var key = $"gr_{size}_{fill}_{borderStart}_{borderEnd}_{ringWidth}";
            return Get(key, () =>
            {
                var texture = NewTexture(size, size);
                var buffer = new Color32[size * size];
                var center = size * 0.5f;
                var radius = center - 1.5f;
                var total = (float)(size * 2);

                for (var y = 0; y < size; y++)
                {
                    for (var x = 0; x < size; x++)
                    {
                        var distance = SdCircle(x + 0.5f, y + 0.5f, center, center, radius);
                        var color = fill;
                        if (ringWidth > 0 && distance > -ringWidth)
                            color = Color.Lerp(borderStart, borderEnd, (x + y) / total);

                        Paint(buffer, size, x, y, distance, color, 1.2f);
                    }
                }

                texture.SetPixels32(buffer);
                return ToSprite(texture, Vector4.zero, SpriteMeshType.Tight);
            });
        }

        /// <summary>横向渐变条（进度条/音量条填充）。</summary>
        internal static Sprite GradientBar(int width, int height, int radius, Color start, Color end, int borderOverride = 0)
        {
            var key = $"gbar_{width}_{height}_{radius}_{start}_{end}_{borderOverride}";
            return Get(key, () =>
            {
                var texture = NewTexture(width, height);
                var buffer = new Color32[width * height];
                var centerX = width * 0.5f;
                var centerY = height * 0.5f;

                for (var y = 0; y < height; y++)
                {
                    for (var x = 0; x < width; x++)
                    {
                        var distance = SdBox(x + 0.5f, y + 0.5f, centerX, centerY, centerX, centerY, radius);
                        var color = Color.Lerp(start, end, width <= 1 ? 0f : x / (float)(width - 1));
                        Paint(buffer, width, x, y, distance, color, 1.1f);
                    }
                }

                texture.SetPixels32(buffer);
                var slice = borderOverride >= 0 ? borderOverride : Mathf.Max(4, radius);
                return ToSprite(texture, new Vector4(slice, slice, slice, slice));
            });
        }

        /// <summary>矢量风格图标（白色，用 Image.color 上色）。</summary>
        internal static Sprite Icon(LofiIcon icon, int size = 64)
        {
            return Get("icon_" + icon + "_" + size, () =>
            {
                var texture = NewTexture(size, size);
                var buffer = new Color32[size * size];
                var s = (float)size;
                var white = Color.white;

                switch (icon)
                {
                    // 注意：图形要尽量铺满贴图（0.06~0.94）。之前只占约一半宽度，
                    // 缩放到按钮尺寸后图形只有预期的一半大，看起来又小又糊。
                    case LofiIcon.Play:
                        DrawTriangle(buffer, size, new Vector2(0.20f, 0.10f) * s, new Vector2(0.20f, 0.90f) * s, new Vector2(0.88f, 0.50f) * s, white);
                        break;

                    case LofiIcon.Pause:
                        DrawBox(buffer, size, 0.32f * s, 0.5f * s, 0.095f * s, 0.36f * s, 0.075f * s, white);
                        DrawBox(buffer, size, 0.68f * s, 0.5f * s, 0.095f * s, 0.36f * s, 0.075f * s, white);
                        break;

                    case LofiIcon.Prev:
                        DrawBox(buffer, size, 0.13f * s, 0.5f * s, 0.06f * s, 0.32f * s, 0.05f * s, white);
                        DrawTriangle(buffer, size, new Vector2(0.94f, 0.10f) * s, new Vector2(0.94f, 0.90f) * s, new Vector2(0.26f, 0.50f) * s, white);
                        break;

                    case LofiIcon.Next:
                        DrawBox(buffer, size, 0.87f * s, 0.5f * s, 0.06f * s, 0.32f * s, 0.05f * s, white);
                        DrawTriangle(buffer, size, new Vector2(0.06f, 0.10f) * s, new Vector2(0.06f, 0.90f) * s, new Vector2(0.74f, 0.50f) * s, white);
                        break;

                    case LofiIcon.RepeatAll:
                        DrawRing(buffer, size, 0.5f * s, 0.5f * s, 0.38f * s, 0.07f * s, white);
                        // 箭头落在圆环右上、沿顺时针切线方向
                        DrawArrow(buffer, size, new Vector2(0.54f, 0.92f) * s, new Vector2(0.86f, 0.60f) * s, 0.07f * s, 0.26f * s, white);
                        break;

                    case LofiIcon.RepeatOne:
                        // 环变细一点，给中间的"1"让出空间（之前 1 贴着环，糊成一团）
                        DrawRing(buffer, size, 0.5f * s, 0.5f * s, 0.39f * s, 0.065f * s, white);
                        DrawArrow(buffer, size, new Vector2(0.56f, 0.93f) * s, new Vector2(0.88f, 0.61f) * s, 0.065f * s, 0.24f * s, white);
                        DrawSegment(buffer, size, 0.50f * s, 0.26f * s, 0.50f * s, 0.74f * s, 0.07f * s, white);
                        DrawSegment(buffer, size, 0.50f * s, 0.74f * s, 0.33f * s, 0.62f * s, 0.055f * s, white);
                        break;

                    case LofiIcon.Shuffle:
                        // 之前：线太细(0.05) + 箭头太长(0.30) + 只画到 0.72，
                        // 缩到 25px 时两个箭头和交叉点糊在一起 —— 看起来就是个"✕"。
                        // 现在按 Material shuffle 的比例：加粗笔画、箭头收到最右端。
                        DrawArrow(buffer, size, new Vector2(0.09f, 0.76f) * s, new Vector2(0.91f, 0.24f) * s, 0.085f * s, 0.24f * s, white);
                        DrawArrow(buffer, size, new Vector2(0.09f, 0.24f) * s, new Vector2(0.91f, 0.76f) * s, 0.085f * s, 0.24f * s, white);
                        break;

                    case LofiIcon.Volume:
                        // 之前图形横向只占 0.07~0.80，重心偏左，看着像"歪"了；声波也太细。
                        // 现在整体铺满 0.15~0.84（视觉居中），并把声波加粗。
                        DrawBox(buffer, size, 0.24f * s, 0.50f * s, 0.085f * s, 0.115f * s, 0.03f * s, white);
                        DrawTriangle(buffer, size, new Vector2(0.325f, 0.62f) * s, new Vector2(0.54f, 0.88f) * s, new Vector2(0.54f, 0.12f) * s, white);
                        // 声波：只画右侧圆弧（画整圆会把喇叭切断）
                        DrawArc(buffer, size, 0.54f * s, 0.50f * s, 0.185f * s, 0.065f * s, 0f, 62f, white);
                        DrawArc(buffer, size, 0.54f * s, 0.50f * s, 0.295f * s, 0.065f * s, 0f, 58f, new Color(1f, 1f, 1f, 0.85f));
                        break;

                    case LofiIcon.Lyrics:
                        DrawBox(buffer, size, 0.5f * s, 0.66f * s, 0.28f * s, 0.05f * s, 0.05f * s, white);
                        DrawBox(buffer, size, 0.42f * s, 0.50f * s, 0.20f * s, 0.05f * s, 0.05f * s, white);
                        DrawBox(buffer, size, 0.46f * s, 0.34f * s, 0.24f * s, 0.05f * s, 0.05f * s, white);
                        break;

                    case LofiIcon.Close:
                        DrawSegment(buffer, size, 0.28f * s, 0.28f * s, 0.72f * s, 0.72f * s, 0.045f * s, white);
                        DrawSegment(buffer, size, 0.72f * s, 0.28f * s, 0.28f * s, 0.72f * s, 0.045f * s, white);
                        break;

                    case LofiIcon.Login:
                        // 之前是"小圆 + 大圆环"两个圆，缩到 25px 就是个"8"。
                        // 现在：实心圆头 + 圆弧肩膀，才是能认出来的人形。
                        DrawCircle(buffer, size, 0.50f * s, 0.72f * s, 0.165f * s, white);
                        DrawArc(buffer, size, 0.50f * s, 0.12f * s, 0.36f * s, 0.085f * s, 90f, 74f, white);
                        break;

                    case LofiIcon.Refresh:
                        // 之前是"整圆 + 一个乱放的三角"，看着像"♀"。
                        // 现在：留缺口的圆环 + 沿切线方向的箭头（顺时针刷新）。
                        DrawArc(buffer, size, 0.50f * s, 0.50f * s, 0.31f * s, 0.075f * s, 180f, 160f, white);
                        DrawArrow(buffer, size, new Vector2(0.719f, 0.719f) * s, new Vector2(0.791f, 0.606f) * s,
                            0.075f * s, 0.23f * s, white);
                        break;

                    case LofiIcon.List:
                        for (var i = 0; i < 3; i++)
                        {
                            var y = (0.30f + i * 0.20f) * s;
                            DrawBox(buffer, size, 0.58f * s, y, 0.26f * s, 0.035f * s, 0.035f * s, white);
                            DrawBox(buffer, size, 0.24f * s, y, 0.035f * s, 0.035f * s, 0.035f * s, white);
                        }
                        break;

                    case LofiIcon.Trash:
                        DrawBox(buffer, size, 0.5f * s, 0.42f * s, 0.22f * s, 0.24f * s, 0.05f * s, white);
                        DrawBox(buffer, size, 0.5f * s, 0.76f * s, 0.28f * s, 0.035f * s, 0.03f * s, white);
                        DrawBox(buffer, size, 0.5f * s, 0.68f * s, 0.10f * s, 0.04f * s, 0.02f * s, white);
                        break;

                    case LofiIcon.Music:
                        DrawCircle(buffer, size, 0.30f * s, 0.22f * s, 0.17f * s, white);
                        DrawSegment(buffer, size, 0.45f * s, 0.24f * s, 0.45f * s, 0.86f * s, 0.045f * s, white);
                        DrawTriangle(buffer, size, new Vector2(0.45f, 0.88f) * s, new Vector2(0.86f, 0.72f) * s, new Vector2(0.45f, 0.54f) * s, white);
                        break;
                }

                texture.SetPixels32(buffer);
                return ToSprite(texture, Vector4.zero);
            });
        }

        private static void DrawBox(Color32[] buffer, int size, float cx, float cy, float halfWidth, float halfHeight, float radius, Color color)
        {
            for (var y = 0; y < size; y++)
            for (var x = 0; x < size; x++)
                Paint(buffer, size, x, y, SdBox(x + 0.5f, y + 0.5f, cx, cy, halfWidth, halfHeight, radius), color, 1.2f);
        }

        private static void DrawTriangle(Color32[] buffer, int size, Vector2 a, Vector2 b, Vector2 c, Color color)
        {
            for (var y = 0; y < size; y++)
            for (var x = 0; x < size; x++)
                Paint(buffer, size, x, y, SdTriangle(x + 0.5f, y + 0.5f, a, b, c), color, 1.2f);
        }

        private static void DrawSegment(Color32[] buffer, int size, float ax, float ay, float bx, float by, float thickness, Color color)
        {
            for (var y = 0; y < size; y++)
            for (var x = 0; x < size; x++)
                Paint(buffer, size, x, y, SdSegment(x + 0.5f, y + 0.5f, ax, ay, bx, by) - thickness, color, 1.2f);
        }

        /// <summary>带方向箭头的线段（箭头自动沿线段方向，避免手填三角形导致朝向错乱）。</summary>
        private static void DrawArrow(Color32[] buffer, int size, Vector2 from, Vector2 to, float thickness, float headLength, Color color)
        {
            DrawSegment(buffer, size, from.x, from.y, to.x, to.y, thickness, color);

            var direction = (to - from).normalized;
            var perpendicular = new Vector2(-direction.y, direction.x);
            var basePoint = to - direction * headLength;
            DrawTriangle(buffer, size, to,
                basePoint + perpendicular * (headLength * 0.62f),
                basePoint - perpendicular * (headLength * 0.62f),
                color);
        }

        private static void DrawRing(Color32[] buffer, int size, float cx, float cy, float radius, float thickness, Color color)
        {
            for (var y = 0; y < size; y++)
            for (var x = 0; x < size; x++)
            {
                var d = Mathf.Abs(SdCircle(x + 0.5f, y + 0.5f, cx, cy, radius)) - thickness;
                Paint(buffer, size, x, y, d, color, 1.2f);
            }
        }

        /// <summary>圆弧（只画 centerAngle ± halfSpan 范围内的环段），用于音量声波等。</summary>
        private static void DrawArc(Color32[] buffer, int size, float cx, float cy, float radius,
            float thickness, float centerAngleDeg, float halfSpanDeg, Color color)
        {
            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    var px = x + 0.5f;
                    var py = y + 0.5f;
                    var dx = px - cx;
                    var dy = py - cy;
                    var distance = Mathf.Sqrt(dx * dx + dy * dy);

                    var ring = Mathf.Abs(distance - radius) - thickness;
                    if (ring > 1.5f) continue;

                    var angle = Mathf.Atan2(dy, dx) * Mathf.Rad2Deg;
                    if (Mathf.Abs(Mathf.DeltaAngle(angle, centerAngleDeg)) > halfSpanDeg) continue;

                    Paint(buffer, size, x, y, ring, color, 1.2f);
                }
            }
        }

        private static void DrawCircle(Color32[] buffer, int size, float cx, float cy, float radius, Color color)
        {
            for (var y = 0; y < size; y++)
            for (var x = 0; x < size; x++)
                Paint(buffer, size, x, y, SdCircle(x + 0.5f, y + 0.5f, cx, cy, radius), color, 1.2f);
        }
    }
}

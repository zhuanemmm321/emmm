(function () {
  var out = [];
  var imgs = document.querySelectorAll('img');
  for (var i = 0; i < imgs.length; i++) {
    var src = imgs[i].src || '';
    if (src.indexOf('ptqrshow') >= 0 || src.indexOf('qrcode') >= 0 || src.indexOf('qr') >= 0) {
      out.push('IMG ' + (imgs[i].width || 0) + 'x' + (imgs[i].height || 0) + ' ' + src.slice(0, 90));
    }
  }
  var iframes = document.querySelectorAll('iframe');
  for (var j = 0; j < iframes.length; j++) {
    out.push('IFRAME ' + (iframes[j].src || '').slice(0, 110));
  }
  var dialogs = document.querySelectorAll('[class*=login],[class*=qr],[id*=login],[id*=qr]');
  out.push('elements-with-login-or-qr-class: ' + dialogs.length);
  return out.join(' ;; ') || 'NONE';
})()

// 开发用小工具：反射 dump 游戏 Assembly-CSharp.dll 的类型/方法，
// 用来挑选 Harmony 补丁的挂载点。不参与插件本体编译。
//
// 用法: TypeDump.exe "<Managed 目录>" <正则过滤>
using System;
using System.IO;
using System.Linq;
using System.Reflection;

internal static class Program
{
    private static string _managed;

    private static int Main(string[] args)
    {
        if (args.Length < 2)
        {
            Console.WriteLine("usage: TypeDump <managedDir> <typeFilterRegex> [memberFilterRegex]");
            return 2;
        }

        _managed = args[0];
        var typeFilter = args[1];
        var memberFilter = args.Length > 2 ? args[2] : ".";

        AppDomain.CurrentDomain.AssemblyResolve += Resolve;

        Assembly asm;
        try
        {
            asm = Assembly.LoadFrom(Path.Combine(_managed, "Assembly-CSharp.dll"));
        }
        catch (Exception e)
        {
            Console.WriteLine("load failed: " + e.Message);
            return 3;
        }

        Type[] types;
        try
        {
            types = asm.GetTypes();
        }
        catch (ReflectionTypeLoadException ex)
        {
            types = ex.Types.Where(t => t != null).ToArray();
            Console.WriteLine("(部分类型加载失败: " + ex.LoaderExceptions.FirstOrDefault()?.Message + ")");
        }
        catch (Exception e)
        {
            Console.WriteLine("GetTypes failed: " + e.Message);
            return 4;
        }

        Console.WriteLine("total types: " + types.Length);

        foreach (var type in types
                     .Where(t => System.Text.RegularExpressions.Regex.IsMatch(t.FullName ?? "", typeFilter, System.Text.RegularExpressions.RegexOptions.IgnoreCase))
                     .OrderBy(t => t.FullName))
        {
            var baseName = type.BaseType != null ? type.BaseType.FullName : "-";
            Console.WriteLine();
            Console.WriteLine("=== " + type.FullName + "   : " + baseName);

            BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;

            foreach (var m in type.GetMethods(flags)
                         .Where(m => System.Text.RegularExpressions.Regex.IsMatch(m.Name, memberFilter, System.Text.RegularExpressions.RegexOptions.IgnoreCase))
                         .OrderBy(m => m.Name))
            {
                var ps = string.Join(", ", m.GetParameters().Select(p => p.ParameterType.Name + " " + p.Name));
                Console.WriteLine("    " + (m.IsPublic ? "public" : m.IsPrivate ? "private" : "other")
                                  + (m.IsStatic ? " static" : "") + " " + m.ReturnType.Name + " " + m.Name + "(" + ps + ")");
            }

            foreach (var f in type.GetFields(flags).OrderBy(f => f.Name))
                Console.WriteLine("    field " + f.FieldType.Name + " " + f.Name);

            foreach (var p in type.GetProperties(flags).OrderBy(p => p.Name))
                Console.WriteLine("    prop  " + p.PropertyType.Name + " " + p.Name);
        }

        return 0;
    }

    private static Assembly Resolve(object sender, ResolveEventArgs args)
    {
        try
        {
            var simple = new AssemblyName(args.Name).Name;
            var path = Path.Combine(_managed, simple + ".dll");
            return File.Exists(path) ? Assembly.LoadFrom(path) : null;
        }
        catch
        {
            return null;
        }
    }
}

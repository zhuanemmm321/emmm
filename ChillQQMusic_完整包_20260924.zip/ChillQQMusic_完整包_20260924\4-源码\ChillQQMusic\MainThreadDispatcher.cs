using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Threading;
using UnityEngine;

namespace ChillQQMusic
{
    /// <summary>
    /// 主线程任务泵。
    ///
    /// Unity 的 UGUI / AudioSource / Texture 只能在主线程调用，网络与文件操作在后台线程完成，
    /// 完成后统一 Post 到这里执行。
    ///
    /// 与最初版本的区别：队列改成**静态**的，泵由 MonoBehaviour.Update 或 RuntimeWatchdog
    /// 两条路径驱动。这样即使本组件随插件对象一起被游戏销毁，任务也不会丢、也不会在
    /// 后台线程上误调 Unity API。
    /// </summary>
    internal sealed class MainThreadDispatcher : MonoBehaviour
    {
        private static MainThreadDispatcher _instance;
        private static int _mainThreadId;

        private static readonly ConcurrentQueue<Action> Queue = new ConcurrentQueue<Action>();

        internal static int MainThreadId => _mainThreadId;

        internal static bool IsMainThread =>
            _mainThreadId != 0 && Thread.CurrentThread.ManagedThreadId == _mainThreadId;

        internal static void Initialize(GameObject host)
        {
            if (_mainThreadId == 0) _mainThreadId = Thread.CurrentThread.ManagedThreadId;
            if (_instance != null || host == null) return;

            _instance = host.AddComponent<MainThreadDispatcher>();
        }

        /// <summary>线程安全入队；真正的执行一定发生在主线程的泵里。</summary>
        internal static void Post(Action action)
        {
            if (action == null) return;
            Queue.Enqueue(action);
        }

        internal static void RunCoroutine(IEnumerator routine)
        {
            if (routine == null) return;
            Post(() =>
            {
                try
                {
                    if (_instance != null) _instance.StartCoroutine(routine);
                    else Plugin.Log?.LogWarning("当前没有可用的协程宿主，已忽略该协程。");
                }
                catch (Exception e)
                {
                    Plugin.Log?.LogWarning("启动协程失败: " + e.Message);
                }
            });
        }

        /// <summary>由 Plugin.Update 与 RuntimeWatchdog 共同调用；空队列时开销可忽略。</summary>
        internal static void PumpOnMainThread()
        {
            while (Queue.TryDequeue(out var action))
            {
                try { action(); }
                catch (Exception e) { Plugin.Log?.LogError("主线程任务异常: " + e); }
            }
        }

        private void Update() => PumpOnMainThread();

        private void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }
    }
}

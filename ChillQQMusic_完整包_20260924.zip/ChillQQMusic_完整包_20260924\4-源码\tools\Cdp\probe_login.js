(function () {
  var out = [];
  var els = document.querySelectorAll('[class*=login],[class*=qr],[id*=login],[id*=qr]');
  for (var i = 0; i < els.length && i < 8; i++) {
    out.push('EL ' + els[i].tagName + ' cls=' + els[i].className + ' | ' + (els[i].innerText || '').replace(/\s+/g, ' ').slice(0, 70));
  }
  out.push('count=' + els.length);
  var all = document.querySelectorAll('*');
  var shadow = 0;
  for (var j = 0; j < all.length; j++) { if (all[j].shadowRoot) shadow++; }
  out.push('shadowRoots=' + shadow);
  out.push('iframeCount=' + document.querySelectorAll('iframe').length);
  out.push('imgCount=' + document.querySelectorAll('img').length);
  out.push('canvasCount=' + document.querySelectorAll('canvas').length);
  return out.join(' ;; ');
})()
